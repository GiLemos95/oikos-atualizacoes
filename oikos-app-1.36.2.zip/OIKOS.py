# -*- coding: utf-8 -*-
"""
Classificador Ambiental MT — v1.18 — direcionamento por categorias de TRs (cadastro auditável)
Base normativa embutida:
- Resolução CONSEMA 74/2025
- Decreto Estadual 1.585/2022

Atenção: esta versão possui uma tabela inicial de municípios/grupos já validados no projeto.
Municípios ainda não cadastrados são bloqueados, em vez de o programa presumir competência.
"""
import tkinter as tk
from tkinter import ttk
import json, re, unicodedata
import webbrowser
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import threading
from difflib import SequenceMatcher

CONSEMA=json.loads('[{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Tratamento de sementes","CNAE":"0141-5/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite confinada","CNAE":"0151-2/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":100,"CONDIÇÃO":"Unidade de produção de leitões","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":"Crescimento e Terminação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":10,"MÁXIMO":100,"CONDIÇÃO":"Ciclo Completo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Avicultura de corte","CNAE":"0155-5/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":30001,"MÁXIMO":150000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Unidade de inspeção e classificação de ovos","CNAE":"0155-5/05","UNIDADE":"dúzias/dia","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de pintinhos de um dia (incubatório)","CNAE":"0155-5/02","UNIDADE":"pintinhos/mês","OPERADOR":null,"MÍNIMO":500001,"MÁXIMO":1000000,"CONDIÇÃO":"Incubatório","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":10000,"MÁXIMO":50000,"CONDIÇÃO":"Postura","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura convencional em tanques escavados (não admitida criação de espécies alóctones e/ou exóticas; e desde que fora de Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Não admitida criação de espécies alóctones e/ou exóticas; Desde que fora de Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Não admitida criação de espécies alóctones e exóticas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":50,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":50,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de produtos de pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abatedouro de grande porte (bovinos e bubalinos)","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":"Bovinos e Bubalinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":50,"CONDIÇÃO":"Ovinos e Caprinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Exceto silvestres","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":null,"MÍNIMO":30,"MÁXIMO":2500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":50,"CONDIÇÃO":"Abate de suínos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de frutas","CNAE":"1031-7/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sucos concentrados de frutas, hortaliças e legumes","CNAE":"1033-3/01","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Preparação do leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laticínios","CNAE":"1052-0/00","UNIDADE":"litros/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de arroz, exceto parboilização","CNAE":"1061-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto parboilização","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos do arroz","CNAE":"1061-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Moagem de trigo e fabricação de derivados","CNAE":"1062-7/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de mandioca e derivados","CNAE":"1063-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de milho e derivados, exceto óleos de milho","CNAE":"1064-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":"Exceto óleos de milho","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos para animais","CNAE":"1066-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Unidade de processamento castanhas, amêndoas e grãos","CNAE":"1069-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de açúcar","CNAE":"1071-6/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de café","CNAE":"1081-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":"Com predominância de produção própria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":2500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Exceto Artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":1000,"CONDIÇÃO":"Exceto Artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós alimentício","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fermentos, leveduras, fungos e algas","CNAE":"1099-6/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos para infusão (chá, mate, etc.)","CNAE":"1099-6/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adoçantes naturais e artificiais","CNAE":"1099-6/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos dietéticos e complementos alimentares","CNAE":"1099-6/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos alimentícios não especificados anteriormente","CNAE":"1099-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aguardentes e outras bebidas destiladas","CNAE":"1111-9/01","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cervejas e chopes","CNAE":"1113-5/02","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chá mate e outros chás prontos para consumo","CNAE":"1122-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto refrescos de frutas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento e descaroçamento de algodão","CNAE":"1311-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fiação de fibras artificiais e sintéticas","CNAE":"1313-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de linhas para costurar e bordar","CNAE":"1314-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de algodão, exceto artesanal","CNAE":"1321-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto Artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto algodão","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras artificiais e sintéticas, exceto artesanal","CNAE":"1323-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto Artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tapeçaria","CNAE":"1352-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cordoaria","CNAE":"1353-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos especiais, inclusive artefatos","CNAE":"1354-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Inclusive artefatos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos têxteis não especificados anteriormente","CNAE":"1359-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos para viagem, bolsas e semelhantes de qualquer material","CNAE":"1521-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de couro","CNAE":"1531-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados anteriormente","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de partes para calçados, de qualquer material","CNAE":"1540-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"De qualquer material","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de madeira, exceto móveis e carvoaria","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis e carvoaria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de cortiça, bambu, palha, vime e outros materiais trançados, exceto móveis","CNAE":"1629-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas de madeira pré-fabricadas","CNAE":"1622-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais","CNAE":"1622-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artigos de carpintaria para construção","CNAE":"1622-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tanoaria e de embalagens de madeira","CNAE":"1623-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Trituração e/ou secagem de biomassa, com ou sem produção de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com ou sem produção de briquetes","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de papel","CNAE":"1731-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de cartolina e papel-cartão","CNAE":"1732-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas e de embalagens de papelão ondulado","CNAE":"1733-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel para uso doméstico e higiênico-sanitário não especificados anteriormente","CNAE":"1742-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de jornais","CNAE":"1811-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de livros, revistas e outras publicações periódicas","CNAE":"1811-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinas fixas e móveis de asfalto a quente ou frio (betume ou outro material)","CNAE":"2399-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fósforos de segurança","CNAE":"2092-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas, filmes, papéis e outros materiais e produtos químicos para fotografia","CNAE":"2099-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pneumáticos e de câmaras-de-ar","CNAE":"2211-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Reforma de pneumáticos usados","CNAE":"2212-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas pré-moldadas de concreto armado, em série e sob encomenda","CNAE":"2330-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Em série e sob encomenda","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cimento para uso na construção","CNAE":"2330-3/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de fibrocimento para uso na construção","CNAE":"2330-3/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas pré-moldadas de concreto","CNAE":"2330-3/04","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinagem e preparação de massa de concreto e argamassa para construção","CNAE":"2330-3/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes","CNAE":"2330-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos refratários","CNAE":"2341-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material sanitário de cerâmica","CNAE":"2349-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos não refratários não especificados anteriormente","CNAE":"2349-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Britamento de pedras, exceto associado à extração","CNAE":"2391-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de pedras para construção, exceto associado à extração","CNAE":"2391-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de placas, e execução de trabalhos em mármore, granito, ardósia e outros materiais","CNAE":"2391-5/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de minerais não metálicos não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus","CNAE":"2930-1/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Exceto caminhões e ônibus","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis de outros materiais, exceto madeira e metal","CNAE":"3103-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto madeira e metal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos musicais, peças e acessórios","CNAE":"3220-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos não eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório","CNAE":"3250-7/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos para pesca e esporte","CNAE":"3230-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de roupas de proteção e segurança e resistentes a fogo","CNAE":"3292-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e acessórios para segurança pessoal e profissional","CNAE":"3292-2/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de guarda-chuvas e similares","CNAE":"3299-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de canetas, lápis e outros artigos para escritório","CNAE":"3299-0/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cerâmica ou barro cozido para uso na construção civil - exceto azulejos e piso","CNAE":"2342-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto azulejos e piso","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Serviços de usinagem, tornearia e solda","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Jateamento de peças","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas","CNAE":"2511-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas (sem usinagem e galvanização)","CNAE":"2511-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem usinagem e galvanização","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de metal","CNAE":"2512-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de artefatos estampados de metal","CNAE":"2532-2/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Metalurgia do pó","CNAE":"2532-2/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de serralheria","CNAE":"2542-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens metálicas","CNAE":"2591-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal padronizados","CNAE":"2592-6/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal, exceto padronizados","CNAE":"2592-6/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Exceto padronizados","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de metal para uso doméstico e pessoal","CNAE":"2593-4/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de metal não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de bancos e estofados para veículos automotores","CNAE":"2949-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Recondicionamento e recuperação de motores para veículos automotores","CNAE":"2950-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Ponto Fixo","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Ponto Fixo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Área Delimitada","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Área Delimitada","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Parque Eólico / Usina Eólica / Central Eólica e Usina por meio de fonte solar para sistemas fotovoltaicos e heliotérmicos","CNAE":"3511-5/01","UNIDADE":"MW/h","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Usina termoelétrica, inclusive móvel (caldeiras e motores estacionários)","CNAE":"3511-5/08","UNIDADE":"MW/h","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":0.5,"CONDIÇÃO":"Inclusive móvel caldeiras e motores estacionários","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de arena para eventos, auditórios, concha acústica, centro de eventos, teatro, anfiteatro, parque de exposição e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estabelecimentos de ensino, como creches, escolas, centros de inclusão digital, asilos e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1600,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de edificações (comerciais, serviços e institucionais)","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de centro de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Obras de implantação de praças, ciclovias e calçadas e similares","CNAE":"4213-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Instalação ou substituição de bueiros tubulares e celulares","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de passarelas sobre rodovias e vias urbanas e rurais","CNAE":"4212-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estações e redes de telecomunicações (construção e operação)","CNAE":"4221-9/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Construção e operação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de cisternas ou caixas d\'água de sistema de abastecimento público","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Substituição de redes coletoras de água e esgoto (exceto coletores tronco, emissários e elevatórias de esgoto)","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto coletores tronco, emissários e elevatórias de esgoto","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Coleta de resíduos não perigosos (transportadora de resíduos urbanos)","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Transportadora de resíduos urbanos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Transportadoras de resíduos Classe II","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":26},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Limpeza, coleta e transporte de resíduos por veículos “limpa fossa”","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Central de triagem de resíduos sólidos urbanos","CNAE":"3821-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Estação de transbordo de resíduos sólidos urbanos","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, sem geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Sem geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, com geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Com geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos não perigosos - Classe II","CNAE":"3821-1/12","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos de construção civil classe A","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe A","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":null,"MÍNIMO":30.1,"MÁXIMO":60,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias não pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias não pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias públicas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com Desmate","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias internas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com Desmate","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias rurais em revestimento primário, sem desmate","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":6,"MÁXIMO":null,"CONDIÇÃO":"Sem Desmate","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação e drenagem de águas pluviais em vias rurais municipais","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação urbana e drenagem de águas pluviais urbanas","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Rampas fluviais para embarque e desembarque de pequenas embarcações e pequeno ancoradouro","CNAE":"4291-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":24,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de tablados, píers e demais estruturas flutuantes sem propulsão","CNAE":"4291-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem propulsão","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Canteiro de obras","CNAE":"4299-5/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Loteamento urbano","CNAE":"4299-5/99","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Conjunto de edificações (residencial, comercial ou de serviço) - horizontal ou vertical","CNAE":"8112-5/00","UNIDADE":"unidades","OPERADOR":null,"MÍNIMO":5,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica médica (clínicas e consultórios com ambulatório)","CNAE":"8630-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Clínicas e consultórios com ambulatório","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica odontológica","CNAE":"8630-5/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades médicas veterinárias (hospitais, clínicas, consultórios e laboratórios de análises)","CNAE":"7500-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Laboratório de pesquisa física, química e biológica, comercial e não comercial","CNAE":"7210-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de serviços de complementação diagnósticos ou terapêutica, laboratório de anatomia patologia; laboratório: de análises clínicas, serviços de raio-x, radioterapia, serviços de quimioterapia, serviço de banco de sangue, etc","CNAE":"8640-2/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista com depósito, centro de distribuição e depósitos de defensivos agrícolas, adubos, fertilizantes e corretivos do solo","CNAE":"4683-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com depósito, centro de distribuição e depósitos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de produtos farmacêuticos com manipulação de fórmulas","CNAE":"4771-7/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":"Com manipulação de fórmulas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de imunização e controle de pragas urbanas","CNAE":"8122-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Mercados, supermercados, atacadistas de produtos alimentícios e afins","CNAE":"4691-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Instalação de armazém inflável","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Armazéns de grãos","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviço de aluguel e locação de banheiros químicos","CNAE":"7739-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4682-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4784-9/00","UNIDADE":"Classe ANP","OPERADOR":">=","MÍNIMO":4,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Pátio de descontaminação","CNAE":"3900-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Posto de abastecimento (tanque aéreo)","CNAE":"52.11-7","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":15,"MÁXIMO":60,"CONDIÇÃO":"Tanque aéreo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Meios de hospedagem (hotéis, motéis, pousadas, etc) localizados fora de APP e Unidades de Conservação","CNAE":"5510-8/01","UNIDADE":"unidades","OPERADOR":">=","MÍNIMO":20,"MÁXIMO":null,"CONDIÇÃO":"Localizados fora de APP e Unidades de Conservação","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de lavagem, lubrificação e polimento de veículos automotores","CNAE":"4520-0/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de manutenção e reparação de veículos automotores, aeronaves, equipamentos e outros (geradores de resíduos perigosos, como óleos, graxas, tintas, solventes, entre outros)","CNAE":"4520-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Lavanderias","CNAE":"9601-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"A","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Tinturarias","CNAE":"9601-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":27},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Tratamento de sementes","CNAE":"0141-5/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite confinada","CNAE":"0151-2/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite confinada","CNAE":"0151-2/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":100,"CONDIÇÃO":"Unidade de produção de leitões","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":300,"CONDIÇÃO":"Unidade de produção de leitões","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":"Crescimento e Terminação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":"Crescimento e Terminação","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":10,"MÁXIMO":300,"CONDIÇÃO":"Ciclo Completo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Avicultura de corte","CNAE":"0155-5/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":30001,"MÁXIMO":200000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Unidade de inspeção e classificação de ovos","CNAE":"0155-5/05","UNIDADE":"dúzias/dia","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de pintinhos de um dia (incubatório)","CNAE":"0155-5/02","UNIDADE":"pintinhos/mês","OPERADOR":null,"MÍNIMO":500001,"MÁXIMO":1500000,"CONDIÇÃO":"Incubatório","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":10000,"MÁXIMO":150000,"CONDIÇÃO":"Postura","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura convencional em tanques escavados (não admitida criação de espécies alóctones e/ou exóticas; e desde que fora de Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":15,"CONDIÇÃO":"Não admitida criação de espécies alóctones e/ou exóticas; Desde que fora de Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Não admitida criação de espécies alóctones e exóticas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":5000,"CONDIÇÃO":"Não admitida criação de espécies alóctones e exóticas","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":50,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de produtos de pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de produtos de pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abatedouro de grande porte (bovinos e bubalinos)","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":70,"CONDIÇÃO":"Bovinos e Bubalinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Ovinos e Caprinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":"Exceto Silvestres","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":null,"MÍNIMO":30,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Abate de suínos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de frutas","CNAE":"1031-7/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sucos concentrados de frutas, hortaliças e legumes","CNAE":"1033-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Preparação do leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Preparação do leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laticínios","CNAE":"1052-0/00","UNIDADE":"litros/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de arroz, exceto parboilização","CNAE":"1061-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto parboilização","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":28},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos do arroz","CNAE":"1061-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Moagem de trigo e fabricação de derivados","CNAE":"1062-7/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de mandioca e derivados","CNAE":"1063-5/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de milho e derivados, exceto óleos de milho","CNAE":"1064-3/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":"Exceto óleos de milho","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos para animais","CNAE":"1066-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de óleos vegetais em bruto, exceto óleo de milho","CNAE":"1041-4/00","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Exceto óleo de milho","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Unidade de processamento castanhas, amêndoas e grãos","CNAE":"1069-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de açúcar","CNAE":"1071-6/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de café","CNAE":"1081-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":"Com predominância de produção própria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":201,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":1000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós alimentício","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós alimentício","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fermentos, leveduras, fungos e algas","CNAE":"1099-6/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos para infusão (chá, mate, etc.)","CNAE":"1099-6/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adoçantes naturais e artificiais","CNAE":"1099-6/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos dietéticos e complementos alimentares","CNAE":"1099-6/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos alimentícios não especificados anteriormente","CNAE":"1099-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aguardentes e outras bebidas destiladas","CNAE":"1111-9/01","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cervejas e chopes","CNAE":"1113-5/02","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":30000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chá mate e outros chás prontos para consumo","CNAE":"1122-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":"Exceto refrescos de frutas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento e descaroçamento de algodão","CNAE":"1311-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fiação de fibras artificiais e sintéticas, exceto artesanal","CNAE":"1313-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de linhas para costurar e bordar","CNAE":"1314-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de algodão, exceto artesanal","CNAE":"1321-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão, exceto artesanal","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão, exceto artesanal","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras artificiais e sintéticas, exceto artesanal","CNAE":"1323-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tapeçaria","CNAE":"1352-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cordoaria","CNAE":"1353-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos especiais, inclusive artefatos","CNAE":"1354-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Inclusive artefatos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos têxteis não especificados anteriormente","CNAE":"1359-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos para viagem, bolsas e semelhantes de qualquer material, exceto artesanal","CNAE":"1521-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":29},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de couro","CNAE":"1531-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de partes para calçados, de qualquer material","CNAE":"1540-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"De qualquer material","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de madeira, exceto móveis e carvoaria","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis e carvoaria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de cortiça, bambu, palha, vime e outros materiais trançados, exceto móveis","CNAE":"1629-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas de madeira pré-fabricadas","CNAE":"1622-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais","CNAE":"1622-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artigos de carpintaria para construção","CNAE":"1622-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tanoaria e de embalagens de madeira","CNAE":"1623-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Trituração e/ou secagem de biomassa, com ou sem produção de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com ou sem produção de briquetes","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de papel","CNAE":"1731-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de cartolina e papel-cartão","CNAE":"1732-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas e de embalagens de papelão ondulado","CNAE":"1733-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel para uso doméstico e higiênico-sanitário não especificados anteriormente","CNAE":"1742-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de jornais","CNAE":"1811-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de livros, revistas e outras publicações periódicas","CNAE":"1811-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinas fixas e móveis de asfalto a quente ou frio (betume ou outro material)","CNAE":"2399-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fósforos de segurança","CNAE":"2092-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas, filmes, papéis e outros materiais e produtos químicos para fotografia","CNAE":"2099-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pneumáticos e de câmaras-de-ar","CNAE":"2211-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Reforma de pneumáticos usados","CNAE":"2212-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas pré-moldadas de concreto armado, em série e sob encomenda","CNAE":"2330-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Em série e sob encomenda","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cimento para uso na construção","CNAE":"2330-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de fibrocimento para uso na construção","CNAE":"2330-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas pré-moldadas de concreto","CNAE":"2330-3/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinagem e preparação de massa de concreto e argamassa para construção","CNAE":"2330-3/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes","CNAE":"2330-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos refratários","CNAE":"2341-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material sanitário de cerâmica","CNAE":"2349-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos não refratários não especificados anteriormente","CNAE":"2349-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Britamento de pedras, exceto associado à extração","CNAE":"2391-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de pedras para construção, exceto associado à extração","CNAE":"2391-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de placas, e execução de trabalhos em mármore, granito, ardósia e outros materiais","CNAE":"2391-5/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":30},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de minerais não metálicos não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus","CNAE":"2930-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto caminhões e ônibus","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis de outros materiais, exceto madeira e metal","CNAE":"3103-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto madeira e metal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos musicais, peças e acessórios","CNAE":"3220-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos não eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório","CNAE":"3250-7/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos para pesca e esporte","CNAE":"3230-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de roupas de proteção e segurança e resistentes a fogo","CNAE":"3292-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e acessórios para segurança pessoal e profissional","CNAE":"3292-2/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de guarda-chuvas e similares","CNAE":"3299-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de canetas, lápis e outros artigos para escritório","CNAE":"3299-0/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cerâmica ou barro cozido para uso na construção civil - exceto azulejos e piso","CNAE":"2342-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto azulejos e piso","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Serviços de usinagem, tornearia e solda","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Jateamento de peças","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes organominerais","CNAE":"2013-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes, exceto organominerais","CNAE":"2013-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto organominerais","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biofertilizantes e inoculantes, e outros fertilizantes","CNAE":"2013-4/03","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fraldas descartáveis","CNAE":"1742-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de absorventes higiênicos","CNAE":"1742-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases","CNAE":"2014-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases industriais","CNAE":"2014-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de intermediários para plastificantes, resinas e fibras","CNAE":"2022-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos químicos orgânicos não especificados anteriormente","CNAE":"2029-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de resinas termofixas e resinas termoplásticas","CNAE":"2031-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tintas de impressão","CNAE":"2072-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adesivos e selantes","CNAE":"2091-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aditivos de uso industrial","CNAE":"2091-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de medicamentos para uso veterinário","CNAE":"2122-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de borracha","CNAE":"2219-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laminados planos e tubulares de material plástico","CNAE":"2221-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de material plástico","CNAE":"2221-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de material plástico","CNAE":"2222-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tubos e acessórios de material plástico para uso na construção","CNAE":"2223-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso pessoal e doméstico","CNAE":"2229-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para usos industriais","CNAE":"2229-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso na construção, exceto tubos e acessórios","CNAE":"2229-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto tubos e acessórios","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para outros usos não especificados anteriormente","CNAE":"2229-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de arames de aço","CNAE":"2424-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de alumínio e suas ligas em formas primárias","CNAE":"2441-5/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de componentes eletrônicos","CNAE":"2610-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Metalurgia dos metais preciosos","CNAE":"2442-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de ânodos para galvanoplastia","CNAE":"2449-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":31},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fundição de ferro e aço","CNAE":"2451-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas","CNAE":"2511-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas (sem usinagem e galvanização)","CNAE":"2511-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem usinagem e galvanização","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de metal","CNAE":"2512-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de obras de caldeiraria pesada","CNAE":"2513-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de artefatos estampados de metal","CNAE":"2532-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Metalurgia do pó","CNAE":"2532-2/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de serralheria","CNAE":"2542-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens metálicas","CNAE":"2591-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal padronizados","CNAE":"2592-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal, exceto padronizados","CNAE":"2592-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto padronizados","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de metal para uso doméstico e pessoal","CNAE":"2593-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de metal não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de informática","CNAE":"2621-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de periféricos para equipamentos de informática","CNAE":"2622-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos transmissores de comunicação, peças e acessórios","CNAE":"2631-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos telefônicos e de outros equipamentos de comunicação, peças e acessórios","CNAE":"2632-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cronômetros e relógios","CNAE":"2652-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e instrumentos ópticos, peças e acessórios","CNAE":"2670-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de geradores de corrente contínua e alternada, peças e acessórios","CNAE":"2710-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de transformadores, indutores, conversores, sincronizadores e semelhantes, peças e acessórios","CNAE":"2710-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de motores elétricos, peças e acessórios","CNAE":"2710-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pilhas, baterias e acumuladores elétricos, exceto para veículos automotores","CNAE":"2721-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto para veículos automotores","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos para distribuição e controle de energia elétrica","CNAE":"2731-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico para instalações em circuito de consumo","CNAE":"2732-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros aparelhos eletrodomésticos não especificados anteriormente, peças e acessórios","CNAE":"2759-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros equipamentos e aparelhos elétricos não especificados anteriormente","CNAE":"2790-2/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de válvulas, registros e dispositivos semelhantes, peças e acessórios","CNAE":"2813-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de transmissão para fins industriais, exceto rolamentos","CNAE":"2815-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto rolamentos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estufas e fornos elétricos para fins industriais, peças e acessórios","CNAE":"2821-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos de ar condicionado para uso industrial e não industrial","CNAE":"2824-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de máquinas de escrever, calcular e outros equipamentos não eletrônicos para escritório, peças e acessórios","CNAE":"2829-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema motor de veículos automotores","CNAE":"2941-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para os sistemas de marcha e transmissão de veículos automotores","CNAE":"2942-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de freios de veículos automotores","CNAE":"2943-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de direção e suspensão de veículos automotores","CNAE":"2944-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico e eletrônico para veículos automotores, exceto baterias","CNAE":"2945-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto baterias","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de bancos e estofados para veículos automotores","CNAE":"2949-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Recondicionamento e recuperação de motores para veículos automotores","CNAE":"2950-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Construção de embarcações para uso comercial e para usos especiais, exceto de grande porte","CNAE":"3011-3/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto de grande porte","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Ponto fixo","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Ponto fixo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Área Delimitada","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Área Delimitada","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":32},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Parque Eólico / Usina Eólica / Central Eólica e Usina por meio de fonte solar para sistemas fotovoltaicos e heliotérmicos","CNAE":"3511-5/01","UNIDADE":"MW/h","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Subestação abaixadora de tensão / Seccionadora","CNAE":"3514-0/00","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Linha de transmissão e/ou de Distribuição (inclusive RDR)","CNAE":"4221-9/02","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":"Inclusive RDR","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Usina termoelétrica, inclusive móvel (caldeiras e motores estacionários)","CNAE":"3511-5/08","UNIDADE":"MW/h","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":0.5,"CONDIÇÃO":"Inclusive móvel (caldeiras e motores estacionários)","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de arena para eventos, auditórios, concha acústica, centro de eventos, teatro, anfiteatro, parque de exposição e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estabelecimentos de ensino, como creches, escolas, centros de inclusão digital, asilos e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1600,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de edificações (comerciais, serviços e institucionais)","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de centro de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Obras de implantação de praças, ciclovias e calçadas","CNAE":"4213-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Instalação ou substituição de bueiros tubulares e celulares","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de passarelas sobre rodovias e vias urbanas e rurais","CNAE":"4212-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estações e redes de telecomunicações (construção e operação)","CNAE":"4221-9/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Construção e operação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de cisternas ou caixas d\'água de sistema de abastecimento público","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Substituição de redes coletoras de água e esgoto (exceto coletores tronco, emissários e elevatórias de esgoto)","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto coletores tronco, emissários e elevatórias de esgoto","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Coleta de resíduos não perigosos (transportadora de resíduos urbanos)","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Transportadora de resíduos urbanos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Transportadoras de resíduos Classe II","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Limpeza, coleta e transporte de resíduos por veículos “limpa fossa”","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Central de triagem de resíduos sólidos urbanos","CNAE":"3821-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Estação de transbordo de resíduos sólidos urbanos","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, sem geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Sem geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, com geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Com geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos não perigosos - Classe II","CNAE":"3821-1/12","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos de construção civil classe A","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe A","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Compostagem de resíduos sólidos orgânicos (exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos)","CNAE":"3839-4/01","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Aeródromo","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Autódromo","CNAE":"4299-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":null,"MÍNIMO":30.1,"MÁXIMO":60,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":">","MÍNIMO":60,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias não pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias não pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias públicas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com desmate","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias internas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com desmate","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias rurais em revestimento primário, sem desmate","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":6,"MÁXIMO":null,"CONDIÇÃO":"Sem desmate","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação e drenagem de águas pluviais em vias rurais municipais","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação urbana e drenagem de águas pluviais urbanas","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Rampas fluviais para embarque e desembarque de pequenas embarcações e pequeno ancoradouro","CNAE":"4291-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":24,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de tablados, píers e demais estruturas flutuantes sem propulsão","CNAE":"4291-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem propulsão","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Canteiro de obras","CNAE":"4299-5/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de muro de contenção em áreas de risco ou uso restrito","CNAE":"4299-5/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Loteamento urbano","CNAE":"4299-5/99","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":25,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Conjunto de edificações (residencial, comercial ou de serviço) - horizontal ou vertical","CNAE":"8112-5/00","UNIDADE":"unidades","OPERADOR":null,"MÍNIMO":5,"MÁXIMO":300,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":33},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica médica (clínicas e consultórios com ambulatório)","CNAE":"8630-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Clínicas e consultórios com ambulatório","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica odontológica (clínicas e consultórios com ambulatório)","CNAE":"8630-5/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Clínicas e consultórios com ambulatório","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de serviços de complementação diagnósticos ou terapêutica, laboratório de anatomia patologia; laboratório: de análises clínicas, serviços de raio-x, radioterapia, serviços de quimioterapia, serviço de banco de sangue, etc","CNAE":"8640-2/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades médicas veterinárias (hospitais, clínicas, consultórios e laboratórios de análises)","CNAE":"7500-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Laboratório de pesquisa física, química e biológica, comercial e não comercial","CNAE":"7210-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista com depósito, centro de distribuição e depósitos de defensivos agrícolas, adubos, fertilizantes e corretivos do solo","CNAE":"4683-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com depósito, centro de distribuição e depósitos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de produtos farmacêuticos com manipulação de fórmulas","CNAE":"4771-7/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":"Com manipulação de fórmulas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de imunização e controle de pragas urbanas","CNAE":"8122-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Mercados, supermercados, atacadistas de produtos alimentícios e afins","CNAE":"4691-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Instalação de armazém inflável","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Armazéns de grãos","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviço de aluguel e locação de banheiros químicos","CNAE":"7739-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4682-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4784-9/00","UNIDADE":"Classe ANP","OPERADOR":">=","MÍNIMO":4,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Pátio de descontaminação","CNAE":"3900-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Posto de abastecimento (tanque aéreo)","CNAE":"52.11-7","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":15,"MÁXIMO":120,"CONDIÇÃO":"Tanque aéreo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Meios de hospedagem (hotéis, motéis, pousadas, etc) localizados fora de APP e Unidades de Conservação","CNAE":"5510-8/01","UNIDADE":"unidades","OPERADOR":">=","MÍNIMO":20,"MÁXIMO":null,"CONDIÇÃO":"Localizados fora de APP e Unidades de Conservação","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Restaurantes em áreas de interesse ambiental","CNAE":"5611-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de lavagem, lubrificação e polimento de veículos automotores","CNAE":"4520-0/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de manutenção e reparação de veículos automotores, aeronaves, equipamentos e outros (geradores de resíduos perigosos, como óleos, graxas, tintas, solventes, entre outros)","CNAE":"4520-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Lavanderias","CNAE":"9601-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"B","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Tinturarias","CNAE":"9601-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Tratamento de sementes","CNAE":"0141-5/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"unidades/ciclo","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":7500,"CONDIÇÃO":"Período Seco","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"unidades/ciclo","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":3750,"CONDIÇÃO":"Período Chuvoso","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite confinada","CNAE":"0151-2/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite confinada","CNAE":"0151-2/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":100,"CONDIÇÃO":"Unidade de produção de leitões","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":2000,"CONDIÇÃO":"Unidade de produção de leitões","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":"Crescimento e Terminação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":25000,"CONDIÇÃO":"Crescimento e Terminação","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/00","UNIDADE":"unidades/ciclo","OPERADOR":null,"MÍNIMO":10,"MÁXIMO":2000,"CONDIÇÃO":"Ciclo Completo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Avicultura de corte","CNAE":"0155-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Unidade de inspeção e classificação de ovos","CNAE":"0155-5/05","UNIDADE":"dúzias/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de pintinhos de um dia (incubatório)","CNAE":"0155-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Incubatório","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":10000,"MÁXIMO":150000,"CONDIÇÃO":"Postura","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":">","MÍNIMO":150000,"MÁXIMO":null,"CONDIÇÃO":"Postura","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura convencional em tanques escavados (não admitida criação de espécies alóctones e/ou exóticas; e desde que fora de Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":"Não admitida criação de espécies alóctones e/ou exóticas; Desde que fora de Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":34},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Não admitida criação de espécies alóctones e exóticas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":10000,"CONDIÇÃO":"Não admitida criação de espécies alóctones e exóticas","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":201,"MÁXIMO":800,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":50,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de Produtos de Pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de Produtos de Pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abatedouro de grande porte (bovinos e bubalinos)","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":70,"CONDIÇÃO":"Bovinos e bubalinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Ovinos e caprinos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":200,"CONDIÇÃO":"Ovinos e caprinos","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":"Exceto silvestres","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":11,"MÁXIMO":20,"CONDIÇÃO":"Exceto silvestres","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":null,"MÍNIMO":30,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":null,"MÍNIMO":5001,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Abate de suínos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":200,"CONDIÇÃO":"Abate de suínos","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de frutas","CNAE":"1031-7/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":501,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sucos concentrados de frutas, hortaliças e legumes","CNAE":"1033-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Preparação do leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Preparação do leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laticínios","CNAE":"1052-0/00","UNIDADE":"litros/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laticínios","CNAE":"1052-0/00","UNIDADE":"litros/dia","OPERADOR":null,"MÍNIMO":5001,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de arroz, exceto parboilização","CNAE":"1061-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto parboilização","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos do arroz","CNAE":"1061-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Moagem de trigo e fabricação de derivados","CNAE":"1062-7/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de mandioca e derivados","CNAE":"1063-5/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de milho e derivados, exceto óleos de milho","CNAE":"1064-3/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":"Exceto óleos de milho","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos para animais","CNAE":"1066-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de óleos vegetais em bruto, exceto óleo de milho","CNAE":"1041-4/00","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Exceto óleo de milho","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Unidade de processamento castanhas, amêndoas e grãos","CNAE":"1069-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de açúcar","CNAE":"1071-6/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de café","CNAE":"1081-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":501,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":"Com predominância de produção própria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":2000,"CONDIÇÃO":"Com predominância de produção própria","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":35},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos, exceto artesanal","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":1000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós alimentício","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós alimentício","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fermentos, leveduras, fungos e algas","CNAE":"1099-6/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos para infusão (chá, mate, etc.)","CNAE":"1099-6/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adoçantes naturais e artificiais","CNAE":"1099-6/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos dietéticos e complementos alimentares","CNAE":"1099-6/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos alimentícios não especificados anteriormente","CNAE":"1099-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aguardentes e outras bebidas destiladas","CNAE":"1111-9/01","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cervejas e chopes","CNAE":"1113-5/02","UNIDADE":"litros/mês","OPERADOR":null,"MÍNIMO":1000,"MÁXIMO":60000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chá mate e outros chás prontos para consumo","CNAE":"1122-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":"Exceto refrescos de frutas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento e descaroçamento de algodão","CNAE":"1311-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fiação de fibras artificiais e sintéticas, exceto artesanal","CNAE":"1313-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de linhas para costurar e bordar","CNAE":"1314-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de algodão, exceto artesanal","CNAE":"1321-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão, exceto artesanal","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão, exceto artesanal","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":3000,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras artificiais e sintéticas, exceto artesanal","CNAE":"1323-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto artesanal","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tapeçaria","CNAE":"1352-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cordoaria","CNAE":"1353-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos especiais, inclusive artefatos","CNAE":"1354-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Inclusive artefatos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos têxteis não especificados anteriormente","CNAE":"1359-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos para viagem, bolsas e semelhantes de qualquer material","CNAE":"1521-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de couro","CNAE":"1531-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de partes para calçados, de qualquer material","CNAE":"1540-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"De qualquer material","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de madeira, exceto móveis e carvoaria","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis e carvoaria","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de cortiça, bambu, palha, vime e outros materiais trançados, exceto móveis","CNAE":"1629-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto móveis","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas de madeira pré-fabricadas","CNAE":"1622-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais","CNAE":"1622-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artigos de carpintaria para construção","CNAE":"1622-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tanoaria e de embalagens de madeira","CNAE":"1623-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Trituração e/ou secagem de biomassa, com ou sem produção de briquetes","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com ou sem produção de briquetes","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de papel","CNAE":"1731-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de cartolina e papel-cartão","CNAE":"1732-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas e de embalagens de papelão ondulado","CNAE":"1733-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":36},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel para uso doméstico e higiênico-sanitário não especificados anteriormente","CNAE":"1742-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de jornais","CNAE":"1811-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Impressão de livros, revistas e outras publicações periódicas","CNAE":"1811-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinas fixas e móveis de asfalto a quente ou frio (betume ou outro material)","CNAE":"2399-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fósforos de segurança","CNAE":"2092-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas, filmes, papéis e outros materiais e produtos químicos para fotografia","CNAE":"2099-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pneumáticos e de câmaras-de-ar","CNAE":"2211-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Reforma de pneumáticos usados","CNAE":"2212-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas pré-moldadas de concreto armado, em série e sob encomenda","CNAE":"2330-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Em série e sob encomenda","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cimento para uso na construção","CNAE":"2330-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de fibrocimento para uso na construção","CNAE":"2330-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas pré-moldadas de concreto","CNAE":"2330-3/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Usinagem e Preparação de massa de concreto e argamassa para construção","CNAE":"2330-3/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes","CNAE":"2330-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos refratários","CNAE":"2341-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material sanitário de cerâmica","CNAE":"2349-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos não refratários não especificados anteriormente","CNAE":"2349-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Britamento de pedras, exceto associado à extração","CNAE":"2391-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de pedras para construção, exceto associado à extração","CNAE":"2391-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto associado à extração","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de placas, e execução de trabalhos em mármore, granito, ardósia e outros materiais","CNAE":"2391-5/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de minerais não metálicos não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus","CNAE":"2930-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto caminhões e ônibus","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Com predominância de madeira","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis de outros materiais, exceto madeira e metal","CNAE":"3103-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto madeira e metal","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos musicais, peças e acessórios","CNAE":"3220-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos não eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório","CNAE":"3250-7/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos para pesca e esporte","CNAE":"3230-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de roupas de proteção e segurança e resistentes a fogo","CNAE":"3292-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":37},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e acessórios para segurança pessoal e profissional","CNAE":"3292-2/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de guarda-chuvas e similares","CNAE":"3299-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de canetas, lápis e outros artigos para escritório","CNAE":"3299-0/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cerâmica ou barro cozido para uso na construção civil - exceto azulejos e piso","CNAE":"2342-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto azulejos e piso","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Serviços de usinagem, tornearia e solda","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Jateamento de peças","CNAE":"2539-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes organominerais","CNAE":"2013-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes, exceto organominerais","CNAE":"2013-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto organominerais","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biofertilizantes e inoculantes, e outros fertilizantes","CNAE":"2013-4/03","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fraldas descartáveis","CNAE":"1742-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de absorventes higiênicos","CNAE":"1742-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases","CNAE":"2014-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases industriais","CNAE":"2014-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de intermediários para plastificantes, resinas e fibras","CNAE":"2022-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos químicos orgânicos não especificados anteriormente","CNAE":"2029-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de resinas termofixas e resinas termoplásticas","CNAE":"2031-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tintas de impressão","CNAE":"2072-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adesivos e selantes","CNAE":"2091-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aditivos de uso industrial","CNAE":"2091-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de medicamentos para uso veterinário","CNAE":"2122-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de borracha","CNAE":"2219-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laminados planos e tubulares de material plástico","CNAE":"2221-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de material plástico","CNAE":"2221-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de material plástico","CNAE":"2222-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tubos e acessórios de material plástico para uso na construção","CNAE":"2223-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso pessoal e doméstico","CNAE":"2229-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para usos industriais","CNAE":"2229-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso na construção, exceto tubos e acessórios","CNAE":"2229-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto tubos e acessórios","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para outros usos não especificados anteriormente","CNAE":"2229-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de arames de aço","CNAE":"2424-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de alumínio e suas ligas em formas primárias","CNAE":"2441-5/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de componentes eletrônicos","CNAE":"2610-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Metalurgia dos metais preciosos","CNAE":"2442-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de ânodos para galvanoplastia","CNAE":"2449-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fundição de ferro e aço","CNAE":"2451-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas","CNAE":"2511-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas (sem usinagem e galvanização)","CNAE":"2511-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem usinagem e galvanização","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de metal","CNAE":"2512-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de obras de caldeiraria pesada","CNAE":"2513-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de artefatos estampados de metal","CNAE":"2532-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Metalurgia do pó","CNAE":"2532-2/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de serralheria","CNAE":"2542-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens metálicas","CNAE":"2591-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal padronizados","CNAE":"2592-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal, exceto padronizados","CNAE":"2592-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto padronizados","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":38},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de metal para uso doméstico e pessoal","CNAE":"2593-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de metal não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de informática","CNAE":"2621-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de periféricos para equipamentos de informática","CNAE":"2622-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos transmissores de comunicação, peças e acessórios","CNAE":"2631-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos telefônicos e de outros equipamentos de comunicação, peças e acessórios","CNAE":"2632-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cronômetros e relógios","CNAE":"2652-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e instrumentos ópticos, peças e acessórios","CNAE":"2670-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de geradores de corrente contínua e alternada, peças e acessórios","CNAE":"2710-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de transformadores, indutores, conversores, sincronizadores e semelhantes, peças e acessórios","CNAE":"2710-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de motores elétricos, peças e acessórios","CNAE":"2710-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pilhas, baterias e acumuladores elétricos, exceto para veículos automotores","CNAE":"2721-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto para veículos automotores","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos para distribuição e controle de energia elétrica","CNAE":"2731-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico para instalações em circuito de consumo","CNAE":"2732-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros aparelhos eletrodomésticos não especificados anteriormente, peças e acessórios","CNAE":"2759-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros equipamentos e aparelhos elétricos não especificados anteriormente","CNAE":"2790-2/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de válvulas, registros e dispositivos semelhantes, peças e acessórios","CNAE":"2813-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de transmissão para fins industriais, exceto rolamentos","CNAE":"2815-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto rolamentos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estufas e fornos elétricos para fins industriais, peças e acessórios","CNAE":"2821-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos de ar condicionado para uso industrial e não industrial","CNAE":"2824-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de máquinas de escrever, calcular e outros equipamentos não eletrônicos para escritório, peças e acessórios","CNAE":"2829-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema motor de veículos automotores","CNAE":"2941-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para os sistemas de marcha e\\ntransmissão de veículos automotores","CNAE":"2942-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de freios de\\nveículos automotores","CNAE":"2943-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de direção e\\nsuspensão de veículos automotores","CNAE":"2944-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico e eletrônico para veículos\\nautomotores, exceto baterias","CNAE":"2945-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto baterias","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Fabricação de bancos e estofados para veículos automotores","CNAE":"2949-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Recondicionamento e recuperação de motores para veículos\\nautomotores","CNAE":"2950-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Construção de embarcações para uso comercial e para usos\\nespeciais, exceto de grande porte","CNAE":"3011-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto de grande porte","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Ponto fixo","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - ponto fixo","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":"Ponto fixo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Área delimitada","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INDÚSTRIA","ATIVIDADE":"Produção de cavaco - área delimitada","CNAE":"1629-3/01","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Área delimitada","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":39},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Parque Eólico / Usina Eólica / Central Eólica e Usina por meio de fonte solar para sistemas fotovoltaicos e helitérmicos","CNAE":"3511-5/01","UNIDADE":"MW/h","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Subestação abaixadora de tensão / Seccionadora","CNAE":"3514-0/00","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MEDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Linha de transmissão e/ou de distribuição (inclusive RDR)","CNAE":"4221-9/02","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":"Inclusive RDR","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Usina termoelétrica, inclusive móvel (caldeiras e motores estacionários)","CNAE":"3511-5/08","UNIDADE":"MW/h","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":0.5,"CONDIÇÃO":"Inclusive móvel (caldeiras e motores estacionários)","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Usina termoelétrica, inclusive móvel (caldeiras e motores estacionários)","CNAE":"3511-5/08","UNIDADE":"MW/h","OPERADOR":null,"MÍNIMO":0.6,"MÁXIMO":1,"CONDIÇÃO":"Inclusive móvel (caldeiras e motores estacionários)","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de arena para eventos, auditórios, concha acústica, centro de eventos, teatro, anfiteatro, parque de exposição e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estabelecimentos de ensino, como creches, escolas, centros de inclusão digital, asilos e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1600,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de edificações (comerciais, serviços e institucionais)","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de centro de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Obras de implantação de praças, ciclovias e calçadas","CNAE":"4213-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Instalação ou substituição de bueiros tubulares e celulares","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de passarelas sobre rodovias e vias urbanas e rurais","CNAE":"4212-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estações e redes de telecomunicações (construção e operação)","CNAE":"4221-9/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Construção e operação","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de cisternas ou caixas d’água de sistema de abastecimento público","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Substituição de redes coletoras de água e esgoto (exceto coletores tronco, emissários e elevatórias de esgoto)","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto coletores tronco, emissários e elevatórias de esgoto","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Coleta de resíduos não perigosos (transportadora de resíduos urbanos)","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Transportadora de resíduos urbanos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Transportadoras de resíduos Classe II","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Limpeza, coleta e transporte de resíduos por veículos “limpa fossa”","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Central de triagem de resíduos sólidos urbanos","CNAE":"3821-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Estação de transbordo de resíduos sólidos urbanos","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, sem geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Sem geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Comércio atacadista, armazenamento e processamento de materiais recicláveis e sucatas metálicas, com geração de efluentes líquidos","CNAE":"46.87-7","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Com geração de efluentes líquidos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos não perigosos - Classe II","CNAE":"3821-1/12","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos de construção civil classe A","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe A","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Compostagem de resíduos sólidos orgânicos (exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos)","CNAE":"3839-4/01","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Aeródromo","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Autódromo","CNAE":"4299-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":null,"MÍNIMO":30.1,"MÁXIMO":60,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes e demais obras de arte corrente","CNAE":"4212-0/00","UNIDADE":"m","OPERADOR":">","MÍNIMO":60,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação e manutenção de vias não pavimentadas","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Vias não pavimentadas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias públicas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com desmate","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias internas em áreas rurais em revestimento primário, com desmate","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com desmate","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de vias rurais em revestimento primário, sem desmate","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":6,"MÁXIMO":null,"CONDIÇÃO":"Sem desmate","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação e drenagem de águas pluviais em vias rurais municipais","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação urbana e drenagem de águas pluviais urbanas","CNAE":"4211-1/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Rampas fluviais para embarque e desembarque de pequenas embarcações e pequeno ancoradouro","CNAE":"4291-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":24,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de tablados, píers e demais estruturas flutuantes sem propulsão","CNAE":"4291-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem propulsão","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Canteiro de obras","CNAE":"4299-5/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Construção de muro de contenção em áreas de risco ou uso restrito","CNAE":"4299-5/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Loteamento para sítios de lazer","CNAE":"4299-5/99","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":90,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Loteamento urbano","CNAE":"4299-5/99","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":50,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Conjunto de edificações (residencial, comercial ou de serviço) - horizontal ou vertical","CNAE":"8112-5/00","UNIDADE":"unidades","OPERADOR":">","MÍNIMO":5,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Obras de urbanização de orlas fluviais ou lacustres","CNAE":"4213-8/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Sistema de tratamento de água","CNAE":"3600-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"INFRAESTRUTURA","ATIVIDADE":"Sistema de tratamento de esgoto, exceto com lançamento em rios estaduais e federais","CNAE":"3701-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Exceto com lançamento em rios estaduais e federais","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":40},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica médica (clínicas, consultórios com ambulatório, e similares)","CNAE":"8630-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":"Clínicas, consultórios com ambulatório e similares","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de clínica odontológica","CNAE":"8630-5/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de serviços de complementação diagnósticos ou terapêutica, laboratório de anatomia patologia; laboratório: de análises clínicas, serviços de raio-x, radioterapia, serviços de quimioterapia, serviço de banco de sangue, etc","CNAE":"8640-2/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades médicas veterinárias (hospitais, clínicas, consultórios e laboratórios de análises)","CNAE":"7500-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Laboratório de pesquisa física, química e biológica, comercial e não comercial","CNAE":"7210-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista com depósito, centro de distribuição e depósitos de defensivos agrícolas, adubos, fertilizantes e corretivos do solo","CNAE":"4683-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Com depósito, centro de distribuição e depósitos","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de produtos farmacêuticos com manipulação de fórmulas","CNAE":"4771-7/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":"Com manipulação de fórmulas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Atividades de imunização e controle de pragas urbanas","CNAE":"8122-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Mercados, supermercados, atacadistas de produtos alimentícios","CNAE":"4691-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Instalação de armazém inflável","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Armazéns de grãos","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviço de aluguel e locação de banheiros químicos","CNAE":"7739-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio atacadista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4682-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4784-9/00","UNIDADE":"Classe ANP","OPERADOR":">=","MÍNIMO":4,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Pátio de descontaminação","CNAE":"3900-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Comércio a varejo de combustíveis e lubrificantes para veículos automotores","CNAE":"4731-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Posto de abastecimento (tanque enterrado)","CNAE":"52.11-7","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Tanque enterrado","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Posto de abastecimento (tanque aéreo)","CNAE":"52.11-7","UNIDADE":"m³","OPERADOR":">","MÍNIMO":15,"MÁXIMO":null,"CONDIÇÃO":"Tanque aéreo","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Meios de hospedagem (hotéis, motéis, pousadas e similares) localizados fora de APP e Unidades de Conservação","CNAE":"5510-8/01","UNIDADE":"unidades","OPERADOR":">=","MÍNIMO":20,"MÁXIMO":null,"CONDIÇÃO":"Localizados fora de APP e Unidades de Conservação","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Restaurantes em áreas de interesse ambiental","CNAE":"5611-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de lavagem, lubrificação e polimento de veículos automotores","CNAE":"4520-0/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Serviços de manutenção e reparação de veículos automotores, aeronaves, equipamentos e outros (geradores de resíduos perigosos, como óleos, graxas, tintas, solventes, entre outros)","CNAE":"4520-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Lavanderias","CNAE":"9601-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"SERVIÇOS","ATIVIDADE":"Tinturarias","CNAE":"9601-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"MINERAÇÃO","ATIVIDADE":"Extração de areia, e argila para obras civis públicas","CNAE":"08.10-0","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Para obras civis públicas","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"MINERAÇÃO","ATIVIDADE":"Extração de cascalho para obras civis públicas","CNAE":"08.10-0","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Para obras civis públicas","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":41},{"GRUPO":"C","DEPARTAMENTO":"MINERAÇÃO","ATIVIDADE":"Extração de argila para obras civis públicas","CNAE":"08.10-0","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":"Para obras civis públicas","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":41}]')
DECRETO=json.loads('[{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos e  bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":1500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Tratamento  de Sementes","CNAE":"0141-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":1500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":1500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":1500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"matrizes","OPERADOR":">","MÍNIMO":300,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/01","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":1500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/02","UNIDADE":"matrizes","OPERADOR":">","MÍNIMO":300,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Avicultura de corte","CNAE":"0155-5/01","UNIDADE":"cabeças","OPERADOR":">","MÍNIMO":150000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de pintos de um dia (Incubatório)","CNAE":"0155-5/02","UNIDADE":"pintinhos/mês","OPERADOR":">","MÍNIMO":1500000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (Postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":">","MÍNIMO":150000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Unidade de Inspeção e Classificação de ovos","CNAE":"0155-5/06","UNIDADE":"dúzias/dia","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de animais silvestres nativos e/ou exóticos em cativeiro","CNAE":"0159-8/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de carvão vegetal","CNAE":"0210-1/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de carvão vegetal - resíduos madeireiros e florestais","CNAE":"0220-9/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Carcinicultura","CNAE":"0322-1/02","UNIDADE":"ha","OPERADOR":">","MÍNIMO":5,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de ostras e mexilhões em água doce","CNAE":"0322-1/03","UNIDADE":"ha","OPERADOR":">","MÍNIMO":5,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de peixes ornamentais de água doce","CNAE":"0322-1/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criadouro científico da fauna silvestre nativa e exótica","CNAE":"0159-8/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criadouro comercial da fauna silvestre nativa e exótica","CNAE":"0159-8/99; 4633-8; 4623-1; 4644-3; 4724-5","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criadouro conservacionista de fauna silvestre nativa ou exótica","CNAE":"0159-8/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Mantenedouro da fauna silvestre nativa e exótica","CNAE":"7210-0","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Zoológico ou jardim zoológico","CNAE":"9103-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Ranicultura","CNAE":"0322-1/05","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Laboratório de Alevinagem","CNAE":"0322-1/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Convencional em tanques escavados (para criação de  espécies  alóctones e/ou exóticas, ou estiver localizada em Área de Preservação Permanente)","CNAE":"0322-1/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Para criação de espécies  alóctones e/ou exóticas; ou estiver localizada em Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura  Convencional  em  tanques  escavados  (quando  não criar espécies alóctones e/ou exóticas, e não estiver localizada em Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":">","MÍNIMO":5,"MÁXIMO":null,"CONDIÇÃO":"Quando  não criar espécies alóctones e/ou exóticas; e não estiver localizada em Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Tanques-rede (quando não criar espécies alóctones e/ou exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":">","MÍNIMO":10000,"MÁXIMO":null,"CONDIÇÃO":"Quando não criar espécies alóctones e/ou exóticas","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Tanques-rede (quando criar espécies alóctones e/ou exótica)","CNAE":"0322-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Quando criar espécies alóctones e/ou exóticas","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"MINERAÇÃO","ATIVIDADE":"Pelotização, sinterização e outros beneficiamentos de minério de ferro","CNAE":"0710-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"MINERAÇÃO","ATIVIDADE":"Extração Mineral sobre regime de Lavra Garimpeira","CNAE":"0724-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"MINERAÇÃO","ATIVIDADE":"Extração e beneficiamento de bens minerais de qualquer espécie","CNAE":"0810-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"MINERAÇÃO","ATIVIDADE":"Extração e envase água mineral","CNAE":"0899-1/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Abatedouro de animais da fauna silvestre nativa ou exótica","CNAE":"4722-9","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Curtume de produtos da fauna silvestre nativa ou exótica","CNAE":"1510-6","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Abatedouro de Grande Porte (bovinos e bubalinos)","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":">","MÍNIMO":70,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Frigorífico de produtos de origem da fauna silvestre nativa ou exótica","CNAE":"1012-1","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/06","UNIDADE":"cabeças/dia","OPERADOR":">","MÍNIMO":10,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Preparação de subprodutos do abate","CNAE":"1013-9/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação subprodutos de origem animal","CNAE":"1013-9/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Processamento de peixes/Fabricação de Produtos de Pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de conservas de frutas","CNAE":"1031-7/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de óleos vegetais em bruto, exceto óleo de milho","CNAE":"1041-4/00","UNIDADE":"t/dia","OPERADOR":">","MÍNIMO":5,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de óleos vegetais refinados, exceto óleo de milho","CNAE":"1042-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de margarina e outras gorduras vegetais e de óleos não comestíveis de animais","CNAE":"1043-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":15},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Refino e fabricação de margarinas e outras gorduras vegetais de óleo não comestíveis de animais","CNAE":"1043-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de Laticínios","CNAE":"1052-0/01","UNIDADE":"litros/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Beneficiamento de Arroz com parboilização","CNAE":"1061-9/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de amidos e féculas de vegetais","CNAE":"1065-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de óleo de milho em bruto","CNAE":"1065-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de óleo de milho refinado","CNAE":"1065-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Moagem e fabricação de produtos de origem vegetal não especificados anteriormente","CNAE":"1069-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de açúcar","CNAE":"1071-6/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":3000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de biscoitos e bolachas, em escala industrial","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates, em escala industrial","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes, em escala industrial","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de massas alimentícias, em escala industrial","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos, em escala industrial","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de pós-alimentícios","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação, retificação, homogeneização e mistura de aguardente e bebidas","CNAE":"1111-9/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outras aguardentes e bebidas destiladas (Artesanal)","CNAE":"1111-9/03","UNIDADE":"litros/dia","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de vinhos e vinagres","CNAE":"1112-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de malte, inclusive malte uísque","CNAE":"1113-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cervejas e chopes","CNAE":"1113-5/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de refrigerantes","CNAE":"1122-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de bebidas isotônicas","CNAE":"1122-4/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outras bebidas não alcoólicas não especificadas anteriormente","CNAE":"1122-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cigarros","CNAE":"1220-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cigarrilhas e charutos","CNAE":"1220-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de filtros para cigarros","CNAE":"1220-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros produtos do fumo, exceto cigarros, cigarrilhas e charutos","CNAE":"1220-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Deslintamento de Caroço de Algodão","CNAE":"1311-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Esmagadora de Caroço de Algodão ou Grãos","CNAE":"1311-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fiação de fibras artificiais e sintéticas","CNAE":"1313-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Estamparia e texturização em fios, tecidos, artefatos têxteis e peças do vestuário","CNAE":"1340-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Curtimento e outras preparações de couro","CNAE":"1510-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Serrarias com desdobramento de madeira em bruto","CNAE":"1610-2/03","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Com desdobramento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Serrarias sem desdobramento de madeira em bruto","CNAE":"1610-2/04","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Sem desdobramento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Tratamento Químico para Preservação de Madeira","CNAE":"1610-2/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Serraria com desdobro e beneficiamento de madeira","CNAE":"1610-2/07","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":"Com desdobro e beneficiamento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Resserragem/Redimensionamento","CNAE":"1610-2/09","UNIDADE":"m³","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de casas de madeira pré-fabricadas","CNAE":"1622-6/01","UNIDADE":"m³/ano","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais","CNAE":"1622-6/02","UNIDADE":"m³/ano","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros artigos de carpintaria para construção","CNAE":"1622-6/99","UNIDADE":"m³/ano","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de celulose e outras pastas para a fabricação de papel","CNAE":"1710-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de papel","CNAE":"1721-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cartolina e papel-cartão","CNAE":"1722-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos do refino de petróleo","CNAE":"1921-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Formulação de combustíveis","CNAE":"1922-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros produtos derivados do petróleo, exceto produtos do refino","CNAE":"1922-5/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de álcool","CNAE":"1931-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de Biocombustíveis","CNAE":"1932-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":16},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de combustíveis derivados de resíduos (CDR ou RSUE)","CNAE":"1932-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cloro e álcalis","CNAE":"2011-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de intermediários para fertilizantes","CNAE":"2012-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de biofertilizantes e inoculantes, e outros fertilizantes","CNAE":"2013-4/02","UNIDADE":"t/dia","OPERADOR":">","MÍNIMO":10,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros produtos químicos inorgânicos não especificados anteriormente","CNAE":"2019-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos petroquímicos básicos","CNAE":"2021-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos químicos orgânicos não especificados anteriormente","CNAE":"2029-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de resinas termofixas E resinas termoplásticas","CNAE":"2031-2/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de elastômeros, EPS e similares","CNAE":"2033-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de fibras artificiais e sintéticas","CNAE":"2040-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de defensivos agrícolas: Químicos e/ou Biológicos - Fungicidas, Herbicidas, Inseticidas e Bioinoculantes","CNAE":"2051-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de desinfetantes domissanitários","CNAE":"2052-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de sanitizantes","CNAE":"2061-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de Tintas, vernizes, esmaltes e lacas","CNAE":"2071-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de tintas de impressão","CNAE":"2072-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de impermeabilizantes, solventes e produtos afins","CNAE":"2073-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de pólvoras, explosivos e detonantes","CNAE":"2092-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de artigos pirotécnicos","CNAE":"2092-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de catalisadores","CNAE":"2094-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros produtos químicos não especificados anteriormente","CNAE":"2099-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de pneumáticos e de câmaras-de-ar","CNAE":"2211-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de artefatos de borracha","CNAE":"2219-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de vidros em geral","CNAE":"2311-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de Cimento","CNAE":"2320-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de azulejos e pisos","CNAE":"2342-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de artefatos de cerâmica e barro cozido para uso na construção, exceto azulejos e pisos","CNAE":"2342-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de abrasivos","CNAE":"2399-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outros produtos de minerais não metálicos não especificados anteriormente","CNAE":"2399-1/99","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de semiacabados de aço","CNAE":"2421-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de relaminados, trefilados e perfilados de aço, exceto arames","CNAE":"2424-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de tubos de aço com e sem costura","CNAE":"2431-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de outros tubos de ferro e aço","CNAE":"2439-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de alumínio e suas ligas em formas primárias","CNAE":"2441-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Metalurgia do cobre","CNAE":"2443-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Produção de zinco em formas primárias","CNAE":"2449-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Metalurgia de outros metais não ferrosos e suas ligas não especificados anteriormente","CNAE":"2449-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fundição de ferro e aço","CNAE":"2451-2/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fundição de metais não ferrosos e suas ligas","CNAE":"2452-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de estruturas metálicas","CNAE":"2511-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de obras de caldeiraria pesada","CNAE":"2513-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de tanques, reservatórios metálicos e caldeiras para aquecimento central","CNAE":"2521-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de caldeiras geradoras de vapor, exceto para aquecimento central e para veículos","CNAE":"2522-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Metalurgia do pó","CNAE":"2532-2/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de artigos de cutelaria","CNAE":"2541-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de móveis e artefatos de metais, exceto fundição","CNAE":"2542-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de ferramentas","CNAE":"2543-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de equipamento bélico pesado, exceto veículos militares de combate","CNAE":"2550-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de armas de fogo, outras armas e munições","CNAE":"2550-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Serviços de confecção de armações metálicas para a construção","CNAE":"2599-3/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Serviço de corte e dobra de metais","CNAE":"2599-3/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de aparelhos eletromédicos e eletroterapêuticos e equipamentos de irradiação","CNAE":"2660-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de baterias e acumuladores para veículos automotores","CNAE":"2722-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Recondicionamento de baterias e acumuladores para veículos automotores","CNAE":"2722-8/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de fios, cabos e condutores elétricos isolados","CNAE":"2733-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de lâmpadas","CNAE":"2740-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de luminárias e outros equipamentos de iluminação","CNAE":"2740-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":17},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de fogões, refrigeradores e máquinas de lavar e secar para uso doméstico, peças e acessórios","CNAE":"2751-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de eletrodos, contatos e outros artigos de carvão e grafita para uso elétrico, eletroímãs e isoladores","CNAE":"2790-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de equipamentos elétricos e eletrônicos","CNAE":"2790-2/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de motores e turbinas, peças e acessórios, exceto para aviões e veículos rodoviários","CNAE":"2811-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de equipamentos hidráulicos e pneumáticos, peças e acessórios, exceto válvulas","CNAE":"2812-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de compressores para uso industrial e não industrial, peças e acessórios","CNAE":"2814-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de fornos industriais, aparelhos e equipamentos não elétricos para instalações térmicas, peças e acessórios","CNAE":"2821-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas, equipamentos e aparelhos para transporte e elevação de cargas, peças e acessórios","CNAE":"2822-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e aparelhos de refrigeração e ventilação para uso industrial e comercial, peças e acessórios","CNAE":"2823-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e equipamentos para saneamento básico e ambiental, peças e acessórios","CNAE":"2825-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outras máquinas e equipamentos de uso geral não especificados anteriormente, peças e acessórios","CNAE":"2829-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de tratores agrícolas, peças e acessórios","CNAE":"2831-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de equipamentos para irrigação agrícola, peças e acessórios","CNAE":"2832-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e equipamentos para a agricultura e pecuária, peças e acessórios, exceto para irrigação","CNAE":"2833-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas-ferramenta, peças e acessórios","CNAE":"2840-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de outras máquinas e equipamentos para uso na extração mineral, peças e acessórios, exceto na extração de petróleo","CNAE":"2852-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de tratores, peças e acessórios, exceto agrícolas","CNAE":"2853-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e equipamentos para terraplenagem, pavimentação e construção, peças e acessórios, exceto tratores","CNAE":"2854-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas para a indústria metalúrgica, peças e acessórios, exceto máquinas-ferramenta","CNAE":"2861-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e equipamentos para a indústria","CNAE":"2863-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de máquinas e equipamentos para uso industrial específico não especificados anteriormente, peças e acessórios","CNAE":"2869-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de automóveis, camionetas e utilitários","CNAE":"2910-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de chassis com motor para automóveis, camionetas e utilitários","CNAE":"2910-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de motores para automóveis, camionetas e utilitários","CNAE":"2910-7/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de caminhões e ônibus","CNAE":"2920-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de motores para caminhões e ônibus","CNAE":"2920-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de carrocerias para ônibus","CNAE":"2930-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus","CNAE":"2930-1/03","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Construção de embarcações de grande porte","CNAE":"3011-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Construção de embarcações para uso comercial e para usos especiais, exceto de grande porte","CNAE":"3011-3/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de locomotivas, vagões e outros materiais rodantes","CNAE":"3031-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de peças e acessórios para veículos ferroviários","CNAE":"3032-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de aeronaves","CNAE":"3041-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de turbinas, motores e outros componentes e peças para aeronaves","CNAE":"3042-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de veículos militares de combate","CNAE":"3050-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de motocicletas","CNAE":"3091-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de peças e acessórios para motocicletas","CNAE":"3091-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de bicicletas e triciclos não motorizados, peças e acessórios","CNAE":"3092-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de equipamentos de transporte não especificados anteriormente","CNAE":"3099-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de móveis e artefatos de metais, exceto fundição","CNAE":"3102-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de espumas e colchões","CNAE":"3104-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de canetas, lápis e outros artigos para escritório","CNAE":"3299-0/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação de produtos diversos não especificados anteriormente","CNAE":"3299-0/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INDÚSTRIA DE TRANSFORMAÇÃO","ATIVIDADE":"Fabricação, manutenção e reparação de carrinhos de supermercados","CNAE":"3314-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Parque Eólico / Usina Eólica / Central Eólica e Usina por meio de fonte solar para sistemas helitérmicos e fotovoltaicos","CNAE":"3511-5/02","UNIDADE":"MWh","OPERADOR":">","MÍNIMO":30,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Subestação Abaixadora de Tensão / Seccionadora","CNAE":"3511-5/03","UNIDADE":"kV","OPERADOR":">","MÍNIMO":230,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Central Geradora Hidrelétrica - CGH","CNAE":"3511-5/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Pequena Central Hidrelétrica - PCH","CNAE":"3511-5/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Unidade de Cogeração de Energia Elétrica","CNAE":"3511-5/06","UNIDADE":"MW","OPERADOR":">","MÍNIMO":1,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Usina Hidrelétrica","CNAE":"3511-5/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":18},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Usina Termoelétrica, inclusive Móvel","CNAE":"3511-5/08","UNIDADE":"MW","OPERADOR":">","MÍNIMO":0.5,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Linha de transmissão e/ou de Distribuição","CNAE":"3512-3/00","UNIDADE":"kV","OPERADOR":">","MÍNIMO":230,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Captação, adução, tratamento e distribuição de água - ETA","CNAE":"3600-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Barramento de curso ou massa de água para múltiplos usos dissociados de atividades licenciadas","CNAE":"4329-1/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Coleta e tratamento de esgoto - ETE","CNAE":"3701-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Estação de transferência (transbordo) de resíduos sólidos urbanos","CNAE":"3811-4/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Centrais e Postos de recebimento de embalagens de agrotóxicos e afins, vazias ou contendo resíduos pós-consumo","CNAE":"3812-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário e/ou reciclagem de óleo","CNAE":"3821-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem de resíduos sólidos","CNAE":"3821-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Produção de composto oriundo de resíduos industriais e/ou urbanos","CNAE":"3821-1/03","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aterro para resíduos não perigosos - classe II, de origem industrial","CNAE":"3821-1/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aterro sanitário de resíduos sólidos urbanos","CNAE":"3821-1/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Tratamento e disposição final de resíduos oriundos de fossas","CNAE":"3821-1/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aterros de resíduos da construção civil (RCC)","CNAE":"3821-1/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Área de Transbordo e Triagem (ATT) e/ou Reciclagem de resíduos da construção civil (RCC)","CNAE":"3821-1/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Incineração de resíduos","CNAE":"3821-1/09","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Tratamento térmico de resíduos (pirólise, gaseificação e quaisquer outras tecnologias)","CNAE":"3821-1/10","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Coprocessamento de resíduos","CNAE":"3821-1/11","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos perigosos - classe I","CNAE":"3822-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe I","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aterro para resíduos perigosos - classe I, de origem industrial","CNAE":"3822-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe I","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem de embalagens de agrotóxicos","CNAE":"3822-0/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem de pilhas, baterias e acumuladores","CNAE":"3822-0/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem/Descontaminação de lâmpadas","CNAE":"3822-0/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem ou regeneração de produtos químicos","CNAE":"3822-0/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem de resíduos eletroeletrônicos","CNAE":"3822-0/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem ou regeneração de outros materiais não classificados ou não especificados, exceto produtos químicos","CNAE":"3822-0/09","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Autoclavagem de resíduos de serviços de saúde","CNAE":"3822-0/10","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Incineração de resíduos de serviços de saúde","CNAE":"3822-0/11","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Unidade de mistura e pré-condicionamento de resíduos para co-processamento em fornos de clínquer","CNAE":"3822-0/12","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Rerrefino de óleos lubrificantes usados","CNAE":"3822-0/13","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Outras formas de tratamento ou de disposição de resíduos não listadas ou não classificadas","CNAE":"3822-0/14","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Compostagem de resíduos sólidos orgânicos (exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos)","CNAE":"3839-4/02","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":"Exceto resíduos de origem industrial, de confinamentos, lodos e animais mortos","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Compostagem de resíduos sólidos orgânicos (inclusive resíduo de origem industrial, de confinamentos, lodos e animais mortos)","CNAE":"3839-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Inclusive resíduos de origem industrial, de confinamentos, lodos e animais mortos","NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Conjuntos residenciais horizontais","CNAE":"4120-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Conjuntos residenciais verticais","CNAE":"4120-4/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Shoppings centers","CNAE":"4120-4/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Campus universitário","CNAE":"4120-4/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Edificações (residenciais, industriais, comerciais e de serviços)","CNAE":"4120-4/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Implantação e pavimentação de obras viárias (rodovias, estradas vicinais e vias férreas)","CNAE":"4211-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes, e demais obras de arte","CNAE":"4211-1/04","UNIDADE":"m","OPERADOR":">","MÍNIMO":60,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Autódromos","CNAE":"4211-1/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aeroportos","CNAE":"4211-1/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aeródromos","CNAE":"4211-1/09","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Obras de urbanização de orlas fluviais ou lacustre","CNAE":"4213-8/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de redes de esgoto com emissários, coletores tronco, elevatórias, inclusive de interceptores","CNAE":"4222-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de redes de Transportes por dutos","CNAE":"4222-7/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de redes de abastecimento de água","CNAE":"4222-7/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Obras portuárias, marítimas e fluviais","CNAE":"4291-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Canalização de cursos d\'água","CNAE":"4291-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Retificação de cursos d\'água","CNAE":"4291-0/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Hidrovias, abertura de canais para navegação","CNAE":"4291-0/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Transposição de bacias hidrográficas","CNAE":"4291-0/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Canalização de córregos","CNAE":"4291-0/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Obras de dragagem e derrocamento","CNAE":"4291-0/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Montagem de estruturas metálicas","CNAE":"4292-8/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Parcelamento de Solo","CNAE":"4299-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Muros de contenção em APP","CNAE":"4299-5/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Obras de Drenagem de solos","CNAE":"4319-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":19},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio Atacadista de Combustível - Exceto Transportador Retalhista (TRR) e Lubrificantes","CNAE":"4681-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio Atacadista de Combustíveis Realizado por Transportador Retalhista (TRR)","CNAE":"4681-8/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Posto de Abastecimento - (tanque aéreo)","CNAE":"4681-8/06","UNIDADE":"m³","OPERADOR":">","MÍNIMO":15,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Posto de Abastecimento - (tanque enterrado)","CNAE":"4681-8/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio a Varejo de Combustíveis e Lubrificantes Para Veículos Automotores","CNAE":"4731-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Transporte rodoviário de produtos perigosos","CNAE":"4930-2/03","UNIDADE":"veículos","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Armazéns de Produtos Perigosos","CNAE":"5211-7/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Hotéis e pousadas - em áreas de interesse ambiental","CNAE":"5510-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Atividades de Atendimento Hospitalar","CNAE":"8610-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Complexos turísticos e de lazer, inclusive parques temáticos","CNAE":"9321-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Cemitérios","CNAE":"9603-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Serviços de cremação de cadáveres humanos e animais","CNAE":"9603-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Atividades de Somatoconservação - Tanatopraxia","CNAE":"9603-3/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Centro de triagem e reabilitação de animais silvestres","CNAE":"7500-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Empreendimento comercial de partes, produtos e subprodutos da fauna silvestre ou exótica","CNAE":"4611-7; 4643-5; 4781-4","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"II","MODALIDADE":"LP+LI+LO","GRUPO":"SERVIÇOS","ATIVIDADE":"Empreendimento comercial de animais vivos da fauna silvestre nativa ou da fauna exótica","CNAE":"4611-7; 4724-5; 4789-0/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Tratamento de Sementes","CNAE":"0141-5/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite","CNAE":"0151-2/02","UNIDADE":"cabeças/ciclo","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":300,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/02","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":101,"MÁXIMO":300,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Avicultura de corte","CNAE":"0155-5/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":30001,"MÁXIMO":150000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de pintos de um dia (Incubatório)","CNAE":"0155-5/02","UNIDADE":"pintinhos/mês","OPERADOR":null,"MÍNIMO":500001,"MÁXIMO":1500000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (Postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":50001,"MÁXIMO":150000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Unidade de Inspeção e Classificação de ovos","CNAE":"0155-5/06","UNIDADE":"dúzias/dia","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Sistemas de irrigação","CNAE":"4222-7/02","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Convencional em tanques escavados (não admitida criação de espécies alóctones e/ou exóticas; e desde que fora de Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":null,"MÍNIMO":1.1,"MÁXIMO":5,"CONDIÇÃO":"Quando  não criar espécies alóctones e/ou exóticas; e não estiver localizada em Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Tanques-rede (não admitida criação de espécies alóctones e exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":10000,"CONDIÇÃO":"Quando não criar espécies alóctones e/ou exóticas","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de peixes ornamentais de água doce","CNAE":"0322-1/04","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":201,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Abatedouro de Grande Porte (bovinos e bubalinos)","CNAE":"1011-2/01","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":70,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de ovinos e caprinos","CNAE":"1011-2/03","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de animais de diversas espécies, exceto silvestres","CNAE":"1011-2/06","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":10,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Abate de aves","CNAE":"1012-1/01","UNIDADE":"aves/dia","OPERADOR":null,"MÍNIMO":30,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Frigorífico - abate de suínos","CNAE":"1012-1/03","UNIDADE":"cabeças/dia","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de Produtos de Pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de frutas","CNAE":"1031-7/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sucos concentrados de frutas, hortaliças e legumes","CNAE":"1033-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de óleos vegetais em bruto, exceto óleo de milho","CNAE":"1041-4/00","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Preparação do Leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":">","MÍNIMO":5000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de Laticínios","CNAE":"1052-0/00","UNIDADE":"litros/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos do arroz","CNAE":"1061-9/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":20},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Moagem de trigo e fabricação de derivados","CNAE":"1062-7/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":750,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de mandioca e derivados","CNAE":"1063-5/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":750,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de milho e derivados, exceto óleos de milho","CNAE":"1064-3/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":750,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de Ração","CNAE":"1066-0/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Unidade de Processamento Castanhas, Amêndoas e Grãos","CNAE":"1069-4/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":400,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de açúcar","CNAE":"1071-6/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":3000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de café","CNAE":"1081-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Torrefação e moagem de café","CNAE":"1081-3/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":201,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas, em escala industrial","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates, em escala industrial","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes, em escala industrial","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":201,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias, em escala industrial","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos, em escala industrial","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":">","MÍNIMO":100,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós-alimentícios","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fermentos, leveduras, fungos e algas","CNAE":"1099-6/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos para infusão (chá, mate, etc.)","CNAE":"1099-6/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adoçantes naturais e artificiais","CNAE":"1099-6/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos dietéticos e complementos alimentares","CNAE":"1099-6/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos alimentícios não especificados anteriormente","CNAE":"1099-6/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outras aguardentes e bebidas destiladas (Artesanal)","CNAE":"1111-9/03","UNIDADE":"litros/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cervejas e chopes","CNAE":"1113-5/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chá mate e outros chás prontos para consumo","CNAE":"1122-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento e descaroçamento de algodão","CNAE":"1311-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fiação de fibras artificiais e sintéticas","CNAE":"1313-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de linhas para costurar e bordar","CNAE":"1314-6/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de algodão","CNAE":"1321-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras artificiais e sintéticas","CNAE":"1323-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tapeçaria","CNAE":"1352-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cordoaria","CNAE":"1353-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos especiais, inclusive artefatos","CNAE":"1354-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos têxteis não especificados anteriormente","CNAE":"1359-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos para viagem, bolsas e semelhantes de qualquer material","CNAE":"1521-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de couro","CNAE":"1531-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados anteriormente","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de partes para calçados, de qualquer material","CNAE":"1540-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Serrarias com desdobramento de madeira em bruto","CNAE":"1610-2/03","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Com desdobramento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Serrarias sem desdobramento de madeira em bruto","CNAE":"1610-2/04","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Sem desdobramento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de Cavaco de Madeira","CNAE":"1610-2/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Serraria com desdobro e beneficiamento de madeira","CNAE":"1610-2/07","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":5000,"CONDIÇÃO":"Com desdobro e beneficiamento","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Desdobro com motosserra","CNAE":"1610-2/08","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Resserragem/Redimensionamento","CNAE":"1610-2/09","UNIDADE":"m³","OPERADOR":null,"MÍNIMO":1001,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de madeira laminada e de chapas de madeira compensada, prensada e aglomerada","CNAE":"1621-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas de madeira pré-fabricadas","CNAE":"1622-6/01","UNIDADE":"m³/ano","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais","CNAE":"1622-6/02","UNIDADE":"m³/ano","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artigos de carpintaria para construção","CNAE":"1622-6/99","UNIDADE":"m³/ano","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de tanoaria e de embalagens de madeira","CNAE":"1623-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Picador Fixo","CNAE":"1629-3/04","UNIDADE":"m³","OPERADOR":">","MÍNIMO":10000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Picador móvel florestal","CNAE":"1629-3/05","UNIDADE":"m³","OPERADOR":">","MÍNIMO":50000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Trituração e/ou secagem de biomassa, com ou sem produção de briquetes","CNAE":"1629-3/07","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de cartolina e papel-cartão","CNAE":"1732-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas e de embalagens de papelão ondulado","CNAE":"1733-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel para uso doméstico e higiênico-sanitário não especificados anteriormente","CNAE":"1742-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":21},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes organo-minerais","CNAE":"2013-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adubos e fertilizantes, exceto organo-minerais","CNAE":"2013-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biofertilizantes e inoculantes, e outros fertilizantes","CNAE":"2013-4/03","UNIDADE":"t/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases","CNAE":"2014-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação e envase de gases industriais","CNAE":"2014-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Usinas fixas e móveis de asfalto a quente ou frio (betume ou outro material)","CNAE":"2021-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de intermediários para plastificantes, resinas e fibras","CNAE":"2022-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos químicos orgânicos não especificados anteriormente","CNAE":"2029-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de resinas termofixas E resinas termoplásticas","CNAE":"2031-2/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sabões e detergentes sintéticos","CNAE":"2061-4/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tintas de impressão","CNAE":"2072-0/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de adesivos e selantes","CNAE":"2091-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fósforos de segurança","CNAE":"2092-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aditivos de uso industrial","CNAE":"2093-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de chapas, filmes, papéis e outros materiais e produtos químicos para fotografia","CNAE":"2099-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de medicamentos para uso veterinário","CNAE":"2122-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pneumáticos e de câmaras-de-ar","CNAE":"2211-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Reforma de pneumáticos usados","CNAE":"2212-9/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de borracha","CNAE":"2219-6/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de laminados planos e tubulares de material plástico","CNAE":"2221-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de material plástico","CNAE":"2221-8/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de material plástico","CNAE":"2222-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tubos e acessórios de material plástico para uso na construção","CNAE":"2223-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso pessoal e doméstico","CNAE":"2229-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para usos industriais","CNAE":"2229-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para uso na construção, exceto tubos e acessórios","CNAE":"2229-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de material plástico para outros usos não especificados anteriormente","CNAE":"2229-3/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas pré-moldadas de concreto armado, em série e sob encomenda","CNAE":"2330-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cimento para uso na construção","CNAE":"2330-3/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de fibrocimento para uso na construção","CNAE":"2330-3/03","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas pré-moldadas de concreto","CNAE":"2330-3/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Usinagem e Preparação de massa de concreto e argamassa para construção","CNAE":"2330-3/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes","CNAE":"2330-3/99","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos refratários","CNAE":"2341-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material sanitário de cerâmica","CNAE":"2349-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos cerâmicos não refratários não especificados anteriormente","CNAE":"2349-4/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Britamento de pedras, exceto associado à extração","CNAE":"2391-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de pedras para construção, exceto associado à extração","CNAE":"2391-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Aparelhamento de placas, e execução de trabalhos em mármore, granito, ardósia e outros materiais","CNAE":"2391-5/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":251,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de minerais não metálicos não especificados anteriormente","CNAE":"2399-1/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Produção de arames de aço","CNAE":"2424-5/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Produção de alumínio e suas ligas em formas primárias","CNAE":"2441-5/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":501,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Metalurgia dos metais preciosos","CNAE":"2442-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de ânodos para galvanoplastia","CNAE":"2449-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fundição de ferro e aço","CNAE":"2451-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas","CNAE":"2511-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estruturas metálicas (sem usinagem)","CNAE":"2511-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Sem usinagem","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de esquadrias de metal","CNAE":"2512-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de obras de caldeiraria pesada","CNAE":"2513-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Produção de artefatos estampados de metal","CNAE":"2532-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Metalurgia do pó","CNAE":"2532-2/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":2000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Serviços de usinagem, tornearia e solda","CNAE":"2539-0/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":2500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Jateamento de peças","CNAE":"2539-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de serralheria","CNAE":"2542-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens metálicas","CNAE":"2591-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal padronizados","CNAE":"2592-6/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de trefilados de metal, exceto padronizados","CNAE":"2592-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"ALTO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artigos de metal para uso doméstico e pessoal","CNAE":"2593-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros produtos de metal não especificados anteriormente","CNAE":"2599-3/99","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de informática","CNAE":"2621-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de periféricos para equipamentos de informática","CNAE":"2622-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos transmissores de comunicação, peças e acessórios","CNAE":"2631-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos telefônicos e de outros equipamentos de comunicação, peças e acessórios","CNAE":"2632-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cronômetros e relógios","CNAE":"2652-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e instrumentos ópticos, peças e acessórios","CNAE":"2670-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":22},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de geradores de corrente contínua e alternada, peças e acessórios","CNAE":"2710-4/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de transformadores, indutores, conversores, sincronizadores e semelhantes, peças e acessórios","CNAE":"2710-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de motores elétricos, peças e acessórios","CNAE":"2710-4/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pilhas, baterias e acumuladores elétricos, exceto para veículos automotores","CNAE":"2721-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos para distribuição e controle de energia elétrica","CNAE":"2731-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico para instalações em circuito de consumo","CNAE":"2732-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros aparelhos eletrodomésticos não especificados anteriormente, peças e acessórios","CNAE":"2759-7/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros equipamentos e aparelhos elétricos não especificados anteriormente","CNAE":"2790-2/99","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de válvulas, registros e dispositivos semelhantes, peças e acessórios","CNAE":"2813-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos de transmissão para fins industriais, exceto rolamentos","CNAE":"2815-1/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de estufas e fornos elétricos para fins industriais, peças e acessórios","CNAE":"2821-6/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de aparelhos e equipamentos de ar condicionado para uso industrial e não industrial","CNAE":"2824-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de máquinas de escrever, calcular e outros equipamentos não eletrônicos para escritório, peças e acessórios","CNAE":"2829-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus","CNAE":"2930-1/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema motor de veículos automotores","CNAE":"2941-7/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para os sistemas de marcha e transmissão de veículos automotores","CNAE":"2942-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de freios de veículos automotores","CNAE":"2943-3/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de peças e acessórios para o sistema de direção e suspensão de veículos automotores","CNAE":"2944-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de material elétrico e eletrônico para veículos automotores, exceto baterias","CNAE":"2945-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de bancos e estofados para veículos automotores","CNAE":"2949-2/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Recondicionamento e recuperação de motores para veículos automotores","CNAE":"2950-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Construção de embarcações para uso comercial e para usos especiais, exceto de grande porte","CNAE":"3011-3/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis de outros materiais, exceto madeira e metal","CNAE":"3103-9/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos musicais, peças e acessórios","CNAE":"3220-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos não eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório","CNAE":"3250-7/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos para pesca e esporte","CNAE":"3230-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de roupas de proteção e segurança e resistentes a fogo","CNAE":"3292-2/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de equipamentos e acessórios para segurança pessoal e profissional","CNAE":"3292-2/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de guarda-chuvas e similares","CNAE":"3299-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de canetas, lápis e outros artigos para escritório","CNAE":"3299-0/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Parque Eólico / Usina Eólica / Central Eólica e Usina por meio de fonte solar para sistemas helitérmicos e fotovoltaicos","CNAE":"3511-5/02","UNIDADE":"MWh","OPERADOR":null,"MÍNIMO":5.1,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Subestação Abaixadora de Tensão / Seccionadora","CNAE":"3511-5/03","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Linha de transmissão e/ou de Distribuição","CNAE":"3512-3/00","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":138.1,"MÁXIMO":230,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Usina Termoelétrica, inclusive Móvel","CNAE":"3511-5/08","UNIDADE":"MW","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":0.5,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Coleta de resíduos não perigosos (Transportadora de Resíduos Urbanos)","CNAE":"3811-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Transportadoras de resíduos - classe II","CNAE":"3811-4/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II ","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Limpeza, coleta e transporte de resíduos por veículos “limpa fossa”","CNAE":"3811-4/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Central de triagem de resíduos sólidos urbanos","CNAE":"3821-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Reciclagem de resíduos não perigosos","CNAE":"3821-1/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Produção de composto oriundo de resíduos industriais e/ou urbanos","CNAE":"3821-1/03","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos não perigosos - classe II","CNAE":"3821-1/12","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe II ","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Armazenamento temporário de resíduos de construção civil classe A - bota fora","CNAE":"3821-1/13","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe A","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Compostagem de resíduos sólidos orgânicos (exceto resíduo de origem industrial, de confinamentos, lodos e animais mortos)","CNAE":"3839-4/02","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":"Exceto resíduos de origem industrial, de confinamentos, lodos e animais mortos","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Pátio de descontaminação","CNAE":"3900-5/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes, e demais obras de arte","CNAE":"4211-1/04","UNIDADE":"m","OPERADOR":null,"MÍNIMO":30.1,"MÁXIMO":60,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Aberturas de vias internas em áreas rurais (com desmate)","CNAE":"4211-1/10","UNIDADE":"m","OPERADOR":">","MÍNIMO":6,"MÁXIMO":null,"CONDIÇÃO":"Com desmate","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Pavimentação urbana e drenagem de águas pluviais urbanas","CNAE":"4213-8/01","UNIDADE":"m","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Canteiro de obras","CNAE":"4299-5/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de Muro de Contenção em áreas de risco ou uso restrito","CNAE":"4299-5/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio Atacadista de Gás Liquefeito de Petróleo (GLP)","CNAE":"4682-6/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio Varejista de Gás Liqüefeito de Petróleo (GLP)","CNAE":"4784-9/00","UNIDADE":"Classe ANP","OPERADOR":">=","MÍNIMO":4,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Montagem de estruturas metálicas","CNAE":"4292-8/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Transporte rodoviário de produtos perigosos","CNAE":"4930-2/03","UNIDADE":"veículos","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Transporte de resíduos - classe I. (Que realizem a Coleta e/ou transporte)","CNAE":"4930-2/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe I","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":23},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Transporte de resíduos de serviços de saúde - classe I. (Que realizem a Coleta e/ou transporte)","CNAE":"4930-2/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":"Classe I","NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Restaurantes - em áreas de interesse ambiental","CNAE":"5510-8/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Atividades de serviços de complementação diagnósticos ou terapêutica, laboratório de anatomia patologia; laboratório: de análises clínicas, serviços de raio-x, radioterapia, serviços de quimioterapia, serviço de banco de sangue, etc","CNAE":"8640-2/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"III","MODALIDADE":"LAS","GRUPO":"SERVIÇOS","ATIVIDADE":"Tinturarias","CNAE":"9601-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bovinos de corte confinados","CNAE":"0151-2/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Bovinocultura, bubalinocultura e caprinocultura de leite","CNAE":"0151-2/02","UNIDADE":"cabeças/ciclo","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de bubalinos de corte confinados","CNAE":"0152-1/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de equinos de corte confinados","CNAE":"0152-1/02","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de asininos e muares de corte confinados","CNAE":"0152-1/03","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de caprinos de corte confinados","CNAE":"0153-9/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (unidade de produção de leitões)","CNAE":"0154-7/00","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":20,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (crescimento e terminação)","CNAE":"0154-7/01","UNIDADE":"cabeças","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Suinocultura (ciclo completo)","CNAE":"0154-7/02","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":10,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Produção de ovos (Postura)","CNAE":"0155-5/05","UNIDADE":"matrizes","OPERADOR":null,"MÍNIMO":10000,"MÁXIMO":50000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Convencional em tanques escavados (não admitida criação de espécies alóctones e/ou exóticas; e desde que fora de Área de Preservação Permanente)","CNAE":"0322-1/01","UNIDADE":"ha","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1,"CONDIÇÃO":"Quando  não criar espécies alóctones e/ou exóticas; e não estiver localizada em Área de Preservação Permanente","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Piscicultura Tanques-rede (não admitida criação de espécies alóctones e/ou exóticas)","CNAE":"0322-1/99","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":"Quando não criar espécies alóctones e/ou exóticas","NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"AGRICULTURA, PECUÁRIA, PRODUÇÃO FLORESTAL, PESCA E AQUICULTURA","ATIVIDADE":"Criação de peixes de água doce","CNAE":"0322-1/04","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de carne, salsicharia e outros embutidos","CNAE":"1013-9/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":50,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Processamento de peixes/Fabricação de Produtos de Pescado","CNAE":"1020-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de peixes, crustáceos e moluscos","CNAE":"1020-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":60,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de conservas de legumes e outros vegetais","CNAE":"1032-5/99","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Preparação do Leite","CNAE":"1051-1/00","UNIDADE":"litros/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":5000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de sorvetes e outros gelados comestíveis","CNAE":"1053-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Beneficiamento de Arroz, exceto parboilização","CNAE":"1061-9/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Moagem de trigo e fabricação de derivados","CNAE":"1062-7/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de mandioca e derivados","CNAE":"1063-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de farinha de milho e derivados, exceto óleos de milho","CNAE":"1064-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":750,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de Ração","CNAE":"1066-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Unidade de processamento castanhas, amêndoas e grãos","CNAE":"1069-4/00","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":400,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos à base de café","CNAE":"1082-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de panificação industrial","CNAE":"1091-1/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de padaria e confeitaria com predominância de produção própria","CNAE":"1091-1/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de biscoitos e bolachas, em escala industrial","CNAE":"1092-9/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos derivados do cacau e de chocolates, em escala industrial","CNAE":"1093-7/01","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":200,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de frutas cristalizadas, balas e semelhantes, em escala industrial","CNAE":"1093-7/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":100,"MÁXIMO":200,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de massas alimentícias, em escala industrial","CNAE":"1094-5/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de especiarias, molhos, temperos e condimentos, em escala industrial","CNAE":"1095-3/00","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de alimentos e pratos prontos","CNAE":"1096-1/00","UNIDADE":"kg/dia","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":100,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de pós-alimentícios","CNAE":"1099-6/02","UNIDADE":"kg/dia","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de gelo comum","CNAE":"1099-6/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":250,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas","CNAE":"1122-4/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Processamento industrial do fumo","CNAE":"1210-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Tecelagem de fios de fibras têxteis naturais, exceto algodão","CNAE":"1322-7/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tecidos de malha","CNAE":"1330-8/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tênis de qualquer material","CNAE":"1532-7/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de material sintético","CNAE":"1533-5/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de calçados de materiais não especificados anteriormente","CNAE":"1539-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Resserragem/Redicionamento","CNAE":"1610-2/09","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de madeira, exceto móveis","CNAE":"1629-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos diversos de cortiça, bambu, palha, vime e outros materiais trançados, exceto móveis","CNAE":"1629-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de Briquetes","CNAE":"1629-3/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Picador Fixo","CNAE":"1629-3/04","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":10000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Picador móvel florestal","CNAE":"1629-3/05","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":50000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Atividade de trituração e/ou secagem de biomassa","CNAE":"1629-3/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de embalagens de papel","CNAE":"1731-1/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório","CNAE":"1741-9/02","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de fraldas descartáveis","CNAE":"1742-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de absorventes higiênicos","CNAE":"1742-7/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente","CNAE":"1749-4/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Impressão de jornais","CNAE":"1811-3/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Impressão de livros, revistas e outras publicações periódicas","CNAE":"1811-3/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos químicos orgânicos não especificados anteriormente","CNAE":"2029-1/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de resinas termofixas e resinas termoplásticas","CNAE":"2031-2/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":24},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos de limpeza e polimento","CNAE":"2062-2/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal","CNAE":"2063-1/00","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de tintas de impressão","CNAE":"2072-0/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de produtos farmoquímicos","CNAE":"2110-6/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de cimento para uso na construção","CNAE":"2330-3/02","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de artefatos de fibrocimento para uso na construção","CNAE":"2330-3/03","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de casas pré-moldadas de concreto","CNAE":"2330-3/04","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes","CNAE":"2330-3/99","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cal e gesso","CNAE":"2392-3/00","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Produção de alumínio e suas ligas em formas primárias","CNAE":"2441-5/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de componentes eletrônicos","CNAE":"2610-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de cabines, carrocerias e reboques para caminhões","CNAE":"2930-1/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de móveis com predominância de madeira","CNAE":"3101-2/00","UNIDADE":"m³","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":1000,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de instrumentos não eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório","CNAE":"3250-7/01","UNIDADE":"m²","OPERADOR":null,"MÍNIMO":250,"MÁXIMO":500,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INDÚSTRIA","ATIVIDADE":"Fabricação de roupas de proteção e segurança e resistentes a fogo","CNAE":"3292-2/01","UNIDADE":"m²","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":250,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Geração distribuída, microgeração e minigeração distribuída, geração compartilhada e autoconsumo remoto; por meio de fonte solar para sistemas helitérmicos e fotovoltaicos","CNAE":"3511-5/01","UNIDADE":"MWh","OPERADOR":null,"MÍNIMO":1,"MÁXIMO":5,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"MÉDIO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Subestação Abaixadora de Tensão / Seccionadora","CNAE":"3511-5/03","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":69,"MÁXIMO":138,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Linha de transmissão e/ou de Distribuição (inclusive RDR)","CNAE":"3514-0/00","UNIDADE":"kV","OPERADOR":null,"MÍNIMO":69,"MÁXIMO":138,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de arena para eventos, auditório, concha acústica, centro de eventos, teatro, anfiteatro e similares","CNAE":"4120-4/00","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estabelecimentos de ensino, como creches, centros de inclusão digital, asilos e similares","CNAE":"4120-4/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1600,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de centros de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares","CNAE":"4120-4/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":1000,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Obras de implantação de praças , ciclovias e calçadas","CNAE":"4213-8/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação de Rodovia e Estrada pavimentada que inclua mudanças de base e sub base","CNAE":"4211-1/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Instalação ou substituição de bueiros tubulares e celulares","CNAE":"4211-1/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção e/ou substituição de pontilhões, pontes, e demais obras de arte","CNAE":"4211-1/04","UNIDADE":"m","OPERADOR":"<=","MÍNIMO":null,"MÁXIMO":30,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Recuperação de Rodovias e estradas vicinais não pavimentadas","CNAE":"4211-1/11","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de passarelas sobre rodovias e vias urbanas e rurais","CNAE":"4212-0/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de estações e redes de telefonia, internet e telecomunicação","CNAE":"4221-9/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Construção de cisternas ou caixas d’água de sistema de abastecimento público","CNAE":"4222-7/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Substituição de redes coletoras de água e esgoto (exceto coletores tronco, emissários e elevatórias de esgoto)","CNAE":"4222-7/06","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Rampas fluviais para embarque e desembarque de pequenas embarcações e pequeno ancoradouro de até 24 metros quadrados","CNAE":"4291-0/02","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"INFRAESTRUTURA","ATIVIDADE":"Implantação de Tablados, píeres e demais estruturas flutuantes sem propulsão","CNAE":"4291-0/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio Atacadista de Defensivos Agrícolas, Adubos, Fertilizantes e Corretivos do Solo com Depósito no Local","CNAE":"4683-4/00","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Comércio varejista de produtos farmacêuticos com manipulação de fórmulas","CNAE":"4771-7/02","UNIDADE":"m²","OPERADOR":">","MÍNIMO":500,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Armazéns gerais (emissão de warrants)","CNAE":"5211-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Instalação de armazém inflável","CNAE":"5211-7/04","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Armazéns de Grãos","CNAE":"5211-7/05","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Banheiros Químicos, aluguel e locação","CNAE":"7739-0/03","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Lavanderias","CNAE":"9601-7/01","UNIDADE":"Todo","OPERADOR":null,"MÍNIMO":null,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Atividades de Clínica Médica (clínicas e consultórios com ambulatório)","CNAE":"8630-5/01","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25},{"ANEXO":"IV","MODALIDADE":"LAC","GRUPO":"SERVIÇOS","ATIVIDADE":"Atividades de Clínica Odontológica","CNAE":"8630-5/04","UNIDADE":"m²","OPERADOR":">","MÍNIMO":200,"MÁXIMO":null,"CONDIÇÃO":null,"NÍVEL DE POLUIÇÃO":"BAIXO","PÁGINA FONTE":25}]')

MUNICIPIOS_GRUPO={'Alta Floresta': 'B', 'Apiacás': 'B', 'Aripuanã': 'B', 'Barra do Garças': 'B', 'Brasnorte': 'B', 'Campinápolis': 'B', 'Campo Novo do Parecis': 'B', 'Campo Verde': 'B', 'Campos de Júlio': 'B', 'Canabrava do Norte': 'B', 'Canarana': 'B', 'Carlinda': 'A', 'Cláudia': 'B', 'Cocalinho': 'B', 'Colíder': 'B', 'Comodoro': 'B', 'Confresa': 'B', "Conquista D'Oeste": 'B', 'Cotriguaçu': 'B', 'Cuiabá': 'C', 'Cáceres': 'B', 'Diamantino': 'B', 'Feliz Natal': 'A', 'Gaúcha do Norte': 'B', 'Guarantã do Norte': 'B', 'Jaciara': 'B', 'Juara': 'B', 'Juína': 'B', 'Lucas do Rio Verde': 'B', 'Marcelândia': 'B', 'Matupá': 'B', 'Nortelândia': 'B', 'Nova Bandeirantes': 'B', 'Nova Maringá': 'B', 'Nova Monte Verde': 'B', 'Nova Mutum': 'B', 'Nova Nazaré': 'B', 'Nova Ubiratã': 'B', 'Nova Xavantina': 'B', 'Paranatinga': 'B', 'Paranaíta': 'B', 'Peixoto de Azevedo': 'B', 'Porto Alegre do Norte': 'B', 'Porto dos Gaúchos': 'B', 'Poxoréu': 'B', 'Primavera do Leste': 'B', 'Querência': 'B', 'Ribeirão Cascalheira': 'B', 'Rondonópolis': 'B', 'Santa Rita do Trivelato': 'B', 'Santa Terezinha': 'B', 'Sapezal': 'B', 'Sinop': 'B', 'Sorriso': 'C', 'São Félix do Araguaia': 'B', 'São José do Xingu': 'B', 'Tangará da Serra': 'C', 'Tapurah': 'B', 'Vera': 'B', 'Vila Bela da Santíssima Trindade': 'B', 'Vila Rica': 'B', 'Várzea Grande': 'B', 'Água Boa': 'B'}
FONTE_DESCENTRALIZACAO='https://www.sema.mt.gov.br/site/index.php/unidades-administrativas/munic%C3%ADpios-descentralizados'
TODOS_MUNICIPIOS_MT=['Acorizal', 'Água Boa', 'Alta Floresta', 'Alto Araguaia', 'Alto Boa Vista', 'Alto Garças', 'Alto Paraguai', 'Alto Taquari', 'Apiacás', 'Araguaiana', 'Araguainha', 'Araputanga', 'Arenápolis', 'Aripuanã', 'Barão de Melgaço', 'Barra do Bugres', 'Barra do Garças', 'Boa Esperança do Norte', 'Bom Jesus do Araguaia', 'Brasnorte', 'Cáceres', 'Campinápolis', 'Campo Novo do Parecis', 'Campo Verde', 'Campos de Júlio', 'Canabrava do Norte', 'Canarana', 'Carlinda', 'Castanheira', 'Chapada dos Guimarães', 'Cláudia', 'Cocalinho', 'Colíder', 'Colniza', 'Comodoro', 'Confresa', "Conquista D'Oeste", 'Cotriguaçu', 'Cuiabá', 'Curvelândia', 'Denise', 'Diamantino', 'Dom Aquino', 'Feliz Natal', "Figueirópolis D'Oeste", 'Gaúcha do Norte', 'General Carneiro', "Glória D'Oeste", 'Guarantã do Norte', 'Guiratinga', 'Indiavaí', 'Ipiranga do Norte', 'Itanhangá', 'Itaúba', 'Itiquira', 'Jaciara', 'Jangada', 'Jauru', 'Juara', 'Juína', 'Juruena', 'Juscimeira', "Lambari D'Oeste", 'Lucas do Rio Verde', 'Luciara', 'Marcelândia', 'Matupá', "Mirassol d'Oeste", 'Nobres', 'Nortelândia', 'Nossa Senhora do Livramento', 'Nova Bandeirantes', 'Nova Brasilândia', 'Nova Canaã do Norte', 'Nova Guarita', 'Nova Lacerda', 'Nova Marilândia', 'Nova Maringá', 'Nova Monte Verde', 'Nova Mutum', 'Nova Nazaré', 'Nova Olímpia', 'Nova Santa Helena', 'Nova Ubiratã', 'Nova Xavantina', 'Novo Horizonte do Norte', 'Novo Mundo', 'Novo Santo Antônio', 'Novo São Joaquim', 'Paranaíta', 'Paranatinga', 'Pedra Preta', 'Peixoto de Azevedo', 'Planalto da Serra', 'Poconé', 'Pontal do Araguaia', 'Ponte Branca', 'Pontes e Lacerda', 'Porto Alegre do Norte', 'Porto dos Gaúchos', 'Porto Esperidião', 'Porto Estrela', 'Poxoréu', 'Primavera do Leste', 'Querência', 'Reserva do Cabaçal', 'Ribeirão Cascalheira', 'Ribeirãozinho', 'Rio Branco', 'Rondolândia', 'Rondonópolis', 'Rosário Oeste', 'Salto do Céu', 'Santa Carmem', 'Santa Cruz do Xingu', 'Santa Rita do Trivelato', 'Santa Terezinha', 'Santo Afonso', 'Santo Antônio do Leste', 'Santo Antônio de Leverger', 'São Félix do Araguaia', 'São José do Povo', 'São José do Rio Claro', 'São José do Xingu', 'São José dos Quatro Marcos', 'São Pedro da Cipa', 'Sapezal', 'Serra Nova Dourada', 'Sinop', 'Sorriso', 'Tabaporã', 'Tangará da Serra', 'Tapurah', 'Terra Nova do Norte', 'Tesouro', 'Torixoréu', 'União do Sul', 'Vale de São Domingos', 'Várzea Grande', 'Vera', 'Vila Bela da Santíssima Trindade', 'Vila Rica']
# v1.15 — decisões de interface da planilha de revisão de condicionantes.
# A numeração LINHA BASE da planilha inclui duas linhas de cabeçalho.
REVISAO_CONDICIONANTES = json.loads('{"7": {"exibir": "NÃO", "observacao": ""}, "8": {"exibir": "NÃO", "observacao": ""}, "9": {"exibir": "NÃO", "observacao": ""}, "12": {"exibir": "NÃO", "observacao": ""}, "13": {"exibir": "NÃO", "observacao": ""}, "14": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "15": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "20": {"exibir": "NÃO", "observacao": ""}, "21": {"exibir": "SIM", "observacao": ""}, "22": {"exibir": "SIM", "observacao": ""}, "24": {"exibir": "SIM", "observacao": ""}, "31": {"exibir": "SIM", "observacao": "Perguntar se tem parboilização. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "35": {"exibir": "SIM", "observacao": "Perguntar se tem óleos de milho. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "43": {"exibir": "NÃO", "observacao": ""}, "49": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "50": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "60": {"exibir": "SIM", "observacao": "Perguntar se tem refresco de fruta. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "65": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "66": {"exibir": "SIM", "observacao": "Perguntar se é de algodão. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "67": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "71": {"exibir": "NÃO", "observacao": ""}, "78": {"exibir": "NÃO", "observacao": ""}, "79": {"exibir": "SIM", "observacao": "Perguntar se tem móveis ou carvoaria. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "80": {"exibir": "SIM", "observacao": "Perguntar se tem móveis. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "86": {"exibir": "NÃO", "observacao": ""}, "103": {"exibir": "NÃO", "observacao": ""}, "112": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "113": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "120": {"exibir": "SIM", "observacao": "Perguntar se é para caminhões ou ônibus. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "121": {"exibir": "NÃO", "observacao": ""}, "122": {"exibir": "NÃO", "observacao": ""}, "123": {"exibir": "SIM", "observacao": "Perguntar se é para azulejos ou pisos. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "131": {"exibir": "SIM", "observacao": "Perguntar se é organominerais. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "135": {"exibir": "NÃO", "observacao": ""}, "142": {"exibir": "SIM", "observacao": "Perguntar se é padronizado. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "147": {"exibir": "NÃO", "observacao": ""}, "148": {"exibir": "NÃO", "observacao": ""}, "149": {"exibir": "NÃO", "observacao": ""}, "150": {"exibir": "NÃO", "observacao": ""}, "152": {"exibir": "NÃO", "observacao": ""}, "160": {"exibir": "NÃO", "observacao": ""}, "162": {"exibir": "NÃO", "observacao": ""}, "163": {"exibir": "NÃO", "observacao": ""}, "168": {"exibir": "NÃO", "observacao": ""}, "169": {"exibir": "NÃO", "observacao": ""}, "170": {"exibir": "NÃO", "observacao": ""}, "171": {"exibir": "NÃO", "observacao": ""}, "174": {"exibir": "NÃO", "observacao": ""}, "175": {"exibir": "NÃO", "observacao": ""}, "176": {"exibir": "NÃO", "observacao": ""}, "177": {"exibir": "NÃO", "observacao": ""}, "178": {"exibir": "NÃO", "observacao": ""}, "182": {"exibir": "NÃO", "observacao": ""}, "186": {"exibir": "NÃO", "observacao": ""}, "191": {"exibir": "NÃO", "observacao": ""}, "192": {"exibir": "NÃO", "observacao": ""}, "201": {"exibir": "NÃO", "observacao": ""}, "202": {"exibir": "NÃO", "observacao": ""}, "219": {"exibir": "NÃO", "observacao": ""}, "220": {"exibir": "NÃO", "observacao": ""}, "221": {"exibir": "NÃO", "observacao": ""}, "222": {"exibir": "NÃO", "observacao": ""}, "223": {"exibir": "NÃO", "observacao": ""}, "226": {"exibir": "NÃO", "observacao": ""}, "227": {"exibir": "NÃO", "observacao": ""}, "228": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "229": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "230": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "237": {"exibir": "NÃO", "observacao": ""}, "238": {"exibir": "NÃO", "observacao": ""}, "239": {"exibir": "SIM", "observacao": ""}, "241": {"exibir": "NÃO", "observacao": ""}, "250": {"exibir": "SIM", "observacao": "Perguntar se tem parboilização. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "254": {"exibir": "SIM", "observacao": "Perguntar se tem óleos de milho. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "256": {"exibir": "SIM", "observacao": "Perguntar se tem óleo de milho. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "263": {"exibir": "NÃO", "observacao": ""}, "272": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "273": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "284": {"exibir": "SIM", "observacao": "Perguntar se tem refresco de fruta. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "288": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "290": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "291": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "292": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "293": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "298": {"exibir": "NÃO", "observacao": ""}, "300": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "308": {"exibir": "NÃO", "observacao": ""}, "309": {"exibir": "SIM", "observacao": "Perguntar se tem móveis ou carvoaria. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "310": {"exibir": "SIM", "observacao": "Perguntar se tem móveis. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "316": {"exibir": "NÃO", "observacao": ""}, "337": {"exibir": "NÃO", "observacao": ""}, "346": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "347": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "354": {"exibir": "SIM", "observacao": "Perguntar se é para caminhões ou ônibus. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "355": {"exibir": "NÃO", "observacao": ""}, "356": {"exibir": "NÃO", "observacao": ""}, "357": {"exibir": "SIM", "observacao": "Perguntar se é de madeira ou metal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "365": {"exibir": "SIM", "observacao": "Perguntar se é para azulejos ou pisos. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "369": {"exibir": "SIM", "observacao": "Perguntar se é organominerais. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "391": {"exibir": "SIM", "observacao": "Perguntar se é tubos ou acessórios. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "400": {"exibir": "NÃO", "observacao": ""}, "408": {"exibir": "SIM", "observacao": "Perguntar se é padronizado. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "420": {"exibir": "SIM", "observacao": "Perguntar se é para veículos aumotores. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "426": {"exibir": "SIM", "observacao": "Perguntar se tem rolamentos. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "434": {"exibir": "SIM", "observacao": "Perguntar se tem baterias. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "437": {"exibir": "SIM", "observacao": "Perguntar se é porte grande. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "438": {"exibir": "NÃO", "observacao": ""}, "439": {"exibir": "NÃO", "observacao": ""}, "440": {"exibir": "NÃO", "observacao": ""}, "441": {"exibir": "NÃO", "observacao": ""}, "444": {"exibir": "NÃO", "observacao": ""}, "445": {"exibir": "NÃO", "observacao": ""}, "453": {"exibir": "NÃO", "observacao": ""}, "455": {"exibir": "NÃO", "observacao": ""}, "456": {"exibir": "NÃO", "observacao": ""}, "461": {"exibir": "NÃO", "observacao": ""}, "462": {"exibir": "NÃO", "observacao": ""}, "463": {"exibir": "NÃO", "observacao": ""}, "464": {"exibir": "NÃO", "observacao": ""}, "465": {"exibir": "SIM", "observacao": "Perguntar a origem do resíduo. Se for industrial ou confinamento ou lodos ou anmais mortos, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "471": {"exibir": "NÃO", "observacao": ""}, "472": {"exibir": "NÃO", "observacao": ""}, "473": {"exibir": "NÃO", "observacao": ""}, "474": {"exibir": "NÃO", "observacao": ""}, "475": {"exibir": "NÃO", "observacao": ""}, "479": {"exibir": "NÃO", "observacao": ""}, "484": {"exibir": "NÃO", "observacao": ""}, "485": {"exibir": "NÃO", "observacao": ""}, "489": {"exibir": "NÃO", "observacao": ""}, "490": {"exibir": "NÃO", "observacao": ""}, "499": {"exibir": "NÃO", "observacao": ""}, "500": {"exibir": "NÃO", "observacao": ""}, "507": {"exibir": "SIM", "observacao": ""}, "508": {"exibir": "SIM", "observacao": ""}, "519": {"exibir": "NÃO", "observacao": ""}, "520": {"exibir": "NÃO", "observacao": ""}, "521": {"exibir": "NÃO", "observacao": ""}, "522": {"exibir": "NÃO", "observacao": ""}, "523": {"exibir": "NÃO", "observacao": ""}, "526": {"exibir": "NÃO", "observacao": ""}, "527": {"exibir": "NÃO", "observacao": ""}, "528": {"exibir": "NÃO", "observacao": ""}, "529": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "530": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "531": {"exibir": "SIM", "observacao": "Perguntar se é criação de espécie alóctone. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "538": {"exibir": "NÃO", "observacao": ""}, "539": {"exibir": "NÃO", "observacao": ""}, "540": {"exibir": "NÃO", "observacao": ""}, "541": {"exibir": "SIM", "observacao": ""}, "542": {"exibir": "SIM", "observacao": ""}, "545": {"exibir": "NÃO", "observacao": ""}, "546": {"exibir": "NÃO", "observacao": ""}, "557": {"exibir": "SIM", "observacao": "Perguntar se tem parboilização. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "561": {"exibir": "SIM", "observacao": "Perguntar se tem óleos de milho. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "563": {"exibir": "SIM", "observacao": "Perguntar se tem óleo de milho. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "573": {"exibir": "NÃO", "observacao": ""}, "574": {"exibir": "NÃO", "observacao": ""}, "584": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "585": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "596": {"exibir": "SIM", "observacao": "Perguntar se tem refresco de fruta. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "600": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "602": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "603": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "604": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "605": {"exibir": "SIM", "observacao": "Perguntar se é artesanal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "610": {"exibir": "NÃO", "observacao": ""}, "620": {"exibir": "NÃO", "observacao": ""}, "621": {"exibir": "SIM", "observacao": "Perguntar se tem móveis ou carvoaria. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "622": {"exibir": "SIM", "observacao": "Perguntar se tem móveis. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "628": {"exibir": "NÃO", "observacao": ""}, "650": {"exibir": "NÃO", "observacao": ""}, "659": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "660": {"exibir": "SIM", "observacao": "Perguntar se é associado à extração. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "667": {"exibir": "SIM", "observacao": "Perguntar se é para caminhões ou ônibus. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "668": {"exibir": "NÃO", "observacao": ""}, "669": {"exibir": "NÃO", "observacao": ""}, "670": {"exibir": "SIM", "observacao": "Perguntar se é de madeira ou metal. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "678": {"exibir": "SIM", "observacao": "Perguntar se é para azulejos ou pisos. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "682": {"exibir": "SIM", "observacao": "Perguntar se é organominerais. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "704": {"exibir": "SIM", "observacao": "Perguntar se é tubos ou acessórios. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "713": {"exibir": "NÃO", "observacao": ""}, "721": {"exibir": "SIM", "observacao": "Perguntar se é padronizado. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "733": {"exibir": "SIM", "observacao": "Perguntar se é para veículos aumotores. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "739": {"exibir": "SIM", "observacao": "Perguntar se tem rolamentos. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "747": {"exibir": "SIM", "observacao": "Perguntar se tem baterias. Se tiver, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não tiver, pode rodar o programa"}, "750": {"exibir": "SIM", "observacao": "Perguntar se é porte grande. Se for, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "751": {"exibir": "NÃO", "observacao": ""}, "752": {"exibir": "NÃO", "observacao": ""}, "753": {"exibir": "NÃO", "observacao": ""}, "754": {"exibir": "NÃO", "observacao": ""}, "757": {"exibir": "NÃO", "observacao": ""}, "758": {"exibir": "NÃO", "observacao": ""}, "759": {"exibir": "NÃO", "observacao": ""}, "767": {"exibir": "NÃO", "observacao": ""}, "769": {"exibir": "NÃO", "observacao": ""}, "770": {"exibir": "NÃO", "observacao": ""}, "775": {"exibir": "NÃO", "observacao": ""}, "776": {"exibir": "NÃO", "observacao": ""}, "777": {"exibir": "NÃO", "observacao": ""}, "778": {"exibir": "NÃO", "observacao": ""}, "779": {"exibir": "SIM", "observacao": "Perguntar a origem do resíduo. Se for industrial ou confinamento ou lodos ou anmais mortos, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não for, pode rodar o programa"}, "785": {"exibir": "NÃO", "observacao": ""}, "786": {"exibir": "NÃO", "observacao": ""}, "787": {"exibir": "NÃO", "observacao": ""}, "788": {"exibir": "NÃO", "observacao": ""}, "789": {"exibir": "NÃO", "observacao": ""}, "793": {"exibir": "NÃO", "observacao": ""}, "801": {"exibir": "SIM", "observacao": "Perguntar se lança em rio estadual ou federal. Se lançar, travar o algoritimo e retornar \\"Não é passível de licenciamento\\". Se não lançar, pode rodar o programa"}, "802": {"exibir": "NÃO", "observacao": ""}, "807": {"exibir": "NÃO", "observacao": ""}, "808": {"exibir": "NÃO", "observacao": ""}, "818": {"exibir": "NÃO", "observacao": ""}, "819": {"exibir": "NÃO", "observacao": ""}, "820": {"exibir": "NÃO", "observacao": ""}, "826": {"exibir": "NÃO", "observacao": ""}, "827": {"exibir": "NÃO", "observacao": ""}, "828": {"exibir": "NÃO", "observacao": ""}}')
for _idx,_row in enumerate(CONSEMA):
    _revisao=REVISAO_CONDICIONANTES.get(str(_idx))
    if _revisao:
        _row["_EXIBIR_CONDICAO"]=_revisao["exibir"] == "SIM"
        _row["_OBS_CONDICAO"]=_revisao["observacao"]
    else:
        _row["_EXIBIR_CONDICAO"]=False
        _row["_OBS_CONDICAO"]=""
# A tabela enviada não contém decisões de interface para o Decreto.
# Para o Decreto, manter o tratamento original das condições.

NAO_DESCENTRALIZADOS=set(TODOS_MUNICIPIOS_MT) - set(MUNICIPIOS_GRUPO)
MUNICIPIO_CONSORCIO={'Feliz Natal': 'CIDESA-ATP — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Alto Teles Pires', 'Nova Ubiratã': 'CIDESA-ATP — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Alto Teles Pires', 'Santa Rita do Trivelato': 'CIDESA-ATP — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Alto Teles Pires', 'Vera': 'CIDESA-ATP — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Alto Teles Pires', 'Canabrava do Norte': 'CIDESA-NA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Norte Araguaia', 'Porto Alegre do Norte': 'CIDESA-NA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Norte Araguaia', 'Santa Terezinha': 'CIDESA-NA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Norte Araguaia', 'São José do Xingu': 'CIDESA-NA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Norte Araguaia', 'Vila Rica': 'CIDESA-NA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental - Norte Araguaia', 'Água Boa': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Campinápolis': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Cocalinho': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Canarana': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Gaúcha do Norte': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Nova Nazaré': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Nova Xavantina': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Querência': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia', 'Ribeirão Cascalheira': 'CODEMA — Consórcio Intermunicipal de Desenvolvimento Econômico, Social e Ambiental Médio Araguaia'}

def norm(s):
    s=unicodedata.normalize("NFKD",str(s or "").lower())
    s="".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"\s+"," ",re.sub(r"[^a-z0-9]+"," ",s)).strip()

def fnum(v):
    if v in (None,""): return None
    if isinstance(v,(int,float)): return float(v)
    s=str(v).strip()
    if "," in s: s=s.replace(".","").replace(",",".")
    try: return float(s)
    except: return None

def usernum(s):
    s=str(s or "").strip()
    if not s: return None
    if "," in s: s=s.replace(".","").replace(",",".")
    return float(s)

def toks(s):
    stop={"de","da","do","das","dos","e","em","para","com","sem","por","ou","a","o"}
    return {x for x in norm(s).split() if len(x)>2 and x not in stop}

ALIASES={
 "algodoeira":["beneficiamento e descarocamento de algodao"],
 "confinamento bovino":["criacao de bovinos de corte confinados","criacao de bovinos e bubalinos de corte confinados"],
 "armazens gerais":["armazens gerais"],
 "armazem de graos":["armazenamento de graos","armazens gerais"],
}

def activity_score(q,a):
    qn,an=norm(q),norm(a)
    if not qn or not an: return 0
    for key,targets in ALIASES.items():
        if key in qn and any(t in an for t in targets): return 1.0
    tq,ta=toks(qn),toks(an)
    overlap=len(tq & ta)/max(1,len(tq))
    seq=SequenceMatcher(None,qn,an).ratio()
    contain=0.98 if qn in an or an in qn else 0
    return max(contain,0.78*overlap+0.22*seq)

def candidates(rows,q,municipal_group=None):
    if norm(q) in _VARIANTES_POR_PUBLICO:
        permitidas=_variantes_publicas(q)
        return [r for r in rows if norm(r.get("ATIVIDADE")) in permitidas
                and (not municipal_group or str(r.get("GRUPO","")).strip()==municipal_group)]
    scored=[]
    for r in rows:
        if municipal_group and str(r.get("GRUPO","")).strip()!=municipal_group: continue
        s=activity_score(q,r.get("ATIVIDADE",""))
        try:
            da=display_activity(r.get("ATIVIDADE",""))
            if norm(da)==norm(q): s=max(s,1.0)
            elif norm(q) and norm(q) in norm(da): s=max(s,0.82)
        except NameError:
            pass
        if s>=0.55: scored.append((s,r))
    if not scored:return []
    scored.sort(key=lambda x:x[0],reverse=True)
    top=scored[0][0]
    return [r for s,r in scored if s>=max(0.62,top-0.10)]

def unit_equiv(user_u,norm_u):
    u,n=norm(user_u),norm(norm_u)
    if not user_u: return True
    if u==n:return True
    # practical equivalence for bovine confinement input vs CONSEMA technical normalization
    if u in {"cabecas","unidades ciclo"} and n in {"cabecas","unidades ciclo"}: return True
    return False

def row_fit(r,value,unit):
    ru=str(r.get("UNIDADE") or "").strip()
    if norm(ru)=="todo": return True,"TODO"
    if value is None:return None,"NEED_VALUE"
    if not unit_equiv(unit,ru):return None,"UNIT"
    mn,mx=fnum(r.get("MÍNIMO")),fnum(r.get("MÁXIMO"))
    op=str(r.get("OPERADOR") or "").strip()
    if op==">": return (mn is not None and value>mn),"RANGE"
    if op==">=": return (mn is not None and value>=mn),"RANGE"
    if op=="<": return (mx is not None and value<mx),"RANGE"
    if op=="<=": return (mx is not None and value<=mx),"RANGE"
    return ((mn is None or value>=mn) and (mx is None or value<=mx)),"RANGE"

def outorga(activity):
    n=norm(activity)
    termos=("outorga","captacao superficial","captacao subterranea",
            "captacao de agua superficial","captacao de agua subterranea",
            "derivacao de agua")
    return any(t in n for t in termos)

def mineracao(activity):
    n=norm(activity)
    pad=f" {n} "
    nao_minerarias=("fabricacao de maquinas","fabricacao de outras maquinas",
                    "manutencao de maquinas","reparacao de maquinas",
                    "fabricacao de equipamentos")
    if any(t in n for t in nao_minerarias):
        return False
    termos=[" mineracao "," pesquisa mineral "," beneficiamento mineral ",
            " extracao mineral "," extracao e beneficiamento de bens minerais ",
            " recurso mineral "," recursos minerais "," cascalho "," ouro ",
            " diamante "," calcario "," lavra "," pelotizacao "," sinterizacao "]
    return any(t in pad for t in termos)

COND_NAO_ATENDE = "NÃO ATENDE / NÃO SE APLICA"

def row_condition(r):
    return str(r.get("CONDIÇÃO") or "").strip()

def _cond_perguntavel(r):
    return r.get("_EXIBIR_CONDICAO", True)

def _observacao_pergunta(r):
    obs=str(r.get("_OBS_CONDICAO") or "").strip()
    if not _cond_perguntavel(r) or not obs.lower().startswith("perguntar"):
        return ""
    return obs.split(".",1)[0].strip().rstrip(". ") + "?"

def condition_question(rows):
    questions=list(dict.fromkeys(_observacao_pergunta(r) for r in rows if _observacao_pergunta(r)))
    return questions[0] if len(questions)==1 else ""

def condition_options(rows):
    if condition_question(rows):
        return ["Sim", "Não"]
    vals=[];seen=set()
    for r in rows:
        if not _cond_perguntavel(r):
            continue
        c=row_condition(r)
        if c and norm(c) not in seen:
            vals.append(c);seen.add(norm(c))
    return vals

def apply_condition(rows, selected_condition):
    opts=condition_options(rows)
    if not opts:
        return rows,None
    sel=str(selected_condition or "").strip()
    if not sel:
        return [],("NEED_CONDITION",opts)
    if opts==["Sim","Não"]:
        if norm(sel)=="sim":
            return [],("BLOCKED_CONDITION",opts)
        if norm(sel)=="nao":
            return rows,None
        return [],("INVALID_CONDITION",opts)
    if norm(sel)==norm(COND_NAO_ATENDE):
        return [r for r in rows if not row_condition(r) or not _cond_perguntavel(r)], ("NOT_APPLICABLE",opts)
    matched=[r for r in rows if not _cond_perguntavel(r) or (row_condition(r) and norm(row_condition(r))==norm(sel))]
    if matched:
        return matched,None
    return [],("INVALID_CONDITION",opts)

def _blocked_message(activity):
    return ("Critérios não atendidos\n"
            f"Atividade: {activity}\n"
            "Não é passível de licenciamento municipal na linha normativa analisada.\n"
            "Isso não constitui dispensa geral de licenciamento; verificar a competência e o enquadramento estadual, se aplicável.")

def best_matching(rows,activity,value,unit,condition=""):
    cs=candidates(rows,activity)
    if not cs:return [],[]
    cs,cond_status=apply_condition(cs,condition)
    if cond_status and cond_status[0] in {"NEED_CONDITION","INVALID_CONDITION"}:
        return [],[("__CONDITION__",False,cond_status)]
    if not cs:return [],[]
    fits=[]; statuses=[]
    for r in cs:
        ok,why=row_fit(r,value,unit); statuses.append((r,ok,why))
        if ok is True:fits.append(r)
    return fits,statuses

# Catálogo externo editável de fontes oficiais, independente do motor de enquadramento.
# Se o arquivo não existir ou estiver inválido, preserva-se a referência oficial embutida.
TR_SEMA_GERAL = "https://www.sema.mt.gov.br/site/index.php/2013-10-27-00-11-6"
TR_SEMA_LAC = "https://www.sema.mt.gov.br/site/index.php/licen%C3%A7a-por-ades%C3%A3o-e-compromisso"
TR_SEMA_LAS = "https://www.sema.mt.gov.br/site/index.php/licen%C3%A7a-ambiental-simplificada"
TR_CATALOGO_PATH = Path(__file__).resolve().with_name("catalogo_trs_mt_v1_18.json")
TR_FALLBACK = {"GERAL": TR_SEMA_GERAL, "LAC": TR_SEMA_LAC, "LAS": TR_SEMA_LAS}


def carregar_catalogo_trs():
    """Lê URLs oficiais previamente cadastradas; não altera a competência."""
    try:
        dados = json.loads(TR_CATALOGO_PATH.read_text(encoding="utf-8"))
        if not isinstance(dados.get("fontes"), list):
            raise ValueError("Catálogo sem lista de fontes")
        return dados
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return {"fontes": [{"chave": k, "url": v, "orgao": "SEMA/MT", "situacao": "Referência oficial; verificação pendente"}
                           for k, v in TR_FALLBACK.items()]}


def urls_trs():
    urls = dict(TR_FALLBACK)
    for item in carregar_catalogo_trs().get("fontes", []):
        if not isinstance(item, dict):
            continue
        chave = str(item.get("chave", "")).upper()
        url = str(item.get("url", ""))
        if chave in urls and url.startswith("https://www.sema.mt.gov.br/"):
            urls[chave] = url
    return urls


def tr_sema(modalidade):
    """Página oficial de consulta; não afirma existir TR específico."""
    mod = str(modalidade or "").strip().upper()
    fontes = urls_trs()
    if mod in {"LAC", "LAS"}:
        return f"\nConsulta de TRs SEMA/MT ({mod}): {fontes[mod]}"
    return f"\nConsulta de TRs SEMA/MT: {fontes['GERAL']}"


def trs_especificos(atividade, cnae, modalidade):
    """Seleciona apenas vínculos explicitamente confirmados no catálogo.

    Não presume TR por CNAE isolado nem por semelhança textual.
    """
    mod = str(modalidade or "").strip().upper()
    atividade_chave = norm(atividade)
    encontrados = []
    for item in carregar_catalogo_trs().get("trs_especificos", []):
        if not isinstance(item, dict) or item.get("situacao") != "confirmado":
            continue
        if mod not in [str(x).upper() for x in item.get("modalidades", [])]:
            continue
        if atividade_chave not in [norm(x) for x in item.get("atividades", [])]:
            continue
        # CNAE é um refinamento opcional; se preenchido, deve coincidir.
        if item.get("cnaes") and str(cnae or "").strip() not in [str(x).strip() for x in item["cnaes"]]:
            continue
        url = str(item.get("url", ""))
        if not url.startswith("https://www.sema.mt.gov.br/"):
            continue
        encontrados.append(item)
    return encontrados




# Normalização restrita a quebras de palavras confirmadas na auditoria v1.25.
def _chave_tr_v125(valor):
    texto = str(valor or "").strip().rstrip(".")
    for antes, depois in (("an-teriormente", "anteriormente"), ("espe-cificados", "especificados"), ("anteriormen-te", "anteriormente"), ("supermer-cados", "supermercados"), ("transporta-dor", "transportador"), ("especifica-dos", "especificados"), ("anterior-mente", "anteriormente"), ("es-pecificados", "especificados")):
        texto = re.sub(re.escape(antes), depois, texto, flags=re.IGNORECASE)
    return norm(texto)

TR_ASSOCIACOES_PATH = Path(__file__).resolve().with_name("catalogo_trs_associacoes_v1_27.json")

# Aliases somente para a BUSCA de TRs, nunca para enquadramento normativo.
TR_ALIASES_BUSCA={
    "suinocultura": ("suinocultura", "suinos", "criacao de suinos"),
    "confinamento bovino": ("confinamento bovino", "bovinos confinados", "bovino confinado",
                           "confinamento de bovinos", "confinamento de gado", "confinamento"),
}

def _familia_busca_tr(atividade):
    n=norm(atividade)
    if n.startswith("suinocultura"):
        return "Suinocultura"
    if "bovinos" in n and "confinados" in n:
        return "Confinamento bovino"
    return str(atividade).strip()

def _bate_busca_tr(termo,atividade,numero):
    n=norm(atividade)
    if termo in n or termo==norm(numero):
        return True
    familia=_familia_busca_tr(atividade)
    if termo in norm(familia):
        return True
    aliases=TR_ALIASES_BUSCA.get(norm(familia),())
    return any(termo in norm(alias) for alias in aliases)

def _chave_familia_tr(atividade, assinaturas, grupo_normativo):
    """Unifica na consulta apenas variantes com prefixo específico e TRs idênticos.
    Nunca altera as atividades normativas ou as associações da planilha.
    """
    import re
    nome=norm(atividade)
    if nome.startswith("suinocultura"):
        return ("suinocultura", "Suinocultura", grupo_normativo)
    if "bovinos" in nome and "confinados" in nome:
        return ("confinamento bovino", "Confinamento bovino", grupo_normativo)
    # Qualificadores entre parênteses são variantes de uma família SOMENTE
    # quando a assinatura completa dos TRs coincide.
    base=re.sub(r"\s*\([^)]*\)", "", nome).strip(" -.,")
    base=re.sub(r"\s+-\s+(com|sem|inclusive|exceto)\b.*$", "", base).strip()
    if len(base)>=18 and len(base.split())>=3 and base!=nome and assinaturas:
        return (base, atividade.split("(")[0].strip(" -.,"), grupo_normativo, tuple(sorted(assinaturas)))
    return (nome,atividade,grupo_normativo)

def carregar_solicitacoes_tr():
    """42 registros literais da coluna Nº DO TR da planilha original."""
    caminho=Path(__file__).resolve().parent / "solicitacoes_tr_planilha_v1_30_5.json"
    try:
        return json.loads(caminho.read_text(encoding="utf-8"))["registros"]
    except (OSError, ValueError, KeyError) as exc:
        raise RuntimeError("Não foi possível carregar as solicitações de TR da planilha: "
                           + str(caminho) + ". Extraia o ZIP completo. " + str(exc)) from exc

def buscar_grupos_trs(registros,termo,solicitacoes=None):
    """Busca por todas as atividades da planilha, agrupando só equivalências seguras.

    O agrupamento é de exibição, preservando números, modalidades, solicitações,
    links informados e linhas normativas originais.
    """
    from collections import defaultdict
    termo=norm(termo)
    por_atividade=defaultdict(list)
    for r in registros:
        atividade=str(r.get("atividade","")).strip()
        if atividade:
            por_atividade[(atividade,str(r.get("grupo", "")))].append(r)
    grupos={}
    for (atividade,grupo_normativo),itens in por_atividade.items():
        assinaturas={(str(r.get("numero","")),str(r.get("modalidade_licenca","")),
                      str(r.get("tipo_solicitacao",""))) for r in itens}
        chave_info=_chave_familia_tr(atividade,assinaturas,grupo_normativo)
        chave=(chave_info[0],grupo_normativo) if chave_info[0] in ("suinocultura","confinamento bovino") else (chave_info[0],grupo_normativo,tuple(sorted(assinaturas)))
        g=grupos.setdefault(chave,{"titulo":chave_info[1],"atividades":set(),"trs":[],"vistos":set(),"_grupo_normativo":grupo_normativo})
        g["atividades"].add(atividade)
        for r in itens:
            numero=str(r.get("numero","")).strip()
            modalidade=str(r.get("modalidade_licenca","")).strip()
            tipo=str(r.get("tipo_solicitacao","")).strip()
            pagina=str(r.get("link_pagina","")).strip()
            chave_tr=(numero,modalidade,tipo,pagina)
            if chave_tr not in g["vistos"]:
                g["vistos"].add(chave_tr)
                g["trs"].append({"numero":numero,"modalidade":modalidade,"tipo":tipo,"pagina":pagina})
    # Incluir todas as atividades da base normativa estadual na consulta,
    # inclusive aquelas sem TR numerado cadastrado. Não inventar número ou link.
    # A competência municipal continua sendo avaliada na aba Classificador.
    atividades_normativas={}
    for linha_norma in DECRETO:
        atividade_norma=str(linha_norma.get("ATIVIDADE","")).strip()
        grupo_norma=str(linha_norma.get("GRUPO","")).strip()
        if atividade_norma:
            atividades_normativas[(atividade_norma,grupo_norma)]=True
    for atividade_norma,grupo_norma in atividades_normativas:
        if (atividade_norma,grupo_norma) in por_atividade:
            continue
        chave_info=_chave_familia_tr(atividade_norma,set(),grupo_norma)
        chave=(chave_info[0],grupo_norma) if chave_info[0] in ("suinocultura","confinamento bovino") else (chave_info[0],grupo_norma,())
        g=grupos.setdefault(chave,{"titulo":chave_info[1],"atividades":set(),"trs":[],"vistos":set(),"_grupo_normativo":grupo_normativo})
        g["atividades"].add(atividade_norma)
    # Adicionar explicitamente as 42 linhas "Solicitar ao órgão" da planilha,
    # inclusive quando já existem TRs numerados para outras solicitações.
    for pendencia in (solicitacoes or []):
        atividade=str(pendencia.get("atividade","")).strip()
        grupo_normativo=str(pendencia.get("grupo","")).strip()
        if not atividade:
            continue
        candidatos=[g for g in grupos.values()
                    if any(norm(at)==norm(atividade) for at in g["atividades"])
                    and norm(g.get("_grupo_normativo",""))==norm(grupo_normativo)]
        # Se a classificação de grupo mudou entre planilha e base, a
        # identidade textual exata da atividade ainda permite exibir o aviso.
        if not candidatos:
            candidatos=[g for g in grupos.values()
                        if any(norm(at)==norm(atividade) for at in g["atividades"])]
        if not candidatos:
            chave_info=_chave_familia_tr(atividade,set(),grupo_normativo)
            chave=("solicitar",norm(atividade),grupo_normativo)
            g=grupos.setdefault(chave,{"titulo":chave_info[1],"atividades":set(),"trs":[],"vistos":set(),"_grupo_normativo":grupo_normativo})
            g["atividades"].add(atividade)
            candidatos=[g]
        for g in candidatos:
            g.setdefault("solicitacoes",[])
            identificador=pendencia["linha_planilha"]
            if not any(x["linha_planilha"]==identificador for x in g["solicitacoes"]):
                g["solicitacoes"].append(pendencia)
    saida=[]
    for g in grupos.values():
        if not (any(_bate_busca_tr(termo,at,t["numero"]) for at in g["atividades"] for t in g["trs"])
                or any(termo in norm(at) or norm(at) in termo for at in g["atividades"])):
            continue
        g["atividades"]=sorted(g["atividades"],key=norm)
        g["trs"].sort(key=lambda x:(0 if x["tipo"]=="Inicial" else 1,
                       {"LP":0,"LI":1,"LO":2,"LAS":3,"LAC":4,"*":5}.get(x["modalidade"],6),
                       int(x["numero"]) if x["numero"].isdigit() else 99999))
        del g["vistos"]
        g.pop("_grupo_normativo",None)
        saida.append(g)
    return sorted(saida,key=lambda x:norm(x["titulo"]))

# ÓIKOS: TRs complementares independentes das linhas normativas.
TR_COMPLEMENTARES_PATH = Path(__file__).resolve().with_name("catalogo_trs_complementares_oikos.json")

def carregar_trs_complementares():
    try:
        dados = json.loads(TR_COMPLEMENTARES_PATH.read_text(encoding="utf-8"))
        return dados.get("extras", []), dados.get("especiais", [])
    except (OSError, ValueError, TypeError) as exc:
        raise RuntimeError("Falha no catálogo complementar de TRs: " + str(exc)) from exc

def buscar_trs_complementares(termo):
    extras, especiais = carregar_trs_complementares()
    termo = norm(termo)
    return [r for r in extras + especiais
            if termo in norm(r.get("atividade", "")) or termo == norm(r.get("numero", ""))
            or termo in norm(r.get("modalidade", ""))]

def texto_trs_especiais_estaduais(modalidade, tipo_solicitacao):
    # Chamado SOMENTE no fluxo estadual do Decreto 1.585/2022.
    _, especiais = carregar_trs_complementares()
    licencas = {p.strip().upper() for p in str(modalidade or "").split("+")}
    renovacao = str(tipo_solicitacao or "").strip().lower().startswith("renov")
    aplicaveis = []
    for r in especiais:
        if not r.get("exibir_classificador"):
            continue  # TR 02: alteração de razão social, somente consulta.
        numero = str(r.get("numero", ""))
        modalidades = {p.strip().upper() for p in r.get("modalidade", "").split("+")}
        if not licencas.intersection(modalidades):
            continue
        if numero == "211" and not renovacao:
            continue  # TR 211 corresponde à renovação de LAS.
        aplicaveis.append(r)
    if not aplicaveis:
        return ""
    linhas = ["TRs especiais complementares — Decreto 1.585/2022 (verifique aplicabilidade):"]
    for r in aplicaveis:
        linhas.append("- TR nº {} — {}".format(r["numero"], r["atividade"]))
        if r.get("link_pagina"):
            linhas.append("  Página informada na planilha: " + r["link_pagina"])
    return "\n".join(linhas)

def consultar_trs_planilha(atividade, modalidade, tipo_solicitacao="Inicial", anm=""):
    """Correspondências exatas informadas pela usuária; não certifica vigência oficial."""
    try:
        registros = json.loads(TR_ASSOCIACOES_PATH.read_text(encoding="utf-8")).get("registros", [])
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise RuntimeError(
            "Não foi possível carregar o catálogo de TRs da planilha: "
            + str(TR_ASSOCIACOES_PATH) + ". Verifique se o arquivo JSON foi extraído "
            "na mesma pasta do programa. Detalhes: " + str(exc)
        ) from exc
    lic = str(modalidade or "").upper()
    tipo = "Renovação" if str(tipo_solicitacao).strip().lower().startswith("renov") else "Inicial"
    licencas = [m.strip() for m in lic.split("+")]
    selecionados = []
    for item in registros:
        if _chave_tr_v125(item.get("atividade")) != _chave_tr_v125(atividade):
            continue
        if item.get("tipo_solicitacao") != tipo:
            continue
        if item.get("modalidade_licenca") not in licencas and item.get("modalidade_licenca") != "*":
            continue
        if item.get("modalidade_licenca") == "LOPM" and anm not in ("Alvará de Pesquisa", "Alvará de Pesquisa + GU"):
            continue
        if item.get("modalidade_licenca") in ("LP", "LI", "LO") and anm in ("Alvará de Pesquisa", "Alvará de Pesquisa + GU") and lic == "LOPM":
            continue
        selecionados.append(item)
    return selecionados

def texto_trs_planilha(atividade, modalidade, tipo_solicitacao="Inicial", anm=""):
    itens = consultar_trs_planilha(atividade, modalidade, tipo_solicitacao, anm)
    if not itens:
        return ""
    partes = ["TRs cadastrados conforme planilha (verifique correspondência, aplicabilidade e vigência antes do protocolo):"]
    for item in itens:
        pagina = str(item.get("link_pagina") or "").strip()
        modalidade_tr = "modalidade específica não discriminada na fonte" if item['modalidade_licenca'] == "*" else item['modalidade_licenca']
        partes.append("- TR nº {} — {} — {}".format(item['numero'], modalidade_tr, item['tipo_solicitacao']))
        # Usar EXCLUSIVAMENTE o endereço de página informado na planilha,
        # sem substituir por páginas gerais, categorias inferidas ou PDFs.
        if pagina:
            partes.append("  Página informada na planilha: " + pagina)
        else:
            partes.append("  Link da página não informado na planilha.")
        if item.get("uso_provisorio_renovacao"):
            partes.append("  ATENÇÃO: TR de solicitação inicial utilizado provisoriamente para renovação de LAS/LAC, conforme procedimento relatado. Verifique orientações atuais da SEMA antes do protocolo; substitua por TR específico quando publicado.")
        if item.get("observacoes"):
            partes.append("  Observação: " + item['observacoes'])
    partes.append("Confira o documento e sua aplicabilidade antes do protocolo.")
    return "\n".join(partes)

def categoria_tr_atividade(atividade):
    """Direcionamento conservador por assunto; não confirma TR individual."""
    nome = norm(atividade)
    categorias = carregar_catalogo_trs().get("categorias", [])
    correspondencias = []
    for categoria in categorias:
        palavras = categoria.get("termos", [])
        if any(re.search(r"(?<![a-z])" + re.escape(norm(t)) + r"(?![a-z])", nome) for t in palavras):
            correspondencias.append(categoria)
    # Não escolher arbitrariamente se houver ambiguidade.
    if len(correspondencias) == 1:
        return correspondencias[0]
    return None


def tr_atividade(atividade, cnae, modalidade):
    """Exibe documentos confirmados ou orienta consulta oficial, sem inventar TRs."""
    mods = [m.strip() for m in str(modalidade or "").split("+") if m.strip()]
    if not mods:
        mods = [str(modalidade or "").strip()]
    saida = []
    for mod in mods:
        encontrados = trs_especificos(atividade, cnae, mod)
        if encontrados:
            saida.append(f"\nTR(s) específico(s) cadastrado(s) — {mod}:")
            for item in encontrados:
                numero = str(item.get("numero", "")).strip()
                titulo = str(item.get("titulo", "")).strip()
                verificado = str(item.get("ultima_verificacao", "não informada"))
                saida.append(f"- {numero} — {titulo}\n  {item['url']}\n  Última conferência: {verificado}")
            saida.append("Confirme a versão e a aplicabilidade antes de protocolar.")
        else:
            saida.append(f"\nTR específico ({mod}): não identificado na base verificada.")
            if mod.upper() in {"LAS", "LAC"}:
                saida.append(tr_sema(mod).strip())
            else:
                categoria = categoria_tr_atividade(atividade)
                if categoria:
                    saida.append(f"Consulta de TRs SEMA/MT — categoria {categoria['nome']}: {categoria['url']}")
                    saida.append("Categoria sugerida por assunto; confira o TR aplicável e sua versão.")
                else:
                    saida.append(tr_sema(mod).strip())
    return "\n".join(saida)


def verificar_link_tr(url, timeout=9):
    """Verifica resposta HTTP, sem afirmar vigência ou conteúdo jurídico."""
    try:
        req = Request(url, headers={"User-Agent": "Mozilla/5.0 (Classificador Ambiental MT; verificador de links)"})
        with urlopen(req, timeout=timeout) as resp:
            status = resp.status
            final = resp.geturl()
            if status == 200:
                return "Acessível (HTTP 200)" + (" — redirecionado" if final != url else "")
            return f"Resposta HTTP {status}"
    except HTTPError as e:
        return f"HTTP {e.code} — verificar manualmente"
    except (URLError, TimeoutError, OSError, ValueError) as e:
        return f"Não foi possível confirmar acesso ({type(e).__name__})"


def analyze(municipio,activity,porte="",unit="",anm="",condition="",tipo_solicitacao="Inicial"):
    municipio=str(municipio or "").strip(); activity=str(activity or "").strip()
    if not municipio or not activity:return "Informe Município e Atividade."
    try:value=usernum(porte)
    except:return "Porte/Capacidade inválido. Informe somente o valor numérico."

    if outorga(activity):
        return (f"Município: {municipio}\nAtividade: {activity}\n\n"
                "Competência: SEMA/MT — Recursos Hídricos\n"
                "Enquadramento municipal: Não aplicável\n"
                "Modalidade ambiental: Não definida por este classificador de licenciamento.")

    mining_ctx = mineracao(activity) or bool(anm)
    if mining_ctx and not anm:
        return "Mineração identificada. Selecione o Regime ANM para continuar."

    # Guarda as linhas CONSEMA candidatas para permitir reenquadramento estadual
    # por CNAE quando o porte/condição não couber no grupo municipal.
    municipal_candidates = []
    motivo_municipal = ""
    grupos_atividade = []

    if municipio in MUNICIPIOS_GRUPO:
        g=MUNICIPIOS_GRUPO[municipio]
        # Consultar a atividade em TODOS os grupos, não somente no grupo
        # habilitado. Isso evita ocultar divergências A/B/C.
        candidatos_consema = candidates(CONSEMA,activity)
        grupos_atividade = sorted({str(x.get("GRUPO") or "").strip()
                                   for x in candidatos_consema if x.get("GRUPO")})
        cr = [x for x in candidatos_consema
              if str(x.get("GRUPO") or "").strip() == str(g).strip()]
        municipal_candidates = candidatos_consema[:]
        if candidatos_consema and not cr:
            motivo_municipal = ("Grupo municipal " + str(g) +
                                " não contempla o(s) grupo(s) da atividade: " +
                                ", ".join(grupos_atividade) + ".")
        if cr:
            cr,cond_status=apply_condition(cr,condition)
            if cond_status and cond_status[0]=="BLOCKED_CONDITION":
                return _blocked_message(activity)
            if cond_status and cond_status[0]=="NEED_CONDITION":
                return ("Selecione a Condição/Característica aplicável antes de analisar.\n"
                        "Opções normativas: " + " | ".join(cond_status[1]))
            if cond_status and cond_status[0]=="INVALID_CONDITION":
                return ("A condição selecionada não corresponde às linhas normativas desta atividade.\n"
                        "Opções normativas: " + " | ".join(cond_status[1]))
            matched=[]; unit_problem=[]; need_value=[]
            for r in cr:
                ok,why=row_fit(r,value,unit)
                if ok is True:matched.append(r)
                elif why=="UNIT":unit_problem.append(r)
                elif why=="NEED_VALUE":need_value.append(r)
            if matched:
                r=matched[0]
                cond=str(r.get("CONDIÇÃO") or "").strip()
                result=(f"Município: {municipio}\nDescentralizado: SIM\nGrupo municipal: {g}\n"
                        f"Atividade: {display_activity(r.get('ATIVIDADE'))}\nCNAE: {r.get('CNAE')}\n"
                        f"Unidade normativa: {display_unit(r.get('UNIDADE'))}\n"
                        f"Porte informado: {porte+' '+unit if porte else 'Não aplicável'}\n")
                if cond:result+=f"Condição normativa: {cond}\n"
                orgao = MUNICIPIO_CONSORCIO.get(municipio, "Prefeitura/Órgão Ambiental Municipal")
                result+=(f"Grupo da atividade (CONSEMA): {r.get('GRUPO')}\n"
                         "\nEnquadramento municipal: SIM\n"
                         "Resultado: ATIVIDADE PASSÍVEL DE LICENCIAMENTO NO MUNICÍPIO\n"
                         f"Competência: MUNICIPAL — {orgao}\n"
                         "Modalidade: LP + LI + LO")
                if mining_ctx:
                    result += f"\nRegime ANM: {anm}"
                return result
            if not matched and not motivo_municipal:
                motivo_municipal = ("Porte, unidade ou limites da atividade não "
                                    "atendem ao enquadramento municipal.")
            if unit_problem and value is not None:
                motivo_municipal = ("Unidade informada incompatível com o "
                                    "parâmetro municipal.")
            if need_value:
                units=sorted({str(r.get("UNIDADE")) for r in need_value})
                return "Informe Porte/Capacidade na unidade normativa: "+", ".join(units)
        group_text=g
        if not candidatos_consema:
            motivo_municipal = "Atividade não localizada na CONSEMA nº 74/2025."
    elif municipio in NAO_DESCENTRALIZADOS:
        group_text="Não aplicável"
        motivo_municipal = "Município não descentralizado."
    else:
        return (f"Município: {municipio}\n\n"
                "Município ainda não cadastrado na tabela de descentralização desta versão.\n"
                "Análise bloqueada para evitar presumir competência.")

    # Reenquadramento estadual OBRIGATÓRIO quando não houver encaixe municipal.
    # A base estadual continua determinando a modalidade específica (LAS/LAC/
    # LOPM etc.), sem impor LP+LI+LO onde o Decreto não a prevê.
    fits,status=best_matching(DECRETO,activity,value,unit,condition)
    cs=candidates(DECRETO,activity)
    cs,state_cond_status=apply_condition(cs,condition) if cs else (cs,None)
    if state_cond_status and state_cond_status[0]=="BLOCKED_CONDITION":
        return _blocked_message(activity)
    if state_cond_status and state_cond_status[0]=="NEED_CONDITION":
        return ("Selecione a Condição/Característica aplicável antes de analisar.\n"
                "Opções normativas estaduais: " + " | ".join(state_cond_status[1]))
    if state_cond_status and state_cond_status[0]=="INVALID_CONDITION":
        return ("A condição selecionada não corresponde às linhas normativas estaduais desta atividade.\n"
                "Opções normativas estaduais: " + " | ".join(state_cond_status[1]))

    # Fallback por CNAE: importante quando a descrição da mesma atividade varia
    # entre CONSEMA e Decreto.
    if not fits and municipal_candidates:
        cnaes={str(r.get("CNAE") or "").strip() for r in municipal_candidates if r.get("CNAE")}
        by_cnae=[r for r in DECRETO if str(r.get("CNAE") or "").strip() in cnaes]
        by_cnae,bc_status=apply_condition(by_cnae,condition) if by_cnae else (by_cnae,None)
        if bc_status and bc_status[0]=="BLOCKED_CONDITION":
            return _blocked_message(activity)
        if bc_status and bc_status[0]=="NEED_CONDITION":
            return ("O reenquadramento estadual depende de Condição/Característica.\n"
                    "Opções normativas estaduais: " + " | ".join(bc_status[1]))
        if bc_status and bc_status[0]=="INVALID_CONDITION":
            return ("A condição informada não corresponde ao reenquadramento estadual.\n"
                    "Opções normativas estaduais: " + " | ".join(bc_status[1]))
        for r in by_cnae:
            ok,why=row_fit(r,value,unit)
            if ok is True:
                fits.append(r)
        if by_cnae:
            # Une candidatos para mensagens de unidade/porte abaixo do mínimo.
            seen={id(r) for r in cs}
            cs += [r for r in by_cnae if id(r) not in seen]

    if not fits:
        # TODO activities do not need porte
        if cs:
            norm_units=sorted({str(r.get("UNIDADE") or "") for r in cs})
            numeric_min=[fnum(r.get("MÍNIMO")) for r in cs if fnum(r.get("MÍNIMO")) is not None and unit_equiv(unit,r.get("UNIDADE"))]
            if value is not None and numeric_min and value<min(numeric_min):
                return (f"Município: {municipio}\nEnquadramento municipal: NÃO\n\n"
                        "Porte informado abaixo do menor enquadramento identificado na base normativa.\n"
                        "A eventual dispensa de licenciamento deve ser verificada junto ao órgão ambiental competente.")
            if value is None and all(norm(r.get("UNIDADE"))!="todo" for r in cs):
                return "Informe Porte/Capacidade. Unidade(s) normativa(s): "+", ".join(norm_units)
            if value is not None and unit and not any(unit_equiv(unit,r.get("UNIDADE")) for r in cs):
                return "Unidade incompatível com a base estadual. Unidade(s) normativa(s): "+", ".join(norm_units)
        return (f"Município: {municipio}\nEnquadramento municipal: NÃO\nCompetência: SEMA/MT\n\n"
                "Não foi localizado um enquadramento estadual compatível com segurança. Verificação manual necessária.")

    r=fits[0]
    modalidade=str(r.get("MODALIDADE") or "")
    if mining_ctx:
        if anm in {"Alvará de Pesquisa","Alvará de Pesquisa + GU"}:
            modalidade="LOPM"
        elif anm in {"PLG","Concessão de Lavra","Registro de Licença"}:
            modalidade="LP+LI+LO"
    desc="SIM" if municipio in MUNICIPIOS_GRUPO else "NÃO"
    res=(f"Município: {municipio}\nDescentralizado: {desc}\nGrupo municipal: {group_text}\n"
         f"Atividade: {display_activity(r.get('ATIVIDADE'))}\nCNAE: {r.get('CNAE')}\n"
         f"Unidade normativa: {display_unit(r.get('UNIDADE'))}\n"
         f"Porte informado: {porte+' '+unit if porte else 'Não aplicável'}\n")
    cond_final=row_condition(r)
    if cond_final: res+=f"Condição normativa: {cond_final}\n"
    if anm:res+=f"Regime ANM: {anm}\n"
    if motivo_municipal:
        res += f"Verificação municipal: {motivo_municipal}\n"
    res+=("\nEnquadramento municipal: NÃO\n"
          "Resultado: ATIVIDADE NÃO PASSÍVEL DE LICENCIAMENTO NO MUNICÍPIO\n"
          "Competência: SEMA/MT\n"
          f"Modalidade: {modalidade}\n"
          f"Base estadual: Decreto 1.585/2022 — Anexo {r.get('ANEXO')}")
    try:
        trs_planilha = texto_trs_planilha(r.get("ATIVIDADE"), modalidade, tipo_solicitacao, anm)
    except RuntimeError as exc:
        return res + "\n\nERRO NO CATÁLOGO DE TRs: " + str(exc)
    if trs_planilha:
        res += "\n" + trs_planilha
    else:
        res += "\nTR não localizado nas associações da planilha para esta atividade, modalidade e solicitação. Confira o cadastro; nenhum link genérico foi substituído pelo endereço informado."
    try:
        trs_especiais = texto_trs_especiais_estaduais(modalidade, tipo_solicitacao)
    except RuntimeError as exc:
        return res + "\n\nERRO NO CATÁLOGO DE TRs ESPECIAIS: " + str(exc)
    if trs_especiais:
        res += "\n\n" + trs_especiais
    return res


# ===== PADRONIZAÇÃO DE EXIBIÇÃO/PESQUISA =====
# Não altera ATIVIDADE/UNIDADE originais das bases embutidas.

def _clean_spaces(s):
    return " ".join(str(s or "").replace("\r"," ").replace("\n"," ").split())

def _display_key(s):
    s=unicodedata.normalize("NFKD",_clean_spaces(s))
    return "".join(c for c in s if not unicodedata.combining(c)).casefold()

ACTIVITY_DISPLAY_OVERRIDES={
    "tratamento de sementes":"Tratamento de sementes",
    "armazens de graos":"Armazéns de grãos",
    "producao de ovos (postura)":"Produção de ovos (postura)",
    "fabricacao de laticinios":"Fabricação de laticínios",
    "producao de pintinhos de um dia (incubatorio)":"Produção de pintinhos de um dia (incubatório)",
}

UNIT_DISPLAY_MAP={
    "todo":"Todo","m2":"m²","m²":"m²","m3":"m³","m³":"m³","ha":"ha","m":"m",
    "kg/dia":"kg/dia","t/dia":"t/dia",
    "litros/dia":"L/dia","litro/dia":"L/dia","l/dia":"L/dia",
    "litros/mes":"L/mês","litro/mes":"L/mês","l/mes":"L/mês",
    "m3/ano":"m³/ano","m³/ano":"m³/ano",
    "cabecas":"cabeças","cabecas/dia":"cabeças/dia","cabecas/ciclo":"cabeças/ciclo",
    "unidades":"unidades","unidades/ciclo":"unidades/ciclo","matrizes":"matrizes",
    "aves/dia":"aves/dia","duzias/dia":"dúzias/dia","pintinhos/mes":"pintinhos/mês",
    "veiculos":"veículos","classe anp":"Classe ANP","kv":"kV","mw":"MW","mwh":"MWh","mw/h":"MW/h",
}
def display_unit(u):
    raw=_clean_spaces(u); return UNIT_DISPLAY_MAP.get(_display_key(raw),raw)

_ACTIVITY_VARIANTS={}
for _r in CONSEMA+DECRETO:
    if _r.get("ATIVIDADE"):
        _ACTIVITY_VARIANTS.setdefault(_display_key(_r["ATIVIDADE"]),[]).append(str(_r["ATIVIDADE"]))

def _choose_activity_display(vals):
    vals=[_clean_spaces(v) for v in vals if _clean_spaces(v)]
    if not vals:return ""
    k=_display_key(vals[0])
    if k in ACTIVITY_DISPLAY_OVERRIDES:return ACTIVITY_DISPLAY_OVERRIDES[k]
    from collections import Counter
    counts=Counter(vals)
    first={v:i for i,v in enumerate(vals)}
    return sorted(counts,key=lambda v:(-counts[v],first[v]))[0]

ACTIVITY_DISPLAY_BY_KEY={k:_choose_activity_display(v) for k,v in _ACTIVITY_VARIANTS.items()}

# v1.27 — equivalências exclusivamente de exibição, auditadas entre as normas.
# A identificação normativa e todos os seus parâmetros continuam inalterados.
EQUIVALENCIAS_PUBLICAS = {
    "posto de abastecimento": ("Posto de abastecimento", (
        "Posto de abastecimento (tanque aéreo)",
        "Posto de abastecimento (tanque enterrado)")),
    "aerodromo": ("Aeródromo", ("Aeródromo", "Aeródromos")),
    "autodromo": ("Autódromo", ("Autódromo", "Autódromos")),
    "fabricacao de pos alimenticios": ("Fabricação de pós alimentícios", ("Fabricação de pós alimentício", "Fabricação de pós-alimentícios")),
    "centro de multiplo uso": ("Construção de centro de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares",
        ("Construção de centro de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares",
         "Construção de centros de múltiplo uso e/ou atividades de atendimento ao turista, centros de referência de assistência social e similares")),
    "urbanizacao de orlas": ("Obras de urbanização de orlas fluviais ou lacustres",
        ("Obras de urbanização de orlas fluviais ou lacustres",
         "Obras de urbanização de orlas fluviais ou lacustre")),
}
_NOME_PUBLICO_POR_VARIANTE = {
    norm(v): publico
    for publico, variantes in EQUIVALENCIAS_PUBLICAS.values()
    for v in variantes
}
_VARIANTES_POR_PUBLICO = {
    norm(publico): {norm(v) for v in variantes}
    for publico, variantes in EQUIVALENCIAS_PUBLICAS.values()
}
SUBTIPOS_ATIVIDADE = {
    "Posto de abastecimento": {
        "Tanque aéreo": "Posto de abastecimento (tanque aéreo)",
        "Tanque enterrado": "Posto de abastecimento (tanque enterrado)",
    }
}
def atividade_normativa_selecionada(nome_publico, subtipo):
    opcoes = SUBTIPOS_ATIVIDADE.get(nome_publico)
    if not opcoes:
        return nome_publico
    return opcoes.get(subtipo, "")

def _variantes_publicas(nome):
    return _VARIANTES_POR_PUBLICO.get(norm(nome), {norm(nome)})

def display_activity(a):
    raw=_clean_spaces(a); return _NOME_PUBLICO_POR_VARIANTE.get(norm(raw), ACTIVITY_DISPLAY_BY_KEY.get(_display_key(raw),raw))
def standardized_activities():
    return sorted({display_activity(r.get("ATIVIDADE")) for r in CONSEMA+DECRETO if r.get("ATIVIDADE")},key=norm)
def atividades_por_municipio(municipio):
    """Opções identificadas por origem, sem alterar o enquadramento normativo."""
    municipio=str(municipio or "").strip()
    estaduais=sorted({display_activity(r.get("ATIVIDADE")) for r in DECRETO if r.get("ATIVIDADE")},key=norm)
    if municipio in NAO_DESCENTRALIZADOS:
        return ["[DECRETO] "+nome for nome in estaduais]
    if municipio in MUNICIPIOS_GRUPO:
        grupo=MUNICIPIOS_GRUPO[municipio]
        municipais=sorted({display_activity(r.get("ATIVIDADE")) for r in CONSEMA
                          if r.get("ATIVIDADE") and str(r.get("GRUPO","")).strip()==grupo},key=norm)
        return (["[CONSEMA] "+nome for nome in municipais]+
                ["[DECRETO] "+nome for nome in estaduais])
    return []

def atividade_sem_origem(texto):
    texto=str(texto or "").strip()
    for prefixo in ("[DECRETO] ", "[CONSEMA] "):
        if texto.startswith(prefixo):
            return texto[len(prefixo):].strip()
    return texto

def standardized_units():
    return sorted({display_unit(r.get("UNIDADE")) for r in CONSEMA+DECRETO
                   if r.get("UNIDADE") and _display_key(r.get("UNIDADE"))!="todo"},key=norm)
def rows_for_display_activity(text,selected=False):
    n=norm(text)
    if selected:
        return [r for r in CONSEMA+DECRETO if norm(r.get("ATIVIDADE")) in _variantes_publicas(text)]
    rows=[r for r in CONSEMA+DECRETO if n and n in norm(display_activity(r.get("ATIVIDADE")))]
    return rows if rows else candidates(CONSEMA+DECRETO,text)

def contextual_rows_for_activity(municipio,text,selected=False):
    municipio=str(municipio or "").strip()
    if municipio in MUNICIPIOS_GRUPO:
        g=MUNICIPIOS_GRUPO[municipio]
        rows=candidates(CONSEMA,text,g)
        if selected:
            exact=[r for r in rows if norm(r.get("ATIVIDADE")) in _variantes_publicas(text)]
            if exact: rows=exact
        if rows: return rows
        rows=candidates(DECRETO,text)
        if selected:
            exact=[r for r in rows if norm(r.get("ATIVIDADE")) in _variantes_publicas(text)]
            if exact: rows=exact
        return rows
    if municipio in NAO_DESCENTRALIZADOS:
        rows=candidates(DECRETO,text)
        if selected:
            exact=[r for r in rows if norm(r.get("ATIVIDADE")) in _variantes_publicas(text)]
            if exact: rows=exact
        return rows
    return rows_for_display_activity(text,selected=selected)

class SearchCombo(ttk.Combobox):
    """Combobox pesquisável com sugestões sem roubar o foco da digitação."""
    def __init__(self, master, values=(), on_pick=None, **kw):
        self.all_values=list(values)
        self.on_pick=on_pick
        super().__init__(master, values=[atividade_sem_origem(v) for v in self.all_values], **kw)
        self.bind("<KeyRelease>", self._filter)
        self.bind("<<ComboboxSelected>>", self._native_selected)
        self.bind("<FocusOut>", self._focus_out)
        self.bind("<Down>", self._focus_suggestions)
        self._popup=None
        self._listbox=None
        self._display_to_raw=[]
        self.selected_raw=None

    def set_values(self, values, keep_text=True):
        old=self.get()
        self.all_values=list(values)
        self["values"]=[atividade_sem_origem(v) for v in self.all_values]
        if keep_text:self.set(old)

    def reset_filter(self):
        """Restaura no dropdown todos os valores originais do campo."""
        self._display_to_raw=self.all_values
        self["values"]=[atividade_sem_origem(v) for v in self.all_values]
        self._hide_popup()

    def _matches(self):
        typed=self.get()
        n=norm(typed)
        if not n:return self.all_values
        starts=[v for v in self.all_values if norm(atividade_sem_origem(v)).startswith(n)]
        contains=[v for v in self.all_values if n in norm(atividade_sem_origem(v)) and v not in starts]
        return starts+contains

    def _filter(self,event=None):
        if event and event.keysym in {"Up","Down","Left","Right","Return","Escape","Tab","Shift_L","Shift_R","Control_L","Control_R"}:
            if event.keysym=="Escape":self._hide_popup()
            return
        self.selected_raw=None
        vals=self._matches()
        self._display_to_raw=vals
        self["values"]=[atividade_sem_origem(v) for v in vals]
        if not self.get().strip():
            self._display_to_raw=self.all_values
            self["values"]=[atividade_sem_origem(v) for v in self.all_values]
        if self.get().strip() and vals:
            self._show_popup(vals[:12])
        else:
            self._hide_popup()
        if self.on_pick:self.on_pick(self.get(),False)

    def _show_popup(self,vals):
        self.update_idletasks()
        if self._popup is None or not self._popup.winfo_exists():
            self._popup=tk.Toplevel(self)
            self._popup.overrideredirect(True)
            self._popup.attributes("-topmost",True)
            self._listbox=tk.Listbox(self._popup,height=min(10,len(vals)),font=("Quicksand",10),
                                      activestyle="dotbox",exportselection=False)
            self._listbox.pack(fill="both",expand=True)
            self._listbox.bind("<ButtonRelease-1>",self._choose)
            self._listbox.bind("<Return>",self._choose)
            self._listbox.bind("<Escape>",lambda e:self._hide_popup())
        self._listbox.delete(0,"end")
        self._popup_raw=list(vals)
        for v in vals:self._listbox.insert("end",atividade_sem_origem(v))
        self._listbox.configure(height=max(1,min(10,len(vals))))
        x=self.winfo_rootx()
        y=self.winfo_rooty()+self.winfo_height()
        w=max(self.winfo_width(),420)
        h=min(10,len(vals))*24+4
        self._popup.geometry(f"{w}x{h}+{x}+{y}")
        self._popup.deiconify()
        self._popup.lift()

    def _choose(self,event=None):
        if not self._listbox:return
        sel=self._listbox.curselection()
        if not sel:return
        raw=self._popup_raw[sel[0]]
        val=atividade_sem_origem(raw)
        self.selected_raw=raw
        self.set(val)
        self._hide_popup()
        self.focus_set()
        self.icursor("end")
        if self.on_pick:self.on_pick(val,True)

    def _focus_suggestions(self,event=None):
        vals=self._matches()
        if vals:
            self._show_popup(vals[:12])
            self._listbox.focus_set()
            self._listbox.selection_clear(0,"end")
            self._listbox.selection_set(0)
            self._listbox.activate(0)
            return "break"

    def _native_selected(self,event=None):
        idx=self.current()
        self.selected_raw=(self._display_to_raw[idx] if 0<=idx<len(self._display_to_raw) else None)
        self._hide_popup()
        if self.on_pick:self.on_pick(self.get(),True)

    def _focus_out(self,event=None):
        # pequeno atraso permite clicar na sugestão antes de fechar
        self.after(180,self._hide_if_not_popup_focus)

    def _hide_if_not_popup_focus(self):
        try:
            focus=self.focus_get()
            if self._listbox is not None and focus==self._listbox:return
        except:pass
        self._hide_popup()

    def _hide_popup(self):
        try:
            if self._popup is not None and self._popup.winfo_exists():
                self._popup.withdraw()
        except:pass

class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("ÓIKOS — Classificador Ambiental MT — v1.36.2")
        # Ícone da janela Tk (independente do ícone embutido no executável).
        # No PyInstaller --onefile, os recursos são extraídos para sys._MEIPASS.
        import sys
        pasta_recursos = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parent))
        caminho_icone = pasta_recursos / "OIKOS_Icone_Oficial.ico"
        if caminho_icone.is_file():
            try:
                self.iconbitmap(default=str(caminho_icone))
            except tk.TclError:
                pass
        self.geometry("1220x820"); self.minsize(1060,720)
        # Identidade visual: marrom e verde aprovados; sem alterações nos controles de pesquisa.
        MARROM="#522A00"
        VERDE="#6FB64E"
        FUNDO="#FAF9F6"
        TEXTO="#30352E"
        self.configure(bg=FUNDO)
        estilo=ttk.Style(self)
        if "clam" in estilo.theme_names():
            estilo.theme_use("clam")
        # Apenas tipografia: fontes padrão Tk/ttk, sem modificar callbacks ou layout.
        import tkinter.font as tkfont
        for nome in ("TkDefaultFont", "TkTextFont", "TkFixedFont", "TkMenuFont", "TkHeadingFont", "TkCaptionFont", "TkSmallCaptionFont", "TkIconFont", "TkTooltipFont"):
            try:
                tkfont.nametofont(nome).configure(family="Quicksand")
            except tk.TclError:
                pass
        self.option_add("*Font", "Quicksand 10")
        self.option_add("*TCombobox*Listbox.font", "Quicksand 10")
        estilo.configure("TFrame",background=FUNDO)
        estilo.configure("TLabel",background=FUNDO,foreground=TEXTO,font=("Quicksand",10))
        estilo.configure("Cabecalho.TLabel",background=FUNDO,foreground=MARROM,font=("Quicksand",21,"bold"))
        estilo.configure("Subtitulo.TLabel",background=FUNDO,foreground="#657064",font=("Quicksand",9))
        estilo.configure("Dica.TLabel",background=FUNDO,foreground="#507D43",font=("Quicksand",9))
        estilo.configure("Resultado.TLabel",background=FUNDO,foreground=MARROM,
                         font=("Quicksand",11,"bold"))
        estilo.configure("TEntry",padding=7,font=("Quicksand",10))
        estilo.configure("TCombobox",padding=6,font=("Quicksand",10))
        estilo.configure("Primario.TButton",font=("Quicksand",10,"bold"),padding=(14,10),
                         foreground="#FFFFFF",background=MARROM,borderwidth=0)
        estilo.map("Primario.TButton",background=[("active","#75431B"),("pressed","#3D1F00")])
        estilo.configure("Secundario.TButton",font=("Quicksand",10,"bold"),padding=(14,10),
                         foreground="#FFFFFF",background=VERDE,borderwidth=0)
        estilo.map("Secundario.TButton",background=[("active","#579C38"),("pressed","#48872C")])
        estilo.configure("Terciario.TButton",font=("Quicksand",9),padding=(12,8),
                         foreground=MARROM,background="#EAF1E5")
        estilo.map("Terciario.TButton",background=[("active","#E0ECD9")])
        # Painel com menu lateral; componentes de pesquisa originais preservados.
        self.sidebar=tk.Frame(self,bg=MARROM,width=270)
        self.sidebar.pack(side="left",fill="y")
        self.sidebar.pack_propagate(False)
        # Logo oficial da Macan, recortada em PNG transparente para a barra lateral.
        # Referência persistente para evitar coleta de lixo do PhotoImage pelo Tkinter.
        # Marca Macan preservada; textos Óikos em Quicksand nativo do Tk.
        cabecalho_marca=tk.Frame(self.sidebar,bg=MARROM,height=100)
        cabecalho_marca.pack(fill="x",pady=(4,0))
        cabecalho_marca.pack_propagate(False)
        self._logo_macan_lateral=tk.PhotoImage(file=str(Path(__file__).resolve().parent / "assets" / "logo_macan_simbolo_texto.png"))
        tk.Label(cabecalho_marca,image=self._logo_macan_lateral,bg=MARROM,
                 bd=0).pack(side="left",padx=(8,9))
        area_nome=tk.Frame(cabecalho_marca,bg=MARROM)
        area_nome.pack(side="left",fill="both",expand=True,pady=(4,1))
        tk.Label(area_nome,text="ÓIKOS",font=("Quicksand",15,"bold"),
                 bg=MARROM,fg="white",anchor="w").pack(fill="x")
        tk.Label(area_nome,text="Inteligência em\nenquadramento\nambiental",
                 font=("Quicksand",8),bg=MARROM,fg="white",
                 justify="left",anchor="w").pack(fill="x",pady=(4,0))
        tk.Frame(self.sidebar,bg="#927252",height=1).pack(fill="x",padx=18,pady=(0,18))
        # Ícones PNG suavizados: somente decoração dos botões existentes.
        # Não modificar comandos, widgets de pesquisa ou eventos de seleção.
        self._nav_imagens={}
        pasta_icones=Path(__file__).resolve().parent / "icons"
        tipos_icones={"Classificador":"leaf",
                      "Consulta de Municípios":"map",
                      "Termos de Referência":"check",
                      "Base Normativa":"book","Atualizações":"info","Sobre":"info"}
        self.nav_botoes={}
        for nome in ("Classificador","Consulta de Municípios","Termos de Referência","Base Normativa","Atualizações","Sobre"):
            b=tk.Button(self.sidebar,text=nome,anchor="w",relief="flat",bd=0,
                        bg=MARROM,fg="#F8F4ED",activebackground="#67401F",
                        activeforeground="white",font=("Quicksand",10),
                        padx=12,pady=14,cursor="hand2",
                        command=lambda n=nome:self.mostrar_pagina(n))
            tipo=tipos_icones[nome]
            try:
                normal=tk.PhotoImage(file=str(pasta_icones / (tipo+"_normal.png")))
                ativo=tk.PhotoImage(file=str(pasta_icones / (tipo+"_active.png")))
                self._nav_imagens[nome]=(normal,ativo)
                b.configure(image=normal,compound="left")
            except (tk.TclError,OSError):
                pass  # Ícones opcionais; o botão e a navegação seguem funcionando.
            b.pack(fill="x",padx=12,pady=4)
            self.nav_botoes[nome]=b
        tk.Label(self.sidebar,text="v1.36.2  •  Mato Grosso",bg=MARROM,fg="#E1D4C6",
                 font=("Quicksand",9)).pack(side="bottom",pady=20)
        self.workspace=tk.Frame(self,bg=FUNDO)
        self.workspace.pack(side="left",fill="both",expand=True)
        self.paginas={}
        self._pesquisas_auxiliares={}
        f=ttk.Frame(self.workspace,padding=(24,20,24,20))
        self.paginas["Classificador"]=f
        # Marca-d'água decorativa exclusiva da página Classificador.
        # Widget de fundo, sem binds, sem foco e sem interceptar entradas.
        # A imagem é pré-processada em PNG: Pillow NÃO é necessário para executar.
        self._marca_agua_foto=tk.PhotoImage(file=str(Path(__file__).resolve().parent / "assets" / "marca_agua_60.png"))
        self._marca_agua_fundo=tk.Label(f,image=self._marca_agua_foto,
                                       bg=FUNDO,bd=0,highlightthickness=0,
                                       takefocus=0)
        self._marca_agua_fundo.place(relx=0.63,rely=0.67,anchor="center")
        self._marca_agua_fundo.lower()
        self._cores_painel=(MARROM,VERDE,FUNDO,TEXTO)

        # Cabeçalho visual: apenas Frames e Labels, sem Canvas e sem eventos de foco.
        cabecalho_externo=tk.Frame(f,bg="#DCE7D5",bd=0)
        cabecalho_externo.grid(row=0,column=0,columnspan=3,sticky="ew",pady=(0,4))
        cabecalho_interno=tk.Frame(cabecalho_externo,bg="#FFFFFF",bd=0,height=61)
        cabecalho_interno.pack(fill="x",padx=1,pady=1)
        cabecalho_interno.pack_propagate(False)
        tk.Frame(cabecalho_interno,bg=VERDE,width=4).pack(side="left",fill="y",padx=(12,15),pady=14)
        tk.Label(cabecalho_interno,text="CLASSIFICADOR AMBIENTAL MT",
                 bg="#FFFFFF",fg=MARROM,font=("Quicksand",18,"bold"),
                 anchor="w").pack(side="left",fill="y")
        ttk.Label(f,text="CONSEMA nº 74/2025  •  Decreto nº 1.585/2022  •  Catálogo de TRs",style="Subtitulo.TLabel").grid(row=1,column=0,columnspan=2,sticky="w",pady=(0,16))

        ttk.Label(f,text="Município").grid(row=2,column=0,sticky="w")
        self.m=SearchCombo(f,values=TODOS_MUNICIPIOS_MT,on_pick=self.municipality_changed,width=32)
        self.m.grid(row=3,column=0,sticky="ew",padx=(0,10),pady=(5,14))

        ttk.Label(f,text="Atividade — digite qualquer parte do nome").grid(row=2,column=1,columnspan=2,sticky="w")
        acts=[]
        self._atividades_validas=set()
        self.a=SearchCombo(f,values=acts,on_pick=self.activity_changed,width=60)
        self.a.grid(row=3,column=1,columnspan=2,sticky="ew",pady=(5,14))

        # Organização visual dos parâmetros: condições à esquerda,
        # porte no centro e unidade à direita. Não altera valores/eventos.
        parametros_cond=ttk.Frame(f)
        parametros_cond.grid(row=4,column=0,rowspan=2,sticky="new",padx=(0,10))
        parametros_cond.columnconfigure(0,weight=1)

        ttk.Label(f,text="Porte/Capacidade").grid(row=4,column=1,sticky="w")
        self.p=ttk.Entry(f)
        self.p.grid(row=5,column=1,sticky="ew",padx=(0,10),pady=(5,14))

        ttk.Label(f,text="Unidade — associada à atividade").grid(row=4,column=2,sticky="w")
        all_units=standardized_units()
        self.all_units=all_units
        self.u=SearchCombo(f,values=all_units)
        self.u.grid(row=5,column=2,sticky="ew",pady=(5,14))

        self.anm_label=ttk.Label(parametros_cond,text="Regime ANM (mineração)")
        self.anm_label.grid(row=0,column=0,sticky="w")
        self.anm=ttk.Combobox(parametros_cond,state="readonly",values=["","PLG","Alvará de Pesquisa","Alvará de Pesquisa + GU","Concessão de Lavra","Registro de Licença"])
        self.anm.grid(row=1,column=0,sticky="ew",pady=(5,10))
        self.anm_label.grid_remove()
        self.anm.grid_remove()

        self.tipo_tr = ttk.Combobox(f,state="readonly",values=["Inicial", "Renovação"],width=18)
        self.tipo_tr.set("Inicial")
        ttk.Label(f,text="Tipo de solicitação do TR").grid(row=0,column=2,sticky="w")
        self.tipo_tr.grid(row=1,column=2,sticky="ew",pady=(0,12))

        self.subtipo_label=ttk.Label(parametros_cond,text="Tipo de tanque — seleção obrigatória")
        self.subtipo=ttk.Combobox(parametros_cond,state="readonly")
        self.subtipo_label.grid(row=2,column=0,sticky="w")
        self.subtipo.grid(row=3,column=0,sticky="ew",pady=(5,10))
        self.subtipo_label.grid_remove()
        self.subtipo.grid_remove()
        self.subtipo.bind("<<ComboboxSelected>>", self.subtipo_changed)

        self.cond_label=ttk.Label(parametros_cond,text="Condição/Característica — selecione a situação aplicável",wraplength=270)
        self.cond=ttk.Combobox(parametros_cond,state="readonly")
        self.cond_label.grid(row=4,column=0,sticky="w")
        self.cond.grid(row=5,column=0,sticky="ew",pady=(5,10))
        self.cond_label.grid_remove()
        self.cond.grid_remove()

        self.hint=ttk.Label(f,text="Digite no Município ou Atividade para filtrar resultados compatíveis.",style="Dica.TLabel")
        self.hint.grid(row=10,column=0,columnspan=3,sticky="w",pady=(0,8))

        # Linha de ações equilibrada: principal, secundária e limpeza.
        botoes=ttk.Frame(f)
        botoes.grid(row=11,column=0,columnspan=3,sticky="ew",pady=(0,15))
        botoes.columnconfigure(0,weight=5)
        botoes.columnconfigure(1,weight=3)
        botoes.columnconfigure(2,weight=2)
        ttk.Button(botoes,text="ANALISAR",command=self.go,style="Primario.TButton").grid(row=0,column=0,sticky="ew",padx=(0,8))
        ttk.Button(botoes,text="VERIFICAR LINKS TR",command=self.verificar_trs_online,style="Secundario.TButton").grid(row=0,column=1,sticky="ew",padx=(0,8))
        ttk.Button(botoes,text="LIMPAR CAMPOS",command=self.clear_fields,style="Terciario.TButton").grid(row=0,column=2,sticky="ew")

        # Cartões de síntese: somente apresentação, sem alterar analyze().
        resumo=tk.Frame(f,bg=FUNDO)
        resumo.grid(row=12,column=0,columnspan=3,sticky="ew",pady=(2,18))
        resumo.columnconfigure(0,weight=1)
        resumo.columnconfigure(1,weight=1)
        resumo.columnconfigure(2,weight=1)
        self._resumo_campos={}
        for indice,(chave,titulo) in enumerate((
            ("competencia","COMPETÊNCIA AMBIENTAL"),
            ("modalidade","MODALIDADE"),
            ("situacao","SITUAÇÃO DO ENQUADRAMENTO"))):
            # Moldura arredondada puramente decorativa: os Labels e suas
            # referencias permanecem intactos, assim como toda a logica.
            moldura=tk.Canvas(resumo,bg=FUNDO,highlightthickness=0,
                              bd=0,height=118)
            moldura.grid(row=0,column=indice,sticky="nsew",
                         padx=(0,8) if indice<2 else (0,0))
            cartao=tk.Frame(moldura,bg="#FFFFFF",padx=17,pady=14)
            janela=moldura.create_window(1,1,window=cartao,anchor="nw")
            def ajustar_moldura(event,canvas=moldura,window=janela):
                w=max(event.width,4)
                h=max(event.height,4)
                canvas.delete("borda_decorativa")
                r=15
                pontos=[r,1,w-r,1,w-1,1,w-1,r,w-1,h-r,
                        w-1,h-1,w-r,h-1,r,h-1,1,h-1,1,h-r,1,r,1,1]
                canvas.create_polygon(pontos,smooth=True,splinesteps=16,
                                      fill="#FFFFFF",outline="#CBDDC1",
                                      width=1.5,tags="borda_decorativa")
                canvas.tag_lower("borda_decorativa")
                canvas.coords(window,3,3)
                # Nao fixar a altura do Frame: o conteudo precisa crescer
                # quando um resultado extenso ocupa varias linhas.
                canvas.itemconfigure(window,width=max(w-6,1))
                largura_texto=max(w-46,90)
                for filho in cartao.winfo_children():
                    if isinstance(filho,tk.Label) and filho.cget("wraplength"):
                        filho.configure(wraplength=largura_texto)
            moldura.bind("<Configure>",ajustar_moldura)
            def ajustar_altura(event,canvas=moldura,frame=cartao):
                # Atualiza somente se a altura solicitada realmente mudou.
                altura=max(112,frame.winfo_reqheight()+6)
                if int(canvas.cget("height"))!=altura:
                    canvas.configure(height=altura)
            cartao.bind("<Configure>",ajustar_altura)
            tk.Label(cartao,text=titulo,bg="#FFFFFF",fg="#67452A",
                     font=("Quicksand",9,"bold"),anchor="w").pack(fill="x")
            valor=tk.Label(cartao,text="Aguardando análise",bg="#FFFFFF",fg=MARROM,
                           font=("Quicksand",12,"bold"),anchor="w",
                           justify="left",wraplength=220)
            valor.pack(fill="x",pady=(9,0))
            self._resumo_campos[chave]=valor

        # Título da área de resultados, independente do conteúdo do Text.
        ttk.Label(f,text="RESULTADO DO ENQUADRAMENTO",style="Resultado.TLabel").grid(
            row=13,column=0,columnspan=3,sticky="w",pady=(0,10))
        self.out=tk.Text(f,wrap="word",font=("Quicksand",10),padx=18,pady=18,
                         bg="#FFFFFF",fg=TEXTO,insertbackground=MARROM,relief="solid",bd=1,
                         highlightthickness=1,highlightbackground="#CBDDC1")
        self.out.grid(row=14,column=0,columnspan=3,sticky="nsew")
        self.out.insert("1.0","Preencha os dados e clique em ANALISAR.\n\nVocê pode digitar apenas parte do nome da atividade, município ou unidade para filtrar a lista.")
        for c in range(3):f.columnconfigure(c,weight=1)
        f.rowconfigure(14,weight=1)
        self._atualizacao_estado = "Verificação automática ainda não realizada."
        self._atualizacao_bases = []
        self._atualizacao_catalogo_ids = {"municipios", "trs_sema", "trs_municipais", "normas"}
        self._atualizacao_nomes = {"municipios": "Municípios descentralizados", "trs_sema": "TRs da SEMA", "trs_municipais": "TRs municipais e consórcios", "normas": "Base normativa"}
        # Versões reais das bases internas não foram publicadas separadamente.
        # Nunca inferir que uma base online está aplicada apenas pela versão do aplicativo.
        self._atualizacao_versoes_locais = {k: None for k in self._atualizacao_catalogo_ids}
        # Registro documental local. Valores ausentes permanecem desconhecidos.
        try:
            caminho = Path(__file__).resolve().parent / "versoes_locais.json"
            if caminho.is_file():
                with caminho.open("r", encoding="utf-8") as arquivo:
                    dados_locais = json.load(arquivo)
                if isinstance(dados_locais, dict) and dados_locais.get("schema_version") == 1:
                    bases_locais = dados_locais.get("bases", {})
                    if isinstance(bases_locais, dict):
                        for chave in self._atualizacao_catalogo_ids:
                            item = bases_locais.get(chave)
                            if isinstance(item, dict):
                                versao = item.get("versao")
                                if isinstance(versao, str) and 0 < len(versao) <= 80:
                                    self._atualizacao_versoes_locais[chave] = versao
        except (OSError, ValueError, TypeError, AttributeError):
            pass
        self._atualizacao_em_andamento = False
        self._atualizacao_status_var = None
        self._atualizacao_painel = None
        self._atualizacao_botao = None
        self.mostrar_pagina("Classificador")
        self.after(1300, lambda: self._verificar_atualizacoes_33_1(automatico=True))

    def mostrar_pagina(self,nome):
        for pagina in self.paginas.values():
            pagina.pack_forget()
        pagina=self.paginas.get(nome)
        if pagina is None:
            pagina=self._construir_pagina_auxiliar(nome)
            self.paginas[nome]=pagina
        pagina.pack(fill="both",expand=True)
        # Ativar os campos após o Tk mapear a página auxiliar no Windows.
        # Não altera os dados nem os eventos de consulta das bases.
        if nome in ("Termos de Referência", "Base Normativa"):
            def ativar_campo_auxiliar():
                try:
                    if not pagina.winfo_ismapped():
                        return
                    campo = self._pesquisas_auxiliares.get(nome)
                    if campo is not None and campo.winfo_exists():
                        campo.configure(state="normal")
                        campo.focus_set()
                except tk.TclError:
                    pass
            self.after_idle(ativar_campo_auxiliar)
            self.after(120, ativar_campo_auxiliar)
        # Não forçar foco ao trocar de aba: o Windows pode manter um foco
        # visual fictício até que o usuário interaja com o Entry.
        for titulo,botao in self.nav_botoes.items():
            ativo=(titulo==nome)
            botao.configure(bg="#6B4523" if ativo else self._cores_painel[0],
                            fg="#FFFFFF" if ativo else "#F8F4ED",
                            font=("Quicksand",10,"bold" if ativo else "normal"))
            if titulo in self._nav_imagens:
                normal,imagem_ativa=self._nav_imagens[titulo]
                botao.configure(image=imagem_ativa if ativo else normal)

    def _construir_pagina_auxiliar(self,nome):
        marrom,verde,fundo,texto=self._cores_painel
        pagina=tk.Frame(self.workspace,bg=fundo,padx=30,pady=28)
        # Marca-d'água nas abas auxiliares: a mesma imagem e opacidade da
        # aba Classificador. Somente decorativa, atrás dos controles opacos.
        marca_aux=tk.Label(pagina,image=self._marca_agua_foto,bg=fundo,
                           bd=0,highlightthickness=0,takefocus=0)
        marca_aux.place(relx=0.63,rely=0.67,anchor="center")
        marca_aux.lower()
        # Cabeçalho com faixa decorativa arredondada, sem alterar navegação.
        titulo_aux=tk.Canvas(pagina,bg=fundo,highlightthickness=0,bd=0,height=65)
        titulo_aux.pack(fill="x",pady=(0,17))
        def desenhar_titulo_aux(event):
            largura=max(event.width,12)
            titulo_aux.delete("all")
            raio=13
            pontos=[raio,1,largura-raio,1,largura-1,1,
                    largura-1,raio,largura-1,64-raio,
                    largura-1,63,largura-raio,63,raio,63,
                    1,63,1,64-raio,1,raio,1,1]
            titulo_aux.create_polygon(pontos,smooth=True,splinesteps=16,
                                     fill="#FFFFFF",outline="#DCE7D5",width=1)
            titulo_aux.create_rectangle(13,15,17,49,fill=verde,outline=verde)
            titulo_aux.create_text(32,32,text=nome.upper(),anchor="w",
                                   fill=marrom,font=("Quicksand",18,"bold"))
        titulo_aux.bind("<Configure>",desenhar_titulo_aux)
        # Moldura arredondada apenas decorativa para as abas auxiliares.
        # Os controles e suas ligacoes continuam no Frame original.
        moldura_aux=tk.Canvas(pagina,bg=fundo,highlightthickness=0,bd=0)
        # A Central de Atualizações possui mais controles que a altura visível.
        # Apenas nesta aba, permitir rolagem sem alterar os comandos de navegação.
        if nome == "Atualizações":
            barra_atualizacoes = ttk.Scrollbar(pagina, orient="vertical",
                                               command=moldura_aux.yview)
            barra_atualizacoes.pack(side="right", fill="y")
            moldura_aux.configure(yscrollcommand=barra_atualizacoes.set)
            moldura_aux.pack(side="left", fill="both", expand=True)
        else:
            moldura_aux.pack(fill="both",expand=True)
        # Canvas cobre o fundo do Frame: desenhar nele a mesma marca,
        # mantendo a imagem abaixo do cartão branco e de seus widgets.
        imagem_aux=moldura_aux.create_image(0,0,image=self._marca_agua_foto,
                                           anchor="center",tags="marca_aux")
        def posicionar_marca_aux(event):
            # Posicionamento relativo ao painel principal (sem redimensionar).
            x=0.63*pagina.winfo_width()-30
            y=0.67*pagina.winfo_height()-28-65-17
            moldura_aux.coords(imagem_aux,x,y)
            moldura_aux.tag_lower(imagem_aux)
        moldura_aux.bind("<Configure>",posicionar_marca_aux,add="+")
        cartao=tk.Frame(moldura_aux,bg="#FFFFFF",padx=24,pady=24)
        janela_aux=moldura_aux.create_window(3,3,window=cartao,anchor="nw")
        def ajustar_cartao_aux(event):
            largura=max(event.width,8)
            altura=max(event.height,8)
            moldura_aux.delete("borda_aux")
            raio=17
            pontos=[raio,1,largura-raio,1,largura-1,1,
                    largura-1,raio,largura-1,altura-raio,
                    largura-1,altura-1,largura-raio,altura-1,
                    raio,altura-1,1,altura-1,1,altura-raio,1,raio,1,1]
            moldura_aux.create_polygon(pontos,smooth=True,splinesteps=16,
                         fill="#FFFFFF",outline="#CBDDC1",width=1.5,tags="borda_aux")
            moldura_aux.tag_lower("borda_aux")
            moldura_aux.coords(janela_aux,3,3)
            if nome == "Atualizações":
                altura_conteudo = max(cartao.winfo_reqheight(), altura-6)
                moldura_aux.itemconfigure(janela_aux, width=max(largura-6,1),
                                         height=altura_conteudo)
                moldura_aux.configure(scrollregion=(0, 0, largura,
                                                     altura_conteudo+6))
            else:
                moldura_aux.itemconfigure(janela_aux,width=max(largura-6,1),
                                         height=max(altura-6,1))
        moldura_aux.bind("<Configure>",ajustar_cartao_aux)
        if nome == "Atualizações":
            def atualizar_altura_atualizacoes(event=None):
                altura_visivel = moldura_aux.winfo_height()
                largura_visivel = moldura_aux.winfo_width()
                altura_conteudo = max(cartao.winfo_reqheight(), altura_visivel-6)
                moldura_aux.itemconfigure(janela_aux,
                                         height=max(altura_conteudo,1))
                moldura_aux.configure(scrollregion=(0,0,
                                                     max(largura_visivel,1),
                                                     altura_conteudo+6))
            cartao.bind("<Configure>", atualizar_altura_atualizacoes, add="+")
            # Windows: eventos <Leave> do Canvas podem ocorrer ao entrar em
            # botoes/frames filhos. Escutar a roda uma unica vez e conferir
            # a posicao real do cursor, sem interferir nas outras abas.
            def rolar_atualizacoes(event):
                if not moldura_aux.winfo_exists() or not moldura_aux.winfo_ismapped():
                    return
                x, y = moldura_aux.winfo_pointerxy()
                x0 = moldura_aux.winfo_rootx()
                y0 = moldura_aux.winfo_rooty()
                if not (x0 <= x < x0 + moldura_aux.winfo_width() and
                        y0 <= y < y0 + moldura_aux.winfo_height()):
                    return
                if event.delta:
                    passos = max(1, abs(event.delta) // 120)
                    moldura_aux.yview_scroll((-1 if event.delta > 0 else 1) * passos, "units")
                    return "break"
            # add='+' preserva eventuais vinculos globais existentes.
            pagina.bind_all("<MouseWheel>", rolar_atualizacoes, add="+")
        if nome=="Consulta de Municípios":
            self._montar_consulta_competencia(cartao)
        elif nome=="Termos de Referência":
            tk.Label(cartao,text="CONSULTA AO CATÁLOGO DE TRs",bg="white",fg=marrom,
                     font=("Quicksand",12,"bold")).pack(anchor="w",pady=(0,12))
            tk.Label(cartao,text="Pesquise pelo número do TR ou por parte da atividade.",
                     bg="white",fg=texto).pack(anchor="w")
            busca=ttk.Entry(cartao)
            busca.pack(fill="x",pady=(8,12))
            self._pesquisas_auxiliares[nome]=busca
# No Windows, ttk.Entry pode mostrar cursor sem assumir o foco real
            # ao abrir páginas auxiliares criadas sob demanda.
            busca.bind("<ButtonPress-1>", lambda e, w=busca: w.focus_set(), add="+")
            busca.bind("<ButtonRelease-1>", lambda e, w=busca: w.after(10, w.focus_set), add="+")
            # Botão acima da área expansível de resultados: evita corte na base
            # quando a janela está maximizada ou há muitos resultados.
            ttk.Button(cartao,text="PESQUISAR TR",command=lambda: pesquisar(),
                       style="Primario.TButton").pack(anchor="w",pady=(0,12))
            saida=tk.Text(cartao,wrap="word",font=("Quicksand",10),
                          bg="#FFFFFF",fg=texto,relief="flat",padx=5,pady=8)
            saida.pack(fill="both",expand=True)
            # Cada URL cadastrado recebe uma tag clicável no próprio resultado.
            import webbrowser
            saida.tag_configure("link_tr",foreground="#286B45",underline=True)
            saida.tag_bind("link_tr","<Enter>",lambda e: saida.configure(cursor="hand2"))
            saida.tag_bind("link_tr","<Leave>",lambda e: saida.configure(cursor="xterm"))
            self._links_tr_resultado={}
            def abrir_link_tr(event):
                indice=saida.index(f"@{event.x},{event.y}")
                for tag in saida.tag_names(indice):
                    url=self._links_tr_resultado.get(tag)
                    if url:
                        webbrowser.open(url)
                        return "break"
            saida.tag_bind("link_tr","<Button-1>",abrir_link_tr)
            def pesquisar(_event=None):
                termo=norm(busca.get().strip())
                saida.configure(state="normal")
                saida.delete("1.0","end")
                self._links_tr_resultado.clear()
                if not termo:
                    saida.insert("end","Digite um número ou atividade para consultar os TRs associados na planilha.")
                else:
                    try:
                        registros=json.loads(TR_ASSOCIACOES_PATH.read_text(encoding="utf-8")).get("registros",[])
                    except (OSError,ValueError,TypeError) as exc:
                        saida.insert("end",f"Erro ao carregar o catálogo: {exc}\n")
                        registros=[]
                    try:
                        solicitacoes=carregar_solicitacoes_tr()
                    except RuntimeError as exc:
                        saida.insert("end",f"Erro ao carregar solicitações de TR: {exc}\\n")
                        solicitacoes=[]
                    try:
                        complementares=buscar_trs_complementares(termo)
                    except RuntimeError as exc:
                        saida.insert("end",f"Erro ao carregar TRs complementares: {exc}\n")
                        complementares=[]
                    grupos=buscar_grupos_trs(registros,termo,solicitacoes)
                    if not grupos and not complementares:
                        saida.insert("end","Nenhuma atividade ou TR correspondente encontrado na base. Verifique a grafia.")
                    for grupo in grupos[:45]:
                        saida.insert("end",grupo["titulo"]+"\n")
                        trs_numerados=[linha for linha in grupo["trs"] if str(linha["numero"]).strip().isdigit()]
                        if grupo.get("solicitacoes"):
                            for pedido in grupo["solicitacoes"]:
                                tipo=pedido.get("tipo_solicitacao") or "Solicitação não especificada"
                                saida.insert("end",f"  Solicitar TR ao órgão — {tipo}.\\n")
                                if pedido.get("observacoes"):
                                    saida.insert("end",f"  Observação: {pedido['observacoes']}\\n")
                        elif not trs_numerados:
                            saida.insert("end","  TR não cadastrado: consultar/solicitar TR ao órgão.\\n")
                        for linha in trs_numerados:
                            saida.insert("end",f"  TR nº {linha['numero']} — {linha['modalidade']} — {linha['tipo']}\n")
                            if linha["pagina"]:
                                url=linha["pagina"]
                                saida.insert("end","  Acessar página do TR: ")
                                indice_inicio=saida.index("end-1c")
                                saida.insert("end",url)
                                indice_fim=saida.index("end-1c")
                                tag=f"url_tr_{len(self._links_tr_resultado)}"
                                self._links_tr_resultado[tag]=url
                                saida.tag_add("link_tr",indice_inicio,indice_fim)
                                saida.tag_add(tag,indice_inicio,indice_fim)
                                saida.insert("end","\n")
                            else:
                                saida.insert("end","  Página não cadastrada.\n")
                        if len(grupo["atividades"])>1:
                            saida.insert("end","  Atividades associadas: "+"; ".join(grupo["atividades"])+"\n")
                        saida.insert("end","\n")
                    if complementares:
                        saida.insert("end", "\nTRs COMPLEMENTARES\n\n")
                        for registro in complementares[:90]:
                            numero=registro.get("numero") or "Sem número"
                            saida.insert("end",f"{registro['atividade']}\n  TR nº {numero}")
                            if registro.get("modalidade"):
                                saida.insert("end",f" — {registro['modalidade']}")
                            saida.insert("end","\n")
                            if registro.get("situacao"):
                                saida.insert("end",f"  Situação: {registro['situacao']}\n")
                            if registro.get("observacoes"):
                                saida.insert("end",f"  Observação: {registro['observacoes']}\n")
                            url=registro.get("link_pagina","")
                            if url:
                                saida.insert("end","  Acessar página do TR: ")
                                indice_inicio=saida.index("end-1c")
                                saida.insert("end",url)
                                indice_fim=saida.index("end-1c")
                                tag=f"url_tr_{len(self._links_tr_resultado)}"
                                self._links_tr_resultado[tag]=url
                                saida.tag_add("link_tr",indice_inicio,indice_fim)
                                saida.tag_add(tag,indice_inicio,indice_fim)
                                saida.insert("end","\n")
                            else:
                                saida.insert("end","  Página não cadastrada.\n")
                            saida.insert("end","\n")
                    if len(grupos)>45:
                        saida.insert("end",f"Exibindo 45 de {len(grupos)} famílias. Refine a pesquisa.\n")
                saida.configure(state="disabled")
            busca.bind("<Return>",pesquisar)
            pesquisar()
        elif nome=="Base Normativa":
            self._montar_base_normativa(cartao)
        elif nome=="Atualizações":
            self._montar_atualizacoes(cartao)
        else:
            tk.Label(cartao,text="ÓIKOS — Classificador Ambiental MT",
                     bg="white",fg=marrom,font=("Quicksand",14,"bold")).pack(anchor="w",pady=(0,14))
            tk.Label(cartao,text="Interface de consulta ambiental com bases do Decreto nº 1.585/2022,\n"
                     "Resolução CONSEMA nº 74/2025 e catálogo de TRs cadastrado.\n\n"
                     "Esta versão altera somente a apresentação e a navegação.",
                     bg="white",fg=texto,justify="left",font=("Quicksand",11)).pack(anchor="w")
        return pagina

    def _montar_atualizacoes(self, cartao):
        """v1.36.2: painel enxuto; consulta HTTPS em thread e atualização na thread Tk."""
        from tkinter import messagebox
        marrom, verde, _, texto = self._cores_painel
        self._atualizacao_painel = None
        self._atualizacao_status_var = tk.StringVar(value="Aguardando consulta ao GitHub.")
        tk.Label(cartao, text="CENTRAL DE ATUALIZAÇÕES", bg="white", fg=marrom,
                 font=("Quicksand", 14, "bold")).pack(anchor="w", pady=(0, 12))
        faixa = tk.Frame(cartao, bg="white")
        faixa.pack(fill="x", pady=(0, 12))
        local_box = tk.Frame(faixa, bg="#F6F3EF", padx=17, pady=14)
        local_box.pack(side="left", fill="x", expand=True, padx=(0, 7))
        tk.Label(local_box, text="VERSÃO INSTALADA", bg="#F6F3EF", fg=texto,
                 font=("Quicksand", 9, "bold")).pack(anchor="w")
        tk.Label(local_box, text="1.36.2", bg="#F6F3EF", fg=marrom,
                 font=("Quicksand", 20, "bold")).pack(anchor="w")
        online_box = tk.Frame(faixa, bg="#F6F3EF", padx=17, pady=14)
        online_box.pack(side="left", fill="x", expand=True, padx=(7, 0))
        tk.Label(online_box, text="ÚLTIMA VERSÃO ONLINE", bg="#F6F3EF", fg=texto,
                 font=("Quicksand", 9, "bold")).pack(anchor="w")
        self._versao_online_1362 = tk.StringVar(value="Não consultada")
        tk.Label(online_box, textvariable=self._versao_online_1362, bg="#F6F3EF", fg=marrom,
                 font=("Quicksand", 20, "bold")).pack(anchor="w")
        self._status_app_1362 = tk.StringVar(value="Clique em Verificar atualizações para consultar o GitHub.")
        tk.Label(cartao, textvariable=self._status_app_1362, bg="white", fg=marrom,
                 font=("Quicksand", 11, "bold"), wraplength=750,
                 justify="left").pack(anchor="w", pady=(2, 8))
        linha = tk.Frame(cartao, bg="white")
        linha.pack(anchor="w", pady=(0, 14))
        self._atualizacao_botao = ttk.Button(linha, text="Verificar atualizações",
                    style="Primario.TButton", command=self._consultar_app_cards_1362)
        self._atualizacao_botao.pack(side="left", padx=(0, 10))
        self._instalar_app_1362 = ttk.Button(linha, text="Instalar nova versão",
                    command=lambda: self._executar_atualizador_externo_1355(instalar=True))
        self._instalar_app_1362.pack(side="left")
        self._instalar_app_1362.configure(state="disabled")
        ttk.Separator(cartao, orient="horizontal").pack(fill="x", pady=(2, 12))
        tk.Label(cartao, text="BASES DE DADOS", bg="white", fg=marrom,
                 font=("Quicksand", 11, "bold")).pack(anchor="w")
        tk.Label(cartao, text="Sete arquivos no inventário homologado. Bases normativas protegidas: somente leitura.",
                 bg="white", fg=texto, wraplength=750, justify="left").pack(anchor="w", pady=(3, 6))
        ttk.Button(cartao, text="Consultar integridade das bases",
                   command=self._consultar_inventario_github_1358).pack(anchor="w", pady=(0, 12))
        ttk.Separator(cartao, orient="horizontal").pack(fill="x", pady=(2, 12))
        tk.Label(cartao, text="BACKUPS E RESTAURAÇÃO", bg="white", fg=marrom,
                 font=("Quicksand", 11, "bold")).pack(anchor="w")
        tk.Label(cartao, text="Consultar cópias de segurança ou recuperar uma versão com confirmação específica.",
                 bg="white", fg=texto, wraplength=750, justify="left").pack(anchor="w", pady=(3, 6))
        ttk.Button(cartao, text="Gerenciar backups", command=self._abrir_backups_1362).pack(anchor="w", pady=(0, 12))
        ttk.Separator(cartao, orient="horizontal").pack(fill="x", pady=(2, 12))
        ttk.Button(cartao, text="Ferramentas avançadas (laboratório e auditoria)",
                   command=self._abrir_atualizacoes_avancadas_1362).pack(anchor="w", pady=(0, 8))
        # Consulta inicial não executa instalações nem modifica bases.
        self.after(450, self._consultar_app_cards_1362)

    def _consultar_app_cards_1362(self):
        """Lê somente o catálogo do aplicativo; evita cache e mantém Tk na thread principal."""
        import time
        from urllib.parse import urlsplit
        if getattr(self, "_consulta_app_1362_ativa", False):
            return
        self._consulta_app_1362_ativa = True
        self._atualizacao_botao.configure(state="disabled")
        self._instalar_app_1362.configure(state="disabled")
        self._status_app_1362.set("Consultando o catálogo oficial...")
        def tarefa():
            try:
                url = ("https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/"
                       "main/versoes.json?consulta=" + str(time.time_ns()))
                req = Request(url, headers={"User-Agent": "OIKOS/1.36.2", "Cache-Control": "no-cache"})
                with urlopen(req, timeout=15) as resposta:
                    destino = urlsplit(resposta.geturl())
                    if destino.scheme != "https" or destino.hostname != "raw.githubusercontent.com":
                        raise ValueError("Origem do catálogo não autorizada")
                    dados_brutos = resposta.read(131073)
                if len(dados_brutos) > 131072:
                    raise ValueError("Catálogo excede 128 KB")
                catalogo = json.loads(dados_brutos.decode("utf-8-sig"))
                if not isinstance(catalogo, dict) or catalogo.get("schema_version") != 1:
                    raise ValueError("Catálogo incompatível")
                app = catalogo.get("aplicativo")
                if not isinstance(app, dict) or app.get("id") != "oikos-app":
                    raise ValueError("Registro do aplicativo inválido")
                versao = app.get("versao")
                if not isinstance(versao, str) or not re.fullmatch(r"[0-9]+(?:\.[0-9]+){2}", versao):
                    raise ValueError("Versão remota inválida")
                if (not isinstance(app.get("sha256"), str) or
                    not re.fullmatch(r"[0-9a-fA-F]{64}", app["sha256"])):
                    raise ValueError("Hash do pacote inválido")
                def sucesso():
                    if not self.winfo_exists(): return
                    self._versao_online_1362.set(versao)
                    comparacao = self._comparar_versoes_publicadas("1.36.2", versao)
                    if comparacao == 1:
                        self._status_app_1362.set("Nova versão disponível: " + versao + ". Instalação exige confirmação e verificação de integridade.")
                        self._instalar_app_1362.configure(state="normal")
                    elif comparacao == 0:
                        self._status_app_1362.set("Seu ÓIKOS está atualizado.")
                    else:
                        self._status_app_1362.set("Versão local mais recente que o catálogo; nenhuma instalação autorizada.")
                    self._consulta_app_1362_ativa = False
                    self._atualizacao_botao.configure(state="normal")
                self.after(0, sucesso)
            except Exception as exc:
                erro = str(exc)
                def falha():
                    if not self.winfo_exists(): return
                    self._versao_online_1362.set("Indisponível")
                    self._status_app_1362.set("Consulta não concluída: " + erro + ". Nenhum arquivo foi alterado.")
                    self._consulta_app_1362_ativa = False
                    self._atualizacao_botao.configure(state="normal")
                self.after(0, falha)
        threading.Thread(target=tarefa, daemon=True).start()

    def _abrir_backups_1362(self):
        from tkinter import messagebox
        janela = tk.Toplevel(self)
        janela.title("ÓIKOS — Backups e restauração")
        janela.geometry("510x210")
        janela.configure(bg="white")
        tk.Label(janela, text="BACKUPS E RESTAURAÇÃO", bg="white", fg=self._cores_painel[0],
                 font=("Quicksand", 12, "bold")).pack(anchor="w", padx=20, pady=(18, 9))
        tk.Label(janela, text="A restauração exige confirmação específica e não altera bases normativas.",
                 bg="white", wraplength=470, justify="left").pack(anchor="w", padx=20)
        ttk.Button(janela, text="Consultar backups disponíveis",
                   command=self._consultar_backups_1360).pack(anchor="w", padx=20, pady=(14, 5))
        ttk.Button(janela, text="Restaurar backup (com confirmação)",
                   command=self._restaurar_backup_1360).pack(anchor="w", padx=20, pady=5)

    def _abrir_atualizacoes_avancadas_1362(self):
        janela = tk.Toplevel(self)
        janela.title("ÓIKOS — Ferramentas avançadas")
        janela.geometry("900x660")
        canvas = tk.Canvas(janela, bg="white", highlightthickness=0)
        barra = ttk.Scrollbar(janela, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=barra.set)
        barra.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        conteudo = tk.Frame(canvas, bg="white", padx=18, pady=12)
        item = canvas.create_window((0, 0), window=conteudo, anchor="nw")
        conteudo.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", lambda e: canvas.itemconfigure(item, width=e.width))
        self._montar_atualizacoes_avancadas_1362(conteudo)

    def _montar_atualizacoes_avancadas_1362(self, cartao):
        """Cartões informativos de versões; nenhuma instalação nesta etapa."""
        marrom, verde, _, texto = self._cores_painel
        tk.Label(cartao, text="CENTRAL DE ATUALIZAÇÕES", bg="white", fg=marrom,
                 font=("Quicksand", 13, "bold")).pack(anchor="w", pady=(0, 10))
        tk.Label(cartao, text="Versão do aplicativo: 1.36.1 (candidata)  |  Referência homologada: 1.35.9",
                 bg="white", fg=texto).pack(anchor="w", pady=(0, 8))
        tk.Label(cartao, text="Consulta automática e manual. Comparação por base; nenhuma informação normativa é alterada.",
                 bg="white", fg=texto, wraplength=780, justify="left").pack(anchor="w", pady=(0, 12))
        tk.Label(cartao, text="Repositório oficial: GiLemos95/oikos-atualizacoes (GitHub)",
                 bg="white", fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w", pady=(0, 8))
        # Identificação informativa das bases; sem modificar arquivos ou autorização.
        tk.Label(cartao,
                 text="Base municipal: 1.0.0 (homologada)  |  TRs e normas: incorporadas, sem versão individual documentada",
                 bg="white", fg=texto, wraplength=780, justify="left").pack(anchor="w", pady=(0, 8))
        self._atualizacao_status_var = tk.StringVar(value=self._atualizacao_estado)
        tk.Label(cartao, textvariable=self._atualizacao_status_var, bg="white", fg=marrom,
                 wraplength=780, justify="left").pack(anchor="w", pady=(8, 8))
        painel = tk.Frame(cartao, bg="white")
        painel.pack(fill="both", expand=True)
        self._atualizacao_painel = painel
        self._mostrar_bases_atualizacoes_33_1()
        self._atualizacao_botao = ttk.Button(cartao, text="Verificar atualizações online",
                 style="Primario.TButton", command=lambda: self._verificar_atualizacoes_33_1(automatico=False))
        self._atualizacao_botao.pack(anchor="w", pady=(10, 0))
        # Integração controlada com o atualizador externo (sem atualizar durante a execução).
        ttk.Button(cartao, text="Consultar atualização do aplicativo (GitHub)",
                   command=lambda: self._executar_atualizador_externo_1355(instalar=False)).pack(anchor="w", pady=(8, 2))
        ttk.Button(cartao, text="Instalar atualização do aplicativo (com confirmação)",
                   command=lambda: self._executar_atualizador_externo_1355(instalar=True)).pack(anchor="w", pady=(2, 8))
        ttk.Button(cartao, text="Consultar inventário homologado (GitHub) — somente leitura",
                   command=self._consultar_inventario_github_1358).pack(anchor="w", pady=(2, 8))
        # v1.36.1: gerenciamento de backups isolado das bases normativas.
        ttk.Separator(cartao, orient="horizontal").pack(fill="x", pady=(12, 9))
        tk.Label(cartao, text="GERENCIAMENTO DE VERSÕES — BACKUPS", bg="white", fg=marrom,
                 font=("Quicksand", 11, "bold")).pack(anchor="w", pady=(0, 5))
        tk.Label(cartao, text="Consulte backups locais ou restaure uma versão anterior com confirmação. "
                 "Nenhuma base normativa será substituída.", bg="white", fg=texto,
                 wraplength=760, justify="left").pack(anchor="w", pady=(0, 5))
        ttk.Button(cartao, text="Consultar backups disponíveis (somente leitura)",
                   command=self._consultar_backups_1360).pack(anchor="w", pady=(3, 3))
        ttk.Button(cartao, text="Restaurar backup do aplicativo (com confirmação)",
                   command=self._restaurar_backup_1360).pack(anchor="w", pady=(3, 9))
        # v1.34.0: inventário de migração somente-leitura, sem tocar nas abas ou bases.
        inventario = tk.Frame(cartao, bg="white")
        inventario.pack(fill="x", pady=(12, 2))
        tk.Label(inventario, text="SINCRONIZAÇÃO DAS BASES — PREPARAÇÃO", bg="white",
                 fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(inventario,
                 text="4 famílias identificadas. Consulta automática ativa; instalação normativa bloqueada até homologação. "
                      "As bases embutidas continuam sendo utilizadas, inclusive sem internet.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(3, 4))
        ttk.Button(inventario, text="Ver inventário técnico das bases",
                   command=self._abrir_inventario_bases_1340).pack(anchor="w")

        if self._atualizacao_em_andamento:
            self._atualizacao_botao.configure(state="disabled")
        # Teste isolado: nao modifica a consulta oficial nem as bases locais.
        teste = tk.Frame(cartao, bg="white")
        teste.pack(fill="x", pady=(12, 0))
        tk.Label(teste, text="LABORATÓRIO — BASE FICTÍCIA", bg="white", fg=marrom,
                 font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(teste, text="Consulta e validação online; instalação apenas de arquivos fictícios em pasta isolada.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(3, 5))
        self._teste_github_status = tk.StringVar(value="Teste ainda não executado.")
        tk.Label(teste, textvariable=self._teste_github_status, bg="white", fg=marrom,
                 wraplength=760, justify="left").pack(anchor="w", pady=(0, 5))
        self._teste_github_botao = ttk.Button(teste, text="Testar download e integridade (GitHub)",
                 command=self._executar_teste_github_33_6)
        self._teste_github_botao.pack(anchor="w")
        tk.Label(teste, text="Instalação somente na pasta laboratorio_atualizacoes (dados fictícios).",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(8, 3))
        acoes = tk.Frame(teste, bg="white")
        acoes.pack(anchor="w")
        self._lab_instalar_botao = ttk.Button(acoes, text="Instalar base fictícia (com backup)",
                 command=lambda: self._executar_acao_laboratorio_33_7("instalar"))
        self._lab_instalar_botao.pack(side="left", padx=(0, 8))
        self._lab_restaurar_botao = ttk.Button(acoes, text="Restaurar backup fictício",
                 command=lambda: self._executar_acao_laboratorio_33_7("restaurar"))
        self._lab_restaurar_botao.pack(side="left")
        self._lab_ciclo_botao = ttk.Button(teste, text="Testar atualização + falha simulada (isolado)",
                 command=self._executar_teste_ciclo_33_8)
        self._lab_ciclo_botao.pack(anchor="w", pady=(8, 0))


        # v1.34.6: interface de laboratório da base oficial homologada.
        bloco_1346 = tk.Frame(cartao, bg="white")
        bloco_1346.pack(fill="x", pady=(14, 3))
        tk.Label(bloco_1346, text="LABORATÓRIO — MUNICÍPIOS HOMOLOGADOS (1.0.0)",
                 bg="white", fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(bloco_1346,
                 text="Validação online, instalação e restauração somente em pasta isolada. "
                      "Nenhuma base utilizada pelo classificador será substituída.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(3, 5))
        self._municipios_lab_status_1346 = tk.StringVar(value="Aguardando ação experimental.")
        tk.Label(bloco_1346, textvariable=self._municipios_lab_status_1346,
                 bg="white", fg=marrom, wraplength=760, justify="left").pack(anchor="w")
        botoes_1346 = tk.Frame(bloco_1346, bg="white")
        botoes_1346.pack(anchor="w", pady=(7, 0))
        self._municipios_lab_botoes_1346 = []
        for rotulo, acao in (("Validar base online", "validar"),
                             ("Instalar no laboratório", "instalar"),
                             ("Restaurar backup do laboratório", "restaurar")):
            botao = ttk.Button(botoes_1346, text=rotulo,
                               command=lambda modo=acao: self._executar_municipios_lab_1346(modo))
            botao.pack(side="left", padx=(0, 7))
            self._municipios_lab_botoes_1346.append(botao)

        # v1.34.15.2: autorização simulada, sem instalação em bases oficiais.
        simulacao_13411 = tk.Frame(cartao, bg="white")
        simulacao_13411.pack(fill="x", pady=(16, 4))
        tk.Label(simulacao_13411, text="AUTORIZAÇÃO OFICIAL — SIMULAÇÃO (SEM INSTALAÇÃO)",
                 bg="white", fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(simulacao_13411,
                 text="Verifica a base homologada, solicita confirmação e simula falha/recuperação em memória. "
                      "As bases oficiais continuam bloqueadas para atualização.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(4, 5))
        self._autorizacao_status_13411 = tk.StringVar(value="Aguardando simulação.")
        tk.Label(simulacao_13411, textvariable=self._autorizacao_status_13411,
                 bg="white", fg=marrom, wraplength=760, justify="left").pack(anchor="w")
        self._autorizacao_botao_13411 = ttk.Button(simulacao_13411,
                 text="Simular autorização e rollback (sem alterar bases)",
                 command=self._simular_autorizacao_13411)
        self._autorizacao_botao_13411.pack(anchor="w", pady=(7, 0))

        # v1.34.15.2: atualização oficial controlada (somente 1.0.0 idêntica).
        oficial_13415 = tk.Frame(cartao, bg="white")
        oficial_13415.pack(fill="x", pady=(16, 4))
        tk.Label(oficial_13415, text="INSTALAÇÃO OFICIAL CONTROLADA — BASE 1.0.0 IDÊNTICA",
                 bg="white", fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(oficial_13415,
                 text="Verifique primeiro a candidata. A reinstalação real exige confirmação escrita, "
                      "backup e conferência após a gravação. Versões diferentes permanecem bloqueadas.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(4, 5))
        self._oficial_status_13415 = tk.StringVar(value="Aguardando verificação da candidata.")
        tk.Label(oficial_13415, textvariable=self._oficial_status_13415,
                 bg="white", fg=marrom, wraplength=760, justify="left").pack(anchor="w")
        linha_oficial = tk.Frame(oficial_13415, bg="white")
        linha_oficial.pack(anchor="w", pady=(7, 0))
        self._oficial_verificado_13415 = False
        self._oficial_botoes_13415 = []
        for titulo, modo in (("Verificar candidata oficial", "verificar"),
                             ("Reinstalar base oficial 1.0.0", "instalar")):
            botao = ttk.Button(linha_oficial, text=titulo,
                               command=lambda acao=modo: self._executar_oficial_13415(acao))
            botao.pack(side="left", padx=(0, 7))
            self._oficial_botoes_13415.append(botao)
        self._oficial_botoes_13415[1].configure(state="disabled")

        # v1.34.17: análise de candidata municipal, exclusivamente leitura.
        pre_13417 = tk.Frame(cartao, bg="white")
        pre_13417.pack(fill="x", pady=(18, 6))
        tk.Label(pre_13417, text="PRÉ-HOMOLOGAÇÃO — COMPARAR BASE MUNICIPAL",
                 bg="white", fg=marrom, font=("Quicksand", 10, "bold")).pack(anchor="w")
        tk.Label(pre_13417,
                 text="Selecione um JSON candidato local para comparar municípios e grupos A/B/C "
                      "com a base oficial. Apenas diagnóstico: nenhuma instalação ou autorização.",
                 bg="white", fg=texto, wraplength=760, justify="left").pack(anchor="w", pady=(4, 5))
        self._pre_status_13417 = tk.StringVar(value="Aguardando seleção de arquivo candidato.")
        tk.Label(pre_13417, textvariable=self._pre_status_13417,
                 bg="white", fg=marrom, wraplength=760, justify="left").pack(anchor="w")
        ttk.Button(pre_13417, text="Comparar base candidata (JSON)",
                   command=self._pre_homologar_municipios_13417).pack(anchor="w", pady=(7, 5))
        from tkinter import scrolledtext
        self._pre_resultado_13417 = scrolledtext.ScrolledText(
            pre_13417, height=11, width=88, wrap="word", font=("Consolas", 9),
            bg="#FAF8F5", fg=texto, relief="solid", borderwidth=1)
        self._pre_resultado_13417.pack(fill="x", pady=(2, 4))
        self._pre_resultado_13417.insert("1.0", "O relatório comparativo aparecerá aqui.\nA instalação de versões novas permanece bloqueada.")
        self._pre_resultado_13417.configure(state="disabled")
        self._pre_relatorio_detalhado_13418 = None
        self._pre_exportar_13418 = ttk.Button(pre_13417, text="Exportar relatório técnico (TXT)",
            command=self._exportar_pre_relatorio_13418)
        self._pre_exportar_13418.pack(anchor="w", pady=(5, 2))
        self._pre_exportar_13418.configure(state="disabled")
        ttk.Button(pre_13417, text="Registrar revisão técnica (sem instalar)",
                   command=self._registrar_revisao_13421).pack(anchor="w", pady=(5, 2))
        ttk.Button(pre_13417, text="Consultar histórico de revisões técnicas",
                   command=self._consultar_historico_1351).pack(anchor="w", pady=(5, 2))


    def _consultar_inventario_github_1358(self):
        """Exibe inventário remoto e compara hashes; não escreve bases nem altera estado normativo."""
        import hashlib
        import threading
        from tkinter import scrolledtext
        from urllib.request import Request, urlopen
        from urllib.parse import urlparse
        from pathlib import Path
        from tkinter import messagebox
        url_inventario = "https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/INVENTARIO_BASES_OIKOS_1357.json"
        janela = tk.Toplevel(self)
        janela.title("ÓIKOS — Inventário de bases no GitHub (somente leitura)")
        janela.geometry("900x570")
        janela.transient(self)
        tk.Label(janela, text="INVENTÁRIO DOCUMENTAL — NENHUMA INSTALAÇÃO AUTORIZADA",
                 font=("Quicksand", 11, "bold"), fg="#522A00").pack(anchor="w", padx=14, pady=(12, 7))
        status = tk.StringVar(value="Consultando inventário remoto...")
        tk.Label(janela, textvariable=status, wraplength=850, justify="left").pack(anchor="w", padx=14)
        area = scrolledtext.ScrolledText(janela, wrap="word", font=("Consolas", 10))
        area.pack(fill="both", expand=True, padx=14, pady=10)
        area.insert("end", "Aguardando consulta ao GitHub. Nenhum arquivo será instalado.\n")
        area.configure(state="disabled")
        def atualizar(titulo, linhas):
            try:
                if not janela.winfo_exists():
                    return
                status.set(titulo)
                area.configure(state="normal")
                area.delete("1.0", "end")
                area.insert("end", "\n".join(linhas))
                area.configure(state="disabled")
            except tk.TclError:
                pass
        def trabalhador():
            linhas = []
            try:
                req = Request(url_inventario, headers={"User-Agent": "OIKOS-inventario-leitura/1.35.9", "Cache-Control": "no-cache"})
                with urlopen(req, timeout=20) as r:
                    bruto = r.read(128 * 1024 + 1)
                if len(bruto) > 128 * 1024:
                    raise ValueError("Inventário remoto excede 128 KB")
                inv = json.loads(bruto.decode("utf-8-sig"))
                if not isinstance(inv, dict) or inv.get("instalacao_bases_habilitada") is not False:
                    raise ValueError("Inventário não identificado como somente leitura")
                itens = inv.get("arquivos")
                if not isinstance(itens, list) or len(itens) != 7:
                    raise ValueError("Inventário deve conter exatamente sete arquivos")
                vistos = set()
                aprovados = 0
                for item in itens:
                    nome = item.get("arquivo", "")
                    endereco = item.get("url", "")
                    sha = item.get("sha256", "")
                    tamanho = item.get("bytes")
                    if (not isinstance(nome, str) or not nome.startswith("bases/") or
                        nome in vistos or not isinstance(endereco, str) or
                        endereco != "https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/" + nome or
                        not isinstance(sha, str) or len(sha) != 64 or
                        not isinstance(tamanho, int) or tamanho < 0 or tamanho > 5_000_000 or
                        item.get("politica") != "somente_leitura_sem_instalacao"):
                        raise ValueError("Entrada de inventário inválida: " + str(nome))
                    vistos.add(nome)
                    req_arquivo = Request(endereco, headers={"User-Agent": "OIKOS-inventario-leitura/1.35.9", "Cache-Control": "no-cache"})
                    with urlopen(req_arquivo, timeout=30) as r:
                        dados = r.read(tamanho + 1)
                    correto = len(dados) == tamanho and hashlib.sha256(dados).hexdigest() == sha.lower()
                    aprovados += int(correto)
                    linhas.append(("APROVADO" if correto else "DIVERGENTE") + " | " + nome)
                    linhas.append("  SHA esperado: " + sha)
                    linhas.append("  SHA remoto:   " + hashlib.sha256(dados).hexdigest())
                    linhas.append("  Bytes: " + str(len(dados)) + " / " + str(tamanho))
                    linhas.append("")
                titulo = "GitHub: " + str(aprovados) + "/7 arquivos íntegros — somente leitura"
                linhas.append("RESULTADO: " + str(aprovados) + "/7 arquivos aprovados.")
                linhas.append("Nenhuma base baixada para instalação ou substituída no ÓIKOS.")
            except Exception as exc:
                titulo = "Consulta não concluída — nenhuma alteração realizada"
                linhas.append("ERRO: " + type(exc).__name__ + ": " + str(exc))
            try:
                janela.after(0, lambda t=titulo, l=linhas: atualizar(t, l))
            except (RuntimeError, tk.TclError):
                pass
        threading.Thread(target=trabalhador, daemon=True).start()

    def _executar_atualizador_externo_1355(self, instalar=False):
        """Abre processo independente; não modifica bases nem executa atualização em Tk."""
        import subprocess
        import sys
        from tkinter import messagebox
        from pathlib import Path
        arquivo = Path(__file__).resolve().parent / "ATUALIZADOR_COMPLETO.py"
        if not arquivo.is_file():
            messagebox.showerror("ÓIKOS — Atualizações", "Atualizador externo não encontrado na pasta do aplicativo.", parent=self)
            return
        if instalar:
            ok = messagebox.askyesno(
                "ÓIKOS — Atualização do aplicativo",
                "O ÓIKOS será fechado para iniciar o atualizador externo.\n\n"
                "A instalação só ocorrerá após nova confirmação no terminal, "
                "validação SHA-256 e criação do backup.\n\nContinuar?",
                parent=self)
            if not ok:
                return
        comando = [sys.executable, str(arquivo), "--instalar" if instalar else "--verificar"]
        try:
            flags = getattr(subprocess, "CREATE_NEW_CONSOLE", 0)
            subprocess.Popen(comando, cwd=str(arquivo.parent), creationflags=flags)
        except Exception as exc:
            messagebox.showerror("ÓIKOS — Atualizações", "Não foi possível abrir o atualizador: " + str(exc), parent=self)
            return
        if instalar:
            self.after(100, self.destroy)

    def _consultar_backups_1360(self):
        """Exibe backups verificados sem executar gravação nem consultar a rede."""
        from pathlib import Path
        from tkinter import messagebox, scrolledtext
        import importlib.util
        arquivo = Path(__file__).resolve().parent / "RESTAURAR_ATUALIZACAO_OIKOS.py"
        if not arquivo.is_file():
            messagebox.showerror("ÓIKOS — Backups", "Ferramenta de restauração não encontrada.", parent=self)
            return
        try:
            spec = importlib.util.spec_from_file_location("oikos_restauracao_local_1360", arquivo)
            modulo = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(modulo)
            raiz = arquivo.parent
            pastas = modulo.backups_validos(raiz)
            linhas = ["INVENTÁRIO LOCAL — SOMENTE LEITURA", "Nenhum arquivo será alterado.", ""]
            for pasta in pastas:
                try:
                    manifesto, _ = modulo.validate(raiz, pasta)
                    linhas.append("APROVADO | " + pasta.name)
                    linhas.append("  Versão instalada: " + str(manifesto.get("nova")))
                    linhas.append("  Versão recuperável: " + str(manifesto.get("anterior")))
                except Exception as exc:
                    linhas.append("INVÁLIDO | " + pasta.name + " | " + str(exc))
                linhas.append("")
            if not pastas:
                linhas.append("Nenhum backup encontrado nesta instalação.")
            janela = __import__("tkinter").Toplevel(self)
            janela.title("ÓIKOS — Backups do aplicativo")
            janela.geometry("780x470")
            janela.transient(self)
            area = scrolledtext.ScrolledText(janela, wrap="word", font=("Consolas", 10))
            area.pack(fill="both", expand=True, padx=12, pady=12)
            area.insert("1.0", "\n".join(linhas))
            area.configure(state="disabled")
            janela.after_idle(lambda: area.focus_set() if area.winfo_exists() else None)
        except Exception as exc:
            messagebox.showerror("ÓIKOS — Backups", "Consulta não concluída: " + str(exc), parent=self)

    def _restaurar_backup_1360(self):
        """Inicia restauração em processo independente após encerrar o aplicativo."""
        from pathlib import Path
        from tkinter import messagebox
        import subprocess, sys
        arquivo = Path(__file__).resolve().parent / "RESTAURAR_ATUALIZACAO_OIKOS.py"
        if not arquivo.is_file():
            messagebox.showerror("ÓIKOS — Restauração", "Ferramenta de restauração não encontrada.", parent=self)
            return
        ok = messagebox.askyesno("ÓIKOS — Restaurar aplicativo",
            "O ÓIKOS será fechado para abrir a ferramenta de restauração.\n\n"
            "O backup mais recente será apresentado no terminal. A operação só ocorrerá "
            "após digitar RESTAURAR.\n\n"
            "As bases normativas não serão alteradas.\n\nContinuar?", parent=self)
        if not ok:
            return
        try:
            subprocess.Popen([sys.executable, str(arquivo)], cwd=str(arquivo.parent),
                             creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        except Exception as exc:
            messagebox.showerror("ÓIKOS — Restauração", "Falha ao abrir ferramenta: " + str(exc), parent=self)
            return
        self.after(100, self.destroy)

    def _consultar_historico_1351(self):
        """Consulta registros locais; não autoriza nem instala bases."""
        import json
        from pathlib import Path
        from tkinter import messagebox, scrolledtext
        janela = None
        try:
            pasta = Path(__file__).resolve().parent / "registros_homologacao_tecnica"
            registros = sorted(pasta.glob("revisao_*.json"), reverse=True) if pasta.is_dir() else []
            janela = tk.Toplevel(self)
            janela.title("ÓIKOS — Histórico de revisões (somente leitura)")
            janela.geometry("880x520")
            janela.transient(self)
            texto = scrolledtext.ScrolledText(janela, wrap="word", font=("Consolas", 10))
            texto.pack(fill="both", expand=True, padx=12, pady=12)
            texto.insert("end", "HISTÓRICO DOCUMENTAL — SEM AUTORIZAÇÃO DE INSTALAÇÃO\n")
            texto.insert("end", "Registros encontrados: %d\n\n" % len(registros))
            for arquivo in registros:
                try:
                    registro = json.loads(arquivo.read_text(encoding="utf-8"))
                    if not isinstance(registro, dict):
                        raise ValueError("JSON não é objeto")
                    texto.insert("end", "Arquivo: %s\n" % arquivo.name)
                    for chave, rotulo in (("criado_em", "Registrado em"), ("responsavel", "Responsável"),
                                           ("data_analise", "Data da análise"), ("status", "Situação"),
                                           ("sha256_candidata", "SHA-256 candidato"), ("ato_normativo", "Ato normativo"),
                                           ("evidencias", "Evidências"), ("justificativa", "Justificativa")):
                        texto.insert("end", "%s: %s\n" % (rotulo, registro.get(chave, "Não informado")))
                    texto.insert("end", "Instalação autorizada: NÃO (independente do registro)\n")
                except (OSError, ValueError, UnicodeError) as erro:
                    texto.insert("end", "Registro inválido %s: %s\n" % (arquivo.name, erro))
                texto.insert("end", "-" * 70 + "\n")
            if not registros:
                texto.insert("end", "Nenhuma revisão registrada nesta pasta.\n")
            texto.configure(state="disabled")
        except Exception as erro:
            messagebox.showerror("ÓIKOS — Histórico", str(erro), parent=janela or self)
        finally:
            try:
                self.after_idle(lambda: self.focus_force())
                self.after(120, lambda: self.focus_force())
            except Exception:
                pass

    def _registrar_revisao_13421(self):
        """Registra documentação sem liberar instalação e recupera o foco."""
        from tkinter import simpledialog, messagebox
        try:
            import registro_homologacao_tecnica as registro
            import PRE_HOMOLOGAR_MUNICIPIOS as pre
            relatorio_texto = getattr(self, '_pre_relatorio_detalhado_13418', None)
            if not relatorio_texto:
                messagebox.showwarning('ÓIKOS — revisão técnica',
                    'Compare primeiro uma base candidata (JSON).', parent=self)
                return
            # Usa o hash do relatório recém-gerado, sem confiar em texto digitado.
            linha = next((x for x in relatorio_texto.splitlines()
                          if x.startswith('SHA-256 candidata: ')), None)
            if not linha:
                raise ValueError('SHA-256 da candidata não encontrado no relatório.')
            sha = linha.split(': ', 1)[1].strip()
            campos = [
                ('responsavel', 'Responsável técnico (nome):'),
                ('data_analise', 'Data da análise (AAAA-MM-DD):'),
                ('ato_normativo', 'Ato normativo e publicação oficial:'),
                ('evidencias', 'Evidências documentais / referências:'),
                ('justificativa', 'Justificativa e resultado da revisão:')]
            valores={}
            for chave, pergunta in campos:
                valor=simpledialog.askstring('ÓIKOS — registro documental', pergunta, parent=self)
                if valor is None:
                    self._pre_status_13417.set('Registro cancelado; nenhum arquivo criado.')
                    return
                valores[chave]=valor.strip()
            status=simpledialog.askstring('ÓIKOS — situação documental',
                'Digite PENDENTE, APROVADO DOCUMENTALMENTE ou REPROVADO:',
                initialvalue='PENDENTE', parent=self)
            if status is None:
                self._pre_status_13417.set('Registro cancelado; nenhum arquivo criado.')
                return
            valores.update(status=status.strip().upper(),sha256_candidata=sha)
            caminho=registro.registrar(valores)
            self._pre_status_13417.set('Revisão registrada em '+str(caminho.name)+
                '. Instalação continua BLOQUEADA.')
            messagebox.showinfo('ÓIKOS — registro salvo',
                'Registro documental salvo em:\n'+str(caminho)+
                '\n\nA instalação NÃO foi autorizada.', parent=self)
        except Exception as erro:
            messagebox.showerror('ÓIKOS — registro documental', str(erro), parent=self)
        finally:
            self.after_idle(self._recuperar_foco_pos_dialogo_134151)

    def _pre_homologar_municipios_13417(self):
        """Seleciona candidata local e mostra diferenças; nunca instala arquivos."""
        import contextlib
        import io
        from tkinter import filedialog
        try:
            caminho = filedialog.askopenfilename(
                parent=self, title="Selecionar base municipal candidata (JSON)",
                filetypes=[("Arquivos JSON", "*.json"), ("Todos os arquivos", "*.*")])
            if not caminho:
                self._pre_status_13417.set("Seleção cancelada; nenhum arquivo alterado.")
                self.after_idle(self._recuperar_foco_pos_dialogo_134151)
                return
            self._pre_relatorio_detalhado_13418 = None
            self._pre_exportar_13418.configure(state="disabled")
            import PRE_HOMOLOGAR_MUNICIPIOS as pre
            buffer = io.StringIO()
            with contextlib.redirect_stdout(buffer):
                pre.analisar(Path(caminho))
            resultado = buffer.getvalue()
            relatorio = pre.relatorio_detalhado(Path(caminho))
            self._pre_relatorio_detalhado_13418 = pre.formatar_relatorio(relatorio)
            self._pre_exportar_13418.configure(state="normal")
            resultado += "\nRelatório detalhado disponível para exportação em TXT.\n"
            self._pre_status_13417.set("Comparação concluída. SOMENTE LEITURA — instalação bloqueada.")
        except (OSError, ValueError, UnicodeError, TypeError) as erro:
            resultado = "REPROVADO: " + str(erro) + "\nNenhum arquivo alterado."
            self._pre_status_13417.set("Candidata reprovada. Nenhuma instalação autorizada.")
        except Exception as erro:
            resultado = "FALHA NA ANÁLISE: " + str(erro) + "\nNenhum arquivo alterado."
            self._pre_status_13417.set("Erro na análise; instalação permanece bloqueada.")
        self._pre_resultado_13417.configure(state="normal")
        self._pre_resultado_13417.delete("1.0", "end")
        self._pre_resultado_13417.insert("1.0", resultado)
        self._pre_resultado_13417.configure(state="disabled")
        self.after_idle(self._recuperar_foco_pos_dialogo_134151)

    def _exportar_pre_relatorio_13418(self):
        """Exportação explícita do relatório, sem tocar na base oficial."""
        from tkinter import filedialog, messagebox
        texto = getattr(self, "_pre_relatorio_detalhado_13418", None)
        if not texto:
            return
        try:
            destino = filedialog.asksaveasfilename(parent=self,
                title="Salvar relatório técnico de pré-homologação",
                defaultextension=".txt", filetypes=[("Texto UTF-8", "*.txt")],
                initialfile="OIKOS_Relatorio_Pre_Homologacao.txt")
            if destino:
                from pathlib import Path
                import PRE_HOMOLOGAR_MUNICIPIOS as pre
                alvo = Path(destino).resolve()
                if alvo == pre.OFICIAL.resolve() or alvo == Path(__file__).resolve():
                    raise ValueError("Não é permitido sobrescrever arquivo oficial.")
                alvo.write_text(texto, encoding="utf-8-sig")
                self._pre_status_13417.set("Relatório TXT exportado. Bases oficiais preservadas.")
        except (OSError, ValueError) as erro:
            messagebox.showerror("ÓIKOS — exportação", str(erro), parent=self)
        finally:
            self.after_idle(self._recuperar_foco_pos_dialogo_134151)

    def _executar_oficial_13415(self, modo):
        """Confirmação explícita e execução fora da thread de interface."""
        import os
        import subprocess
        import sys
        from tkinter import simpledialog, messagebox
        if modo not in ("verificar", "instalar"):
            return
        if modo == "instalar":
            if not self._oficial_verificado_13415:
                return
            aviso = ("Esta operação grava na BASE OFICIAL, embora os bytes sejam idênticos "
                     "à versão 1.0.0 homologada. Feche outras instâncias do ÓIKOS. "
                     "Será criado/conferido um backup antes da gravação. Continuar?")
            if not messagebox.askyesno("ÓIKOS — alteração oficial", aviso, parent=self):
                self._oficial_status_13415.set("CANCELADO: nenhuma instalação solicitada.")
                self.after_idle(self._recuperar_foco_pos_dialogo_134151)
                return
            frase = "AUTORIZO INSTALACAO OFICIAL 1.0.0"
            digitado = simpledialog.askstring("Confirmação expressa",
                "Digite exatamente:\n" + frase, parent=self)
            if digitado != frase:
                self._oficial_status_13415.set("CANCELADO: autorização escrita não confirmada.")
                self.after_idle(self._recuperar_foco_pos_dialogo_134151)
                return
            self._oficial_verificado_13415 = False
        # Diálogos nativos podem devolver o foco a uma janela Tk incorreta.
        # Recuperar a janela principal sem mudar o foco de um Entry em uso.
        self.after_idle(self._recuperar_foco_pos_dialogo_134151)
        for botao in self._oficial_botoes_13415:
            botao.configure(state="disabled")
        self._oficial_status_13415.set("Executando " + ("verificação" if modo == "verificar" else "reinstalação oficial") + "...")
        def trabalhador():
            try:
                script = Path(__file__).resolve().parent / "instalador_oficial_controlado.py"
                ambiente = os.environ.copy()
                ambiente["PYTHONIOENCODING"] = "utf-8"
                entrada = "AUTORIZO INSTALACAO OFICIAL 1.0.0\n" if modo == "instalar" else None
                resultado = subprocess.run([sys.executable, str(script), modo],
                    input=entrada, cwd=str(script.parent), capture_output=True,
                    text=True, encoding="utf-8", errors="replace", env=ambiente, timeout=60)
                linhas = (resultado.stdout + "\n" + resultado.stderr).strip().splitlines()
                resumo = " | ".join(linhas[-5:])[:850] or "Sem retorno."
                sucesso = resultado.returncode == 0 and "APROVADO:" in resultado.stdout
            except Exception as erro:
                sucesso, resumo = False, str(erro)
            def concluir():
                try:
                    if not self.winfo_exists():
                        return
                    self._oficial_verificado_13415 = bool(sucesso and modo == "verificar")
                    self._oficial_status_13415.set(("APROVADO: " if sucesso else "FALHA: ") + resumo)
                    self._oficial_botoes_13415[0].configure(state="normal")
                    self._oficial_botoes_13415[1].configure(
                        state="normal" if self._oficial_verificado_13415 else "disabled")
                    self.after_idle(self._recuperar_foco_pos_dialogo_134151)
                except tk.TclError:
                    pass
            self.after(0, concluir)
        threading.Thread(target=trabalhador, daemon=True).start()

    def _recuperar_foco_pos_dialogo_134151(self):
        """Reativa foco da janela Tk após fechamento de diálogos modais."""
        try:
            if not self.winfo_exists():
                return
            # Não criar foco forçado enquanto outra janela modal estiver ativa.
            if self.grab_current() is not None:
                return
            self.focus_force()
            pagina_ativa = next((nome for nome, pagina in self.paginas.items()
                                 if pagina.winfo_exists() and pagina.winfo_ismapped()), None)
            if pagina_ativa in ("Termos de Referência", "Base Normativa"):
                campo = self._pesquisas_auxiliares.get(pagina_ativa)
                if campo is not None and campo.winfo_exists():
                    campo.configure(state="normal")
                    campo.focus_set()
        except tk.TclError:
            pass

    def _simular_autorizacao_13411(self):
        """A confirmação é exclusiva para uma simulação de memória."""
        import subprocess
        import sys
        from tkinter import messagebox
        if not messagebox.askyesno("ÓIKOS — autorização SIMULADA",
            "Executar simulação de autorização e falha?\n\n"
            "Nenhuma base oficial ou arquivo do laboratório será alterado.", parent=self):
            self._autorizacao_status_13411.set("CANCELADO: nenhuma operação realizada.")
            return
        self._autorizacao_botao_13411.configure(state="disabled")
        self._autorizacao_status_13411.set("Executando simulação isolada...")
        def trabalhador():
            try:
                script = Path(__file__).resolve().parent / "simular_autorizacao_13411.py"
                # Windows: subprocesso pode usar cp1252 na saída redirecionada.
                # Fixar UTF-8 nos dois lados impede caracteres de substituição.
                import os
                ambiente = os.environ.copy()
                ambiente["PYTHONIOENCODING"] = "utf-8"
                resultado = subprocess.run([sys.executable, str(script), "--confirmado"],
                    cwd=str(script.parent), capture_output=True, text=True, timeout=30,
                    encoding="utf-8", errors="strict", env=ambiente)
                linhas = (resultado.stdout + "\n" + resultado.stderr).strip().splitlines()
                resumo = " | ".join(linhas[-4:])[:750] or "Sem retorno."
                sucesso = resultado.returncode == 0
            except Exception as erro:
                sucesso, resumo = False, str(erro)
            def concluir():
                try:
                    if not self.winfo_exists(): return
                    self._autorizacao_status_13411.set(("APROVADO: " if sucesso else "FALHA: ") + resumo)
                    if self._autorizacao_botao_13411.winfo_exists():
                        self._autorizacao_botao_13411.configure(state="normal")
                except tk.TclError:
                    pass
            self.after(0, concluir)
        threading.Thread(target=trabalhador, daemon=True).start()

    def _executar_municipios_lab_1346(self, modo):
        """Executa o gerenciador em processo separado sem bloquear o Tk."""
        import subprocess
        import sys
        from tkinter import messagebox
        if modo not in ("validar", "instalar", "restaurar"):
            return
        if modo != "validar":
            detalhe = ("Instalar a base 1.0.0 apenas na pasta laboratorio_atualizacoes?"
                       if modo == "instalar" else
                       "Restaurar o backup apenas na pasta laboratorio_atualizacoes?")
            if not messagebox.askyesno("ÓIKOS — confirmação experimental", detalhe, parent=self):
                return
        for botao in self._municipios_lab_botoes_1346:
            botao.configure(state="disabled")
        self._municipios_lab_status_1346.set("Executando " + modo + " em ambiente isolado...")
        # Executa sem entrada interativa. A confirmação já foi feita no diálogo.
        def trabalhador():
            try:
                script = Path(__file__).resolve().parent / "gerenciador_municipios_experimental.py"
                comando = [sys.executable, str(script), modo, "--confirmado"] if modo != "validar" else [sys.executable, str(script), modo]
                resultado = subprocess.run(comando, cwd=str(script.parent), capture_output=True,
                                           text=True, timeout=50, encoding="utf-8", errors="replace")
                linhas = (resultado.stdout + "\n" + resultado.stderr).strip().splitlines()
                resumo = " | ".join(linhas[-3:])[:650] or "Sem retorno."
                sucesso = resultado.returncode == 0
            except Exception as erro:
                sucesso, resumo = False, str(erro)
            def concluir():
                try:
                    if not self.winfo_exists(): return
                    self._municipios_lab_status_1346.set(
                        ("APROVADO: " if sucesso else "FALHA: ") + resumo)
                    for botao in self._municipios_lab_botoes_1346:
                        if botao.winfo_exists(): botao.configure(state="normal")
                except tk.TclError:
                    pass
            self.after(0, concluir)
        threading.Thread(target=trabalhador, daemon=True).start()


    def _abrir_inventario_bases_1340(self):
        """Exibe o plano de migração, sem editar ou instalar arquivos."""
        from tkinter import messagebox
        caminho = Path(__file__).resolve().parent / "inventario_bases_1340.json"
        try:
            dados = json.loads(caminho.read_text(encoding="utf-8"))
            if dados.get("schema_version") != 1 or not isinstance(dados.get("bases"), list):
                raise ValueError("Inventário inválido")
            linhas = ["Inventário técnico (somente leitura):", ""]
            for item in dados["bases"]:
                linhas.append(item["nome"] + " — " + item["situacao"])
                linhas.append("Origem atual: " + item["origem_atual"])
                linhas.append("Próxima ação: " + item["proxima_acao"])
                linhas.append("")
            messagebox.showinfo("ÓIKOS — Preparação das bases", "\n".join(linhas), parent=self)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            messagebox.showerror("ÓIKOS — Inventário", str(exc), parent=self)

    def _executar_teste_github_33_6(self):
        """Executa somente o teste isolado, sem gravar qualquer arquivo."""
        if getattr(self, "_teste_github_em_andamento", False):
            return
        self._teste_github_em_andamento = True
        self._teste_github_status.set("Consultando repositório experimental...")
        self._teste_github_botao.configure(state="disabled")
        def tarefa():
            try:
                from teste_github_integridade import testar
                versao, digest = testar()
                resultado = "APROVADO — versão " + versao + " | SHA-256: " + digest + " | Nenhum arquivo alterado."
            except Exception as exc:
                resultado = "TESTE NÃO CONCLUÍDO — " + type(exc).__name__ + ": " + str(exc)
            def concluir():
                self._teste_github_em_andamento = False
                if self.winfo_exists():
                    self._teste_github_status.set(resultado)
                    if self._teste_github_botao.winfo_exists():
                        self._teste_github_botao.configure(state="normal")
            try:
                self.after(0, concluir)
            except RuntimeError:
                pass
        threading.Thread(target=tarefa, daemon=True).start()

    def _executar_acao_laboratorio_33_7(self, acao):
        """Opera somente a base fictícia, com confirmação explícita."""
        from tkinter import messagebox
        if getattr(self, "_teste_github_em_andamento", False):
            return
        texto = ("Instalar a base fictícia no laboratório? Um backup será criado quando aplicável."
                 if acao == "instalar" else "Restaurar o backup da base fictícia do laboratório?")
        if not messagebox.askyesno("ÓIKOS — Laboratório", texto, parent=self):
            return
        self._teste_github_em_andamento = True
        self._teste_github_status.set("Executando operação experimental...")
        for botao in (self._teste_github_botao, self._lab_instalar_botao, self._lab_restaurar_botao):
            botao.configure(state="disabled")
        def tarefa():
            try:
                from instalador_laboratorio import instalar, restaurar
                resultado = instalar() if acao == "instalar" else restaurar()
            except Exception as exc:
                resultado = "OPERAÇÃO NÃO CONCLUÍDA — " + type(exc).__name__ + ": " + str(exc)
            def concluir():
                self._teste_github_em_andamento = False
                if self.winfo_exists():
                    self._teste_github_status.set(resultado)
                    for botao in (self._teste_github_botao, self._lab_instalar_botao, self._lab_restaurar_botao):
                        if botao.winfo_exists(): botao.configure(state="normal")
            try: self.after(0, concluir)
            except RuntimeError: pass
        threading.Thread(target=tarefa, daemon=True).start()

    def _executar_teste_ciclo_33_8(self):
        """Testa atualização e rollback em pasta temporária, sem rede ou bases oficiais."""
        if getattr(self, "_teste_github_em_andamento", False): return
        self._teste_github_em_andamento = True
        self._teste_github_status.set("Testando ciclo de atualização fictícia em pasta temporária...")
        botoes=(self._teste_github_botao,self._lab_instalar_botao,self._lab_restaurar_botao,self._lab_ciclo_botao)
        for b in botoes: b.configure(state="disabled")
        def tarefa():
            try:
                from instalador_laboratorio import testar_ciclo
                resultado=testar_ciclo()
            except Exception as exc:
                resultado="TESTE NÃO APROVADO — " + type(exc).__name__ + ": " + str(exc)
            def concluir():
                self._teste_github_em_andamento=False
                if self.winfo_exists():
                    self._teste_github_status.set(resultado)
                    for b in botoes:
                        if b.winfo_exists(): b.configure(state="normal")
            try: self.after(0,concluir)
            except RuntimeError: pass
        threading.Thread(target=tarefa,daemon=True).start()

    def _mostrar_bases_atualizacoes_33_1(self):
        """Quatro cartões; compara somente versões locais documentadas."""
        painel = self._atualizacao_painel
        if painel is None or not painel.winfo_exists():
            return
        for filho in painel.winfo_children():
            filho.destroy()
        marrom, verde, _, texto = self._cores_painel
        por_id = {item["id"]: item for item in self._atualizacao_bases}
        for i, chave in enumerate(("municipios", "trs_sema", "trs_municipais", "normas")):
            local = self._atualizacao_versoes_locais[chave]
            integridade_local = None
            if chave == "municipios" and local is not None:
                # Não anunciar base atualizada se o conteúdo local foi modificado.
                try:
                    import hashlib
                    raiz = Path(__file__).resolve().parent
                    registro = json.loads((raiz / "versoes_locais.json").read_text(encoding="utf-8"))
                    item_local = registro["bases"]["municipios"]
                    caminho_relativo = item_local["arquivo"]
                    if caminho_relativo != "bases_locais/municipios_descentralizados.json":
                        raise ValueError("Caminho local não homologado")
                    esperado = item_local["sha256"]
                    atual = hashlib.sha256((raiz / caminho_relativo).read_bytes()).hexdigest()
                    integridade_local = (atual == esperado and esperado ==
                        "d2b44c75457888dad7325ca247e1dcc9a89f392255bb0b16ea73ff19bb62e11a")
                except (OSError, ValueError, TypeError, KeyError, AttributeError):
                    integridade_local = False
            remoto = por_id.get(chave)
            versao_online = remoto["versao"] if remoto else "Não publicada"
            if integridade_local is False:
                situacao = "ALERTA: integridade local divergente — comparação suspensa; nenhuma instalação permitida"
            elif remoto and local:
                comparacao = self._comparar_versoes_publicadas(local, remoto["versao"])
                situacao = ("Nova versão disponível — instalação desabilitada" if comparacao == 1
                            else "Versões coincidentes" if comparacao == 0
                            else "Versão local mais recente — verificar catálogo" if comparacao == -1
                            else "INCOMPATÍVEL: versão não comparável — análise técnica necessária")
            elif remoto:
                situacao = "INCOMPATÍVEL: versão local não identificada; instalação bloqueada"
            else:
                situacao = "Sem atualização publicada"
            card = tk.Frame(painel, bg="#FCFDFB", highlightbackground="#D6E4CF",
                            highlightthickness=1, padx=14, pady=10)
            card.grid(row=i//2, column=i%2, sticky="nsew", padx=(0, 10) if i%2 == 0 else (0, 0), pady=(0, 10))
            tk.Label(card, text=self._atualizacao_nomes[chave], bg="#FCFDFB", fg=marrom,
                     font=("Quicksand", 11, "bold"), anchor="w").pack(fill="x", pady=(0, 7))
            tk.Label(card, text="Versão local: " + (local or "Não individualizada"),
                     bg="#FCFDFB", fg=texto, anchor="w", justify="left").pack(fill="x")
            tk.Label(card, text="Versão online: " + versao_online,
                     bg="#FCFDFB", fg=texto, anchor="w", justify="left").pack(fill="x")
            if integridade_local is not None:
                tk.Label(card, text="Integridade local: " + ("SHA-256 aprovado" if integridade_local else "DIVERGENTE"),
                         bg="#FCFDFB", fg=marrom, anchor="w", justify="left").pack(fill="x")
            tk.Label(card, text="Situação: " + situacao,
                     bg="#FCFDFB", fg=marrom, anchor="w", justify="left", wraplength=310).pack(fill="x", pady=(5, 0))
            if remoto:
                tk.Label(card, text="Referência: " + remoto["descricao"],
                         bg="#FCFDFB", fg=texto, anchor="w", justify="left", wraplength=310).pack(fill="x", pady=(4, 0))
        painel.columnconfigure(0, weight=1, uniform="bases")
        painel.columnconfigure(1, weight=1, uniform="bases")
        for i in range(2):
            painel.rowconfigure(i, weight=1)
        tk.Label(painel, text="SOMENTE LEITURA — nenhuma base será baixada ou instalada. "
                 "Versões locais só são exibidas quando documentadas em versoes_locais.json.",
                 bg="white", fg=texto, justify="left", wraplength=760).grid(
                     row=2, column=0, columnspan=2, sticky="w", pady=(2, 0))

    @staticmethod
    def _comparar_versoes_publicadas(local, remoto):
        """Compara somente versões numéricas explícitas, sem inferir atualização."""
        import re
        padrao = r"[0-9]+(?:\.[0-9]+)*"
        if not (isinstance(local, str) and isinstance(remoto, str)
                and re.fullmatch(padrao, local) and re.fullmatch(padrao, remoto)):
            return None
        a = [int(x) for x in local.split(".")]
        b = [int(x) for x in remoto.split(".")]
        tamanho = max(len(a), len(b))
        a += [0] * (tamanho - len(a))
        b += [0] * (tamanho - len(b))
        return (b > a) - (b < a)

    def _verificar_atualizacoes_33_1(self, automatico=False):
        """Consulta HTTPS em thread; atualiza widgets somente na thread Tk."""
        import ssl
        import time
        from urllib.parse import urlsplit
        if self._atualizacao_em_andamento:
            return
        self._atualizacao_em_andamento = True
        self._atualizacao_estado = "Verificando atualizações online..."
        if self._atualizacao_status_var is not None:
            self._atualizacao_status_var.set(self._atualizacao_estado)
        if self._atualizacao_botao is not None and self._atualizacao_botao.winfo_exists():
            self._atualizacao_botao.configure(state="disabled")
        def tarefa():
            try:
                # Parâmetro variável evita reutilizar o manifesto anterior em cache.
                url = ("https://raw.githubusercontent.com/GiLemos95/"
                       "oikos-atualizacoes/main/versoes.json?consulta=" + str(time.time_ns()))
                req = Request(url, headers={"User-Agent": "OIKOS/1.34.10", "Accept": "application/json", "Cache-Control": "no-cache"})
                with urlopen(req, timeout=12, context=ssl.create_default_context()) as resposta:
                    final = urlsplit(resposta.geturl())
                    if final.scheme != "https" or final.hostname != "raw.githubusercontent.com":
                        raise ValueError("Destino HTTPS não autorizado")
                    conteudo = resposta.read(131073)
                if len(conteudo) > 131072:
                    raise ValueError("Manifesto excede 128 KB")
                dados = json.loads(conteudo.decode("utf-8"))
                if (not isinstance(dados, dict) or type(dados.get("schema_version")) is not int
                        or dados["schema_version"] != 1 or not isinstance(dados.get("bases"), list)):
                    raise ValueError("Formato de manifesto não reconhecido")
                if len(dados["bases"]) > 200:
                    raise ValueError("Manifesto contém registros demais")
                bases = []
                for item in dados["bases"]:
                    if (not isinstance(item, dict) or not all(isinstance(item.get(k), str)
                        and 0 < len(item[k]) <= 250 for k in ("id", "versao", "descricao"))):
                        raise ValueError("Registro de base inválido")
                    if item["id"] not in self._atualizacao_catalogo_ids:
                        raise ValueError("Identificador de base não reconhecido: " + item["id"])
                    if any(reg["id"] == item["id"] for reg in bases):
                        raise ValueError("Identificador de base duplicado: " + item["id"])
                    bases.append({k:item[k] for k in ("id", "versao", "descricao")})
                def sucesso():
                    self._atualizacao_bases = bases
                    self._atualizacao_estado = ("Catálogo consultado: nenhuma base publicada." if not bases
                        else f"Catálogo consultado: {len(bases)} base(s). Instalação de bases normativas desabilitada.")
                    self._finalizar_consulta_33_1()
                    self._mostrar_bases_atualizacoes_33_1()
                    if automatico:
                        novas = [item for item in bases
                                 if self._comparar_versoes_publicadas(
                                     self._atualizacao_versoes_locais.get(item["id"]), item["versao"]) == 1]
                        if novas:
                            nomes = ", ".join(self._atualizacao_nomes[item["id"]] for item in novas)
                            self._atualizacao_estado = (
                                "Atualização disponível: " + nomes +
                                ". Consulte a aba Atualizações. Nenhuma base foi instalada.")
                            if self._atualizacao_status_var is not None:
                                self._atualizacao_status_var.set(self._atualizacao_estado)
                self.after(0, sucesso)
            except Exception as exc:
                erro = str(exc)
                def falha():
                    self._atualizacao_estado = "Não foi possível consultar o catálogo: " + erro
                    self._finalizar_consulta_33_1()
                self.after(0, falha)
        threading.Thread(target=tarefa, daemon=True).start()

    def _finalizar_consulta_33_1(self):
        self._atualizacao_em_andamento = False
        if self._atualizacao_status_var is not None:
            self._atualizacao_status_var.set(self._atualizacao_estado)
        if self._atualizacao_botao is not None and self._atualizacao_botao.winfo_exists():
            self._atualizacao_botao.configure(state="normal")

    def _montar_base_normativa(self, cartao):
        """Consulta somente-leitura das linhas originais, sem consolidar portes."""
        import unicodedata
        marrom, verde, _, texto = self._cores_painel
        tk.Label(cartao,text="CONSULTA À BASE NORMATIVA",bg="white",fg=marrom,
                 font=("Quicksand",12,"bold")).pack(anchor="w",pady=(0,10))
        tk.Label(cartao,text="Digite uma atividade ou CNAE para consultar cada enquadramento normativo individualmente.",
                 bg="white",fg=texto,anchor="w").pack(fill="x",pady=(0,12))
        linha_filtros=tk.Frame(cartao,bg="white")
        linha_filtros.pack(fill="x",pady=(0,10))
        tk.Label(linha_filtros,text="Norma",bg="white",fg=texto).pack(side="left",padx=(0,8))
        norma=ttk.Combobox(linha_filtros,state="readonly",width=37,values=(
            "Decreto Estadual nº 1.585/2022","Resolução CONSEMA nº 74/2025"))
        norma.current(0)
        norma.pack(side="left",padx=(0,18))
        tk.Label(linha_filtros,text="Atividade ou CNAE",bg="white",fg=texto).pack(side="left",padx=(0,8))
        busca=ttk.Entry(linha_filtros)
        busca.pack(side="left",fill="x",expand=True)
        self._pesquisas_auxiliares["Base Normativa"]=busca
# No Windows, ttk.Entry pode mostrar cursor sem assumir o foco real
        # ao abrir páginas auxiliares criadas sob demanda.
        busca.bind("<ButtonPress-1>", lambda e, w=busca: w.focus_set(), add="+")
        busca.bind("<ButtonRelease-1>", lambda e, w=busca: w.after(10, w.focus_set), add="+")
        estado=tk.Label(cartao,bg="white",fg=marrom,anchor="w",font=("Quicksand",9,"bold"))
        estado.pack(fill="x",pady=(0,8))
        area=tk.Frame(cartao,bg="#FCFDFB",highlightbackground="#E2E8DE",highlightthickness=1)
        area.pack(fill="both",expand=True)
        rolagem=ttk.Scrollbar(area,orient="vertical")
        rolagem.pack(side="right",fill="y")
        saida=tk.Text(area,wrap="word",font=("Quicksand",10),bg="#FCFDFB",
                      fg=texto,relief="flat",padx=20,pady=18,yscrollcommand=rolagem.set)
        saida.pack(side="left",fill="both",expand=True)
        rolagem.configure(command=saida.yview)
        saida.tag_configure("titulo",foreground=marrom,font=("Quicksand",16,"bold"),spacing3=12)
        saida.tag_configure("rotulo",foreground=marrom,font=("Quicksand",10,"bold"))
        saida.tag_configure("info",foreground=texto,font=("Quicksand",10))
        import unicodedata
        def normalizar(valor):
            valor=unicodedata.normalize("NFKD",str(valor or ""))
            return "".join(c for c in valor if not unicodedata.combining(c)).casefold()
        def formatar(valor):
            if valor is None or str(valor).strip()=="":return "—"
            return str(valor)
        filtrados=[]
        saida.tag_configure("separador_verde", foreground="#6FB64E", font=("Quicksand", 11, "bold"))
        def apresentar():
            saida.configure(state="normal")
            saida.delete("1.0","end")
            if not filtrados:
                saida.insert("end",("Digite o nome da atividade ou CNAE para consultar os enquadramentos."
                                    if not busca.get().strip() else
                                    "Nenhum enquadramento correspondente. Verifique a atividade ou o CNAE."))
            else:
                # Cada linha normativa é preservada; todos os resultados são
                # apresentados verticalmente na mesma área de rolagem.
                for indice,(_,r) in enumerate(filtrados,1):
                    saida.insert("end",formatar(r.get("ATIVIDADE"))+"\n","titulo")
                    # Rótulos próprios de cada norma; nunca alterar os campos da base.
                    decreto=(norma.current()==0)
                    rotulos_decreto={
                        "ANEXO":"Anexo", "MODALIDADE":"Modalidade de licenciamento",
                        "GRUPO":"Grupo de atividades", "CNAE":"CNAE",
                        "UNIDADE":"Unidade de medida", "OPERADOR":"Critério de porte",
                        "MÍNIMO":"Limite mínimo", "MÁXIMO":"Limite máximo",
                        "CONDIÇÃO":"Condição específica", "NÍVEL DE POLUIÇÃO":"Potencial poluidor",
                        "PÁGINA FONTE":"Página da norma"}
                    rotulos_consema={
                        "GRUPO":"Grupo de habilitação (A, B ou C)",
                        "DEPARTAMENTO":"Grupo de atividades", "CNAE":"CNAE",
                        "UNIDADE":"Unidade de medida", "OPERADOR":"Critério de porte",
                        "MÍNIMO":"Limite mínimo", "MÁXIMO":"Limite máximo",
                        "CONDIÇÃO":"Condição específica", "NÍVEL DE POLUIÇÃO":"Potencial poluidor",
                        "PÁGINA FONTE":"Página da norma"}
                    rotulos=rotulos_decreto if decreto else rotulos_consema
                    for campo,valor in r.items():
                        if str(campo).startswith("_") or campo=="ATIVIDADE":
                            continue
                        # Mostrar somente campos normativos identificados, sem
                        # vazar colunas auxiliares ou denominações do Excel.
                        if campo not in rotulos:
                            continue
                        if campo=="CONDIÇÃO" and (valor is None or str(valor).strip() in ("", "—", "-")):
                            continue
                        saida.insert("end",rotulos[campo]+":  ","rotulo")
                        saida.insert("end",formatar(valor)+"\n","info")
                    if indice<len(filtrados):
                        # Separador visual verde espesso; quebras de linha reais,
                        # sem imprimir sequências literais de barra e letra n.
                        saida.insert("end", "\n" + "━" * 58 + "\n\n", "separador_verde")
            saida.configure(state="disabled")
            saida.yview_moveto(0)
        def pesquisar(event=None):
            nonlocal filtrados
            registros=DECRETO if norma.current()==0 else CONSEMA
            termo=normalizar(busca.get().strip())
            filtrados=([(i,r) for i,r in enumerate(registros,1) if
                        termo in normalizar(r.get("ATIVIDADE")) or termo in normalizar(r.get("CNAE"))]
                       if termo else [])
            estado.configure(text=(f"{len(filtrados)} enquadramento(s) encontrado(s)."
                                   if termo else ""))
            apresentar()
        norma.bind("<<ComboboxSelected>>",pesquisar)
        busca.bind("<KeyRelease>",pesquisar)
        pesquisar()

    def _montar_consulta_competencia(self, cartao):
        """Consulta independente de interface; reaproveita analyze() como fonte única."""
        marrom, verde, _, texto = self._cores_painel
        tk.Label(cartao,text="CONSULTA RÁPIDA POR MUNICÍPIO",bg="white",fg=marrom,
                 font=("Quicksand",12,"bold")).pack(anchor="w",pady=(0,7))
        tk.Label(cartao,text="Selecione um município para verificar a descentralização e seu grupo.",
                 bg="white",fg=texto).pack(anchor="w",pady=(0,7))
        municipio_var=tk.StringVar()
        municipio=ttk.Combobox(cartao,textvariable=municipio_var,
                               values=TODOS_MUNICIPIOS_MT,width=48)
        municipio.pack(fill="x",pady=(0,8))
        situacao=tk.Label(cartao,text="Aguardando seleção do município.",bg="#F1F7ED",
                          fg=marrom,anchor="w",justify="left",padx=12,pady=12,
                          font=("Quicksand",10,"bold"),wraplength=740)
        situacao.pack(fill="x",pady=(0,14))
        todos_municipios=tuple(TODOS_MUNICIPIOS_MT)
        def atualizar_municipio(_event=None):
            digitado=municipio.get().strip()
            if not digitado:
                situacao.configure(text="Aguardando seleção do município.")
                return
            # Aceita nomes digitados sem acentos e diferenças de maiúsculas.
            m=next((nome for nome in todos_municipios
                    if norm(nome)==norm(digitado)),None)
            if m in MUNICIPIOS_GRUPO:
                grupo=MUNICIPIOS_GRUPO[m]
                orgao=MUNICIPIO_CONSORCIO.get(m,"Prefeitura/Órgão Ambiental Municipal")
                situacao.configure(text=(f"{m} — DESCENTRALIZADO | Grupo {grupo}\n"
                    f"Órgão municipal: {orgao}\n"
                    "A competência depende da atividade, do porte e das condições normativas."))
            elif m in NAO_DESCENTRALIZADOS:
                situacao.configure(text=f"{m} — NÃO DESCENTRALIZADO\n"
                     "Licenciamento ambiental estadual: verificar enquadramento na SEMA/MT.")
            elif m:
                situacao.configure(text=f"{m} — Situação não identificada na base de descentralização.")
            else:
                situacao.configure(text="Continue digitando ou escolha um município na lista de sugestões.")

        # Sugestões em janela própria: o menu nativo do Combobox assume o
        # teclado ao abrir, interrompendo a digitação após poucas letras.
        # A lista abaixo NÃO toma o foco do campo de pesquisa.
        popup=None
        lista=None

        def fechar_sugestoes():
            nonlocal popup,lista
            if popup is not None:
                try:
                    popup.destroy()
                except tk.TclError:
                    pass
            popup=None
            lista=None

        def escolher_sugestao(_event=None):
            if lista is None:
                return
            selecionados=lista.curselection()
            if not selecionados:
                return
            valor=lista.get(selecionados[0])
            fechar_sugestoes()
            municipio_var.set(valor)
            municipio.icursor("end")
            municipio.focus_set()
            atualizar_municipio()

        def filtrar_municipios(event=None):
            nonlocal popup,lista
            if event is not None and event.keysym in (
                "Up","Down","Return","Escape","Tab","Shift_L","Shift_R",
                "Control_L","Control_R","Alt_L","Alt_R"):
                return
            digitado=municipio.get().strip()
            chave=norm(digitado)
            correspondencias=([m for m in todos_municipios if chave in norm(m)]
                               if digitado else [])
            municipio.configure(values=correspondencias if digitado else todos_municipios)
            atualizar_municipio()
            if not correspondencias:
                fechar_sugestoes()
                return
            if popup is None:
                popup=tk.Toplevel(cartao)
                popup.overrideredirect(True)
                popup.transient(cartao.winfo_toplevel())
                lista=tk.Listbox(popup,activestyle="none",exportselection=False,
                                 bg="white",fg=marrom,selectbackground="#DDEED3",
                                 selectforeground=marrom,font=("Quicksand",10),
                                 relief="solid",bd=1)
                lista.pack(fill="both",expand=True)
                lista.bind("<ButtonRelease-1>",escolher_sugestao)
            lista.delete(0,"end")
            for nome in correspondencias[:12]:
                lista.insert("end",nome)
            altura=min(len(correspondencias),8)*23+4
            popup.geometry(f"{max(municipio.winfo_width(),300)}x{altura}+"
                           f"{municipio.winfo_rootx()}+"
                           f"{municipio.winfo_rooty()+municipio.winfo_height()}")
            popup.deiconify()
            popup.lift()
            # O foco permanece no campo de digitação (sem event_generate Down).

        def ao_perder_foco(_event=None):
            # Dar tempo para um clique na sugestão antes de fechar o menu.
            municipio.after(180,lambda: fechar_sugestoes()
                if municipio.winfo_exists() and
                municipio.focus_get() not in (municipio,lista) else None)

        def tecla_especial(event):
            if event.keysym=="Escape":
                fechar_sugestoes()
            elif event.keysym in ("Return","Down") and lista is not None:
                if not lista.curselection():
                    lista.selection_set(0)
                escolher_sugestao()
                return "break"

        municipio.bind("<KeyRelease>",filtrar_municipios)
        municipio.bind("<KeyPress>",tecla_especial)
        municipio.bind("<<ComboboxSelected>>",lambda e:(fechar_sugestoes(),atualizar_municipio()))
        municipio.bind("<FocusOut>",ao_perder_foco)
        municipio_var.trace_add("write",lambda *_: atualizar_municipio())
    def municipality_changed(self,text,selected=False):
        municipio=text.strip()
        # Nunca manter uma atividade de outra base/grupo ao trocar município.
        if municipio != getattr(self,"_municipio_atividades_atual",None):
            self._municipio_atividades_atual=municipio
            opcoes=atividades_por_municipio(municipio)
            self._atividades_validas={norm(atividade_sem_origem(a)) for a in opcoes}
            self.a.set("")
            self.a.selected_raw=None
            self.a.set_values(opcoes,keep_text=False)
            self.a.reset_filter()
            self.p.delete(0,"end")
            self.u.set("")
            self.u.set_values(self.all_units,keep_text=False)
            self.cond.set("")
            self.cond.configure(values=[])
            self.cond_label.grid_remove()
            self.cond.grid_remove()
            self.subtipo.set("")
            self.subtipo_label.grid_remove()
            self.subtipo.grid_remove()
            self.anm.set("")
            self.anm_label.grid_remove()
            self.anm.grid_remove()
            if municipio in MUNICIPIOS_GRUPO:
                self.hint.config(text=f"Município descentralizado — Grupo {MUNICIPIOS_GRUPO[municipio]}. Atividades identificadas por legislação: CONSEMA e Decreto.")
            elif municipio in NAO_DESCENTRALIZADOS:
                self.hint.config(text="Município não descentralizado — somente atividades do Decreto.")
            else:
                self.hint.config(text="Selecione um município válido antes da atividade.")
        elif self.a.get().strip():
            self.activity_changed(self.a.get(),selected=True)

    def subtipo_changed(self,event=None):
        self.activity_changed(self.a.get(),selected=True)

    def _atualizar_visibilidade_anm(self, atividade):
        """Exibe ANM só para uma atividade efetivamente selecionada e minerária.

        Usa o grupo normativo e o detector de mineração já empregado na
        classificação. Não interfere nas linhas originais ou nos TRs.
        """
        nome=str(atividade or "").strip()
        nomes_validos=getattr(self,"_atividades_validas",set())
        selecionada=norm(nome) in nomes_validos
        if selecionada and nome in SUBTIPOS_ATIVIDADE:
            nome=atividade_normativa_selecionada(nome,self.subtipo.get())
        mineraria=False
        if selecionada and nome:
            linhas=contextual_rows_for_activity(self.m.get(),nome,selected=True)
            mineraria=any("mineracao" in norm(r.get("GRUPO","")) for r in linhas) or mineracao(nome)
        if mineraria:
            self.anm_label.grid()
            self.anm.grid()
        else:
            self.anm.set("")
            self.anm_label.grid_remove()
            self.anm.grid_remove()

    def activity_changed(self,text,selected=False):
        text=atividade_sem_origem(text)
        self._atualizar_visibilidade_anm(text)
        # Resolve somente a linha normativa do subtipo escolhido.
        opcoes=SUBTIPOS_ATIVIDADE.get(text)
        if opcoes:
            self.subtipo_label.grid()
            self.subtipo.grid()
            self.subtipo.configure(values=list(opcoes))
            if self.subtipo.get() not in opcoes:
                self.subtipo.set("")
            if not self.subtipo.get():
                self.u.set("")
                self.u.set_values([],keep_text=False)
                self.p.delete(0,"end")
                self.cond.set("")
                self.cond_label.grid_remove()
                self.cond.grid_remove()
                self.hint.config(text="Selecione o tipo de tanque para continuar o enquadramento.")
                return
            text=opcoes[self.subtipo.get()]
        else:
            self.subtipo.set("")
            self.subtipo.configure(values=[])
            self.subtipo_label.grid_remove()
            self.subtipo.grid_remove()
        n=norm(text)
        if not n:
            self.u.set_values(self.all_units)
            self.cond.set("")
            self.cond.configure(values=[])
            self.cond_label.config(text="Condição/Característica — selecione a situação aplicável")
            self.cond_label.grid_remove()
            self.cond.grid_remove()
            self.hint.config(text="Digite no Município ou Atividade para filtrar resultados compatíveis.")
            return

        # Linhas compatíveis usando o nome padronizado de exibição.
        rows=contextual_rows_for_activity(self.m.get(),text,selected=selected)

        conds=condition_options(rows)
        current_cond=self.cond.get().strip()
        if conds:
            cond_values=conds if conds==["Sim","Não"] else conds+[COND_NAO_ATENDE]
            self.cond_label.config(text=condition_question(rows) or "Condição/Característica — selecione a situação aplicável")
            self.cond.configure(values=cond_values)
            if current_cond not in cond_values:
                self.cond.set("")
            self.cond_label.grid()
            self.cond.grid()
        else:
            self.cond.set("")
            self.cond.configure(values=[])
            self.cond_label.config(text="Condição/Característica — selecione a situação aplicável")
            self.cond_label.grid_remove()
            self.cond.grid_remove()

        units=sorted({display_unit(r.get("UNIDADE")) for r in rows if r.get("UNIDADE")},key=norm)
        quantitative=[u for u in units if norm(u)!="todo"]

        if units and all(norm(u)=="todo" for u in units):
            self.u.set("")
            self.u.set_values([],keep_text=False)
            self.u.set("Todo")
            self.p.delete(0,"end")
            self.hint.config(text="Esta atividade aparece com unidade normativa 'Todo': porte numérico não é necessário para essa linha.")
        elif quantitative:
            # Limpa explicitamente o valor anterior (inclusive 'Todo')
            # antes de carregar as unidades da nova atividade.
            self.u.set("")
            self.u.set_values(quantitative,keep_text=False)
            if len(quantitative)==1:
                self.u.set(quantitative[0])
            else:
                self.u.set("")
            self.hint.config(text="Unidade(s) compatível(is): "+", ".join(quantitative))
        else:
            # Se a atividade ainda está incompleta, devolve todas as unidades
            # e remove qualquer 'Todo' herdado da atividade anterior.
            self.u.set("")
            self.u.set_values(self.all_units,keep_text=False)
            self.hint.config(text="Continue digitando a atividade para localizar correspondências.")

    def clear_fields(self):
        # Fecha listas de sugestões abertas e restaura o formulário.
        for campo in (self.m, self.a, self.u):
            try:
                campo._hide_popup()
            except Exception:
                pass

        self.m.set("")
        self.m.reset_filter()
        self.a.set("")
        self.a.reset_filter()
        self.p.delete(0, "end")
        self.u.set("")
        self.u.set_values(self.all_units, keep_text=False)
        self.u.reset_filter()
        self.anm.set("")
        self.anm_label.grid_remove()
        self.anm.grid_remove()
        self.tipo_tr.set("Inicial")
        self.subtipo.set("")
        self.subtipo.configure(values=[])
        self.subtipo_label.grid_remove()
        self.subtipo.grid_remove()
        self.cond.set("")
        self.cond.configure(values=[])
        self.cond_label.grid_remove()
        self.cond.grid_remove()
        self.hint.config(text="Digite no Município ou Atividade para filtrar resultados compatíveis.")
        self.out.delete("1.0", "end")
        self.out.insert("1.0", "Preencha os dados e clique em ANALISAR.\n\nVocê pode digitar apenas parte do nome da atividade, município ou unidade para filtrar a lista.")
        self._atualizar_resumo("")
        self.m.focus_set()

    def _atualizar_resumo(self,resultado):
        """Resume apenas o texto já produzido; nunca altera a decisão normativa."""
        import re
        def campo(rotulo):
            achado=re.search(r"(?im)^"+re.escape(rotulo)+r":\s*([^\n]+)",resultado)
            return achado.group(1).strip() if achado else ""
        competencia=campo("Competência")
        modalidade=campo("Modalidade")
        situacao=campo("Resultado")
        if not situacao and resultado.strip():
            situacao=("Dados incompletos ou análise não concluída"
                     if not competencia else "Verificar detalhes abaixo")
        for chave,valor in (
            ("competencia",competencia or ("—" if resultado else "Aguardando análise")),
            ("modalidade",modalidade or ("Não indicada" if resultado else "Aguardando análise")),
            ("situacao",situacao or "Aguardando análise")):
            self._resumo_campos[chave].configure(text=valor)

    def verificar_trs_online(self):
        """Executa a verificação sem bloquear a janela principal."""
        self.hint.config(text="Verificando os links oficiais pela internet…")
        def tarefa():
            fontes = urls_trs()
            resultados = [(chave, verificar_link_tr(url)) for chave, url in fontes.items()]
            def exibir():
                self.out.delete("1.0", "end")
                self._atualizar_resumo("")
                self.out.insert("1.0", "VERIFICAÇÃO ONLINE DE LINKS DOS TRs — SEMA/MT\n\n")
                for chave, situacao in resultados:
                    self.out.insert("end", f"{chave}: {situacao}\n{fontes[chave]}\n\n")
                self.out.insert("end", "Acessibilidade do link não comprova vigência, conteúdo ou existência de TR específico.\n")
                self.hint.config(text="Verificação concluída. Para enquadrar uma atividade, clique em ANALISAR.")
                self.marcar_links(self.out.get("1.0", "end"))
            self.after(0, exibir)
        threading.Thread(target=tarefa, daemon=True).start()

    def marcar_links(self, texto):
        self.out.tag_configure("tr_link", foreground="#175b98", underline=True)
        # Inclui também os endereços provenientes da planilha conciliada.
        # Não confunde páginas de categoria com PDFs específicos.
        urls = set(urls_trs().values())
        for grupo in ("trs_especificos", "categorias"):
            for item in carregar_catalogo_trs().get(grupo, []):
                if isinstance(item, dict):
                    urls.add(str(item.get("url", "")))
        try:
            registros = json.loads(TR_ASSOCIACOES_PATH.read_text(encoding="utf-8")).get("registros", [])
            for item in registros:
                urls.add(str(item.get("link_pdf") or ""))
                urls.add(str(item.get("link_pagina") or ""))
        except (OSError, ValueError, TypeError):
            pass
        for url in sorted(u for u in urls if u.startswith("https://www.sema.mt.gov.br/")):
            start = 0
            while True:
                pos = texto.find(url, start)
                if pos < 0:
                    break
                tag = f"tr_{pos}"
                self.out.tag_add(tag, f"1.0+{pos}c", f"1.0+{pos + len(url)}c")
                self.out.tag_configure(tag, foreground="#175b98", underline=True)
                self.out.tag_bind(tag, "<Button-1>", lambda _event, link=url: webbrowser.open(link))
                self.out.tag_bind(tag, "<Enter>", lambda _event: self.out.configure(cursor="hand2"))
                self.out.tag_bind(tag, "<Leave>", lambda _event: self.out.configure(cursor="xterm"))
                start = pos + len(url)

    def go(self):
        atividade=atividade_sem_origem(self.a.get().strip())
        if atividade in SUBTIPOS_ATIVIDADE:
            atividade=atividade_normativa_selecionada(atividade,self.subtipo.get())
            if not atividade:
                self.out.delete("1.0","end")
                self.out.insert("1.0","Selecione o tipo de tanque (aéreo ou enterrado) antes de analisar.")
                self._atualizar_resumo("")
                return
        r=analyze(self.m.get(),atividade,self.p.get(),self.u.get(),self.anm.get(),self.cond.get(),self.tipo_tr.get())
        self.out.delete("1.0","end");self.out.insert("1.0",r)
        self._atualizar_resumo(r)
        # Links clicáveis cadastrados em fonte externa, sem alterar a análise.
        self.marcar_links(r)

if __name__=="__main__":
    App().mainloop()
