# -*- coding: utf-8 -*-
"""ÓIKOS: atualizador independente de arquivos do aplicativo, sem tocar nas bases."""
import argparse, ast, datetime, hashlib, io, json, os, pathlib, re, sys, tempfile, urllib.request, zipfile
ROOT=pathlib.Path(__file__).resolve().parent
CATALOG='https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/versoes.json'
PREFIX='https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/'
MAX_CATALOG=256*1024
MAX_ZIP=15*1024*1024
ALLOWED={'OIKOS.py','ATUALIZADOR_COMPLETO.py','ATUALIZAR_APLICATIVO.py'}
HEX=re.compile(r'[0-9a-fA-F]{64}\Z')
def sha(data):return hashlib.sha256(data).hexdigest()
def vt(v):
    if not isinstance(v,str) or not re.fullmatch(r'\d+\.\d+\.\d+',v):raise ValueError('Versão inválida')
    return tuple(map(int,v.split('.')))
def current_version(root):
    # Não depender da versão fixa do próprio atualizador.
    tree=ast.parse((root/'OIKOS.py').read_text(encoding='utf-8-sig'))
    for n in ast.walk(tree):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='title' and n.args:
            a=n.args[0]
            if isinstance(a,ast.Constant) and isinstance(a.value,str):
                m=re.search(r'v(\d+\.\d+\.\d+)',a.value)
                if m:return m.group(1)
    raise ValueError('Versão local não identificada no título')
def fetch(url,limit):
    if not isinstance(url,str) or not url.startswith(PREFIX) or not url.endswith(('.zip','.json')):raise ValueError('URL não autorizada')
    req=urllib.request.Request(url,headers={'User-Agent':'OIKOS-Completo/1','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req,timeout=30) as r:
        if r.geturl()!=url:raise ValueError('Redirecionamento não autorizado')
        data=r.read(limit+1)
    if len(data)>limit:raise ValueError('Arquivo excede limite')
    return data
def atomic_write(path,data):
    tmp=None
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.oikos_',suffix='.tmp',delete=False) as f:
            tmp=pathlib.Path(f.name);f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
        if path.read_bytes()!=data:raise RuntimeError('Falha de verificação pós-gravação')
    finally:
        if tmp is not None:tmp.unlink(missing_ok=True)
def prepare(catalog,package,root):
    app=catalog.get('aplicativo')
    if not isinstance(app,dict) or app.get('id')!='oikos-app':raise ValueError('Catálogo inválido')
    version=app.get('versao');vt(version)
    if vt(version)<=vt(current_version(root)):return version,{}
    expected=app.get('sha256')
    if not isinstance(expected,str) or not HEX.fullmatch(expected):raise ValueError('SHA do pacote inválido')
    if sha(package)!=expected.lower():raise ValueError('SHA do pacote divergente')
    spec=app.get('arquivos')
    if not isinstance(spec,list) or not spec or len(spec)>len(ALLOWED):raise ValueError('Manifesto multi-arquivo ausente/inválido')
    files={}
    with zipfile.ZipFile(io.BytesIO(package)) as z:
        names=z.namelist()
        if len(names)!=len(set(names)) or set(names)!={v.get('nome') for v in spec if isinstance(v,dict)}:raise ValueError('Lista de arquivos divergente')
        for entry in spec:
            if not isinstance(entry,dict):raise ValueError('Entrada inválida')
            name=entry.get('nome');h=entry.get('sha256')
            if name not in ALLOWED or not isinstance(h,str) or not HEX.fullmatch(h):raise ValueError('Arquivo ou hash não permitido')
            info=z.getinfo(name)
            if info.is_dir() or info.file_size>4*1024*1024:raise ValueError('Tamanho inválido')
            content=z.read(info)
            if sha(content)!=h.lower():raise ValueError('Hash interno divergente: '+name)
            compile(content,name,'exec')
            files[name]=content
    if 'OIKOS.py' not in files or 'ATUALIZADOR_COMPLETO.py' not in files:raise ValueError('Componentes obrigatórios ausentes')
    if version!=re.search(r'v(\d+\.\d+\.\d+)',next(n.args[0].value for n in ast.walk(ast.parse(files['OIKOS.py'])) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='title' and n.args and isinstance(n.args[0],ast.Constant) and isinstance(n.args[0].value,str) and re.search(r'v\d+\.\d+\.\d+',n.args[0].value))).group(1):raise ValueError('Versão do pacote incompatível')
    return version,files
def run(install=False,root=ROOT,catalog_data=None,package_data=None,authorize=None,fail_after=None):
    root=pathlib.Path(root).resolve()
    if not (root/'OIKOS.py').is_file():raise ValueError('Instalação não encontrada')
    catalog=json.loads(catalog_data if catalog_data is not None else fetch(CATALOG,MAX_CATALOG))
    app=catalog.get('aplicativo',{})
    remote=app.get('versao');vt(remote)
    local=current_version(root)
    if vt(remote)<=vt(local):print('ÓIKOS atualizado:',local,'; catálogo:',remote);return 'atualizado'
    package=package_data if package_data is not None else fetch(app.get('url'),MAX_ZIP)
    version,files=prepare(catalog,package,root)
    if not install:print('VALIDADO (somente leitura): atualização completa disponível',version);return 'validado'
    confirm=authorize if authorize is not None else input('Para instalar '+version+' digite AUTORIZO: ').strip()
    if confirm!='AUTORIZO':print('Cancelado; nenhum arquivo alterado');return 'cancelado'
    backups=root/'backups_atualizacoes_aplicativo';backups.mkdir(exist_ok=True)
    folder=backups/('pacote_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f'))
    folder.mkdir()
    originals={}
    # Snapshot completo antes da primeira substituição.
    for name in files:
        path=root/name
        originals[name]=path.read_bytes() if path.exists() else None
        if originals[name] is not None:atomic_write(folder/name,originals[name])
    atomic_write(folder/'manifesto_backup.json',json.dumps({'anterior':local,'nova':version,'arquivos':{k:sha(v) if v is not None else None for k,v in originals.items()}},indent=2).encode())
    for name,old in originals.items():
        if old is not None and (folder/name).read_bytes()!=old:raise RuntimeError('Backup não conferido')
    changed=[]
    try:
        for name,data in files.items():
            # Se alguém alterou o arquivo durante a operação, abortar.
            actual=(root/name).read_bytes() if (root/name).exists() else None
            if actual!=originals[name]:raise RuntimeError('Arquivo alterado durante atualização: '+name)
            changed.append(name)
            atomic_write(root/name,data)
            if fail_after==name:raise RuntimeError('Falha simulada após '+name)
        print('INSTALADO:',version,'Backup:',folder)
        return 'instalado'
    except BaseException:
        errors=[]
        for name in reversed(changed):
            try:
                old=originals[name]
                if old is None:(root/name).unlink(missing_ok=True)
                else:atomic_write(root/name,old)
            except BaseException as exc:errors.append(name+': '+str(exc))
        if errors:raise RuntimeError('ROLLBACK INCOMPLETO: '+'; '.join(errors))
        print('ROLLBACK confirmado: arquivos restaurados')
        raise
if __name__=='__main__':
    p=argparse.ArgumentParser();g=p.add_mutually_exclusive_group();g.add_argument('--verificar',action='store_true');g.add_argument('--instalar',action='store_true');args=p.parse_args()
    try:run(install=args.instalar)
    except Exception as exc:print('BLOQUEADO:',type(exc).__name__,str(exc));sys.exit(1)
    finally:
        if sys.platform=='win32':
            try:input('Pressione Enter para fechar...')
            except EOFError:pass
