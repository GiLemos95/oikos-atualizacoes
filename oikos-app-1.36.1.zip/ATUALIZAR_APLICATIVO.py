# -*- coding: utf-8 -*-
"""Atualizador independente ÓIKOS; nunca modifica bases normativas."""
import argparse, datetime, hashlib, io, json, os, pathlib, re, sys, tempfile, urllib.request, zipfile
ROOT = pathlib.Path(__file__).resolve().parent
CATALOG = 'https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/versoes.json'
PREFIX = 'https://raw.githubusercontent.com/GiLemos95/oikos-atualizacoes/main/'
MAX_CATALOG = 256 * 1024
MAX_ZIP = 6 * 1024 * 1024
CURRENT_VERSION = '1.35.5'

def sha(data): return hashlib.sha256(data).hexdigest()
def version_tuple(value):
    if not isinstance(value, str) or not re.fullmatch(r'\d+\.\d+\.\d+', value):
        raise ValueError('Formato de versão inválido')
    return tuple(int(n) for n in value.split('.'))
def fetch(url, limit):
    if not isinstance(url,str) or not url.startswith(PREFIX) or not url.endswith(('.zip','.json')):
        raise ValueError('URL fora do repositório oficial')
    req=urllib.request.Request(url, headers={'User-Agent':'OIKOS-Updater/2.0','Cache-Control':'no-cache'})
    with urllib.request.urlopen(req, timeout=25) as r:
        if r.geturl()!=url: raise ValueError('Redirecionamento não permitido')
        data=r.read(limit+1)
    if len(data)>limit: raise ValueError('Arquivo excede o limite')
    return data

def run(install=False, catalog_data=None, package_data=None, root=ROOT):
    root=pathlib.Path(root).resolve()
    target=root/'OIKOS.py'
    if not target.is_file(): raise ValueError('OIKOS.py não encontrado')
    catalog=json.loads(catalog_data if catalog_data is not None else fetch(CATALOG,MAX_CATALOG))
    app=catalog.get('aplicativo')
    if not isinstance(app,dict) or app.get('id')!='oikos-app': raise ValueError('Catálogo sem aplicativo válido')
    new_version=app.get('versao')
    if version_tuple(new_version)<=version_tuple(CURRENT_VERSION):
        print('ÓIKOS atualizado: versão local',CURRENT_VERSION,'; catálogo',new_version)
        return 'atualizado'
    url=app.get('url')
    expected=app.get('sha256')
    inner=app.get('sha256_oikos_py')
    if not isinstance(expected,str) or not re.fullmatch('[a-fA-F0-9]{64}',expected): raise ValueError('Hash do pacote inválido')
    if not isinstance(inner,str) or not re.fullmatch('[a-fA-F0-9]{64}',inner): raise ValueError('Hash interno inválido')
    data=package_data if package_data is not None else fetch(url,MAX_ZIP)
    if sha(data)!=expected.lower(): raise ValueError('SHA-256 do pacote divergente')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        if z.namelist()!=['OIKOS.py']: raise ValueError('Pacote deve conter somente OIKOS.py')
        info=z.getinfo('OIKOS.py')
        if info.file_size>4*1024*1024 or info.is_dir(): raise ValueError('Conteúdo inválido')
        novo=z.read(info)
    if sha(novo)!=inner.lower(): raise ValueError('SHA-256 do aplicativo divergente')
    compile(novo,'OIKOS.py','exec')
    if not install:
        print('VALIDADO (somente leitura): atualização disponível',new_version)
        return 'validado'
    print('Atualização disponível:',CURRENT_VERSION,'->',new_version)
    if input('Para instalar digite AUTORIZO: ').strip()!='AUTORIZO':
        print('Cancelado; nenhuma alteração')
        return 'cancelado'
    antigo=target.read_bytes()
    backup_dir=root/'backups_atualizacoes_aplicativo';backup_dir.mkdir(exist_ok=True)
    backup=backup_dir/('OIKOS_'+datetime.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+sha(antigo)[:12]+'.py.bak')
    with backup.open('xb') as f:
        f.write(antigo);f.flush();os.fsync(f.fileno())
    if backup.read_bytes()!=antigo: raise RuntimeError('Backup não conferido')
    temp=None
    try:
        if target.read_bytes()!=antigo: raise RuntimeError('O aplicativo mudou durante a atualização')
        with tempfile.NamedTemporaryFile(dir=root,prefix='.oikos_app_',suffix='.tmp',delete=False) as f:
            temp=pathlib.Path(f.name);f.write(novo);f.flush();os.fsync(f.fileno())
        os.replace(temp,target)
        if target.read_bytes()!=novo: raise RuntimeError('Instalação não conferida')
        print('INSTALADO:',new_version,'Backup:',backup)
        return 'instalado'
    except BaseException:
        with tempfile.NamedTemporaryFile(dir=root,prefix='.oikos_rollback_',suffix='.tmp',delete=False) as f:
            rollback=pathlib.Path(f.name);f.write(antigo);f.flush();os.fsync(f.fileno())
        os.replace(rollback,target)
        if target.read_bytes()!=antigo: raise RuntimeError('ERRO CRÍTICO: rollback não confirmado')
        print('ROLLBACK confirmado')
        raise
    finally:
        if temp is not None: temp.unlink(missing_ok=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    group=parser.add_mutually_exclusive_group()
    group.add_argument('--verificar',action='store_true')
    group.add_argument('--instalar',action='store_true')
    args=parser.parse_args()
    try: run(install=args.instalar)
    except Exception as exc:
        print('BLOQUEADO:',type(exc).__name__,str(exc))
        sys.exit(1)
    finally:
        if sys.platform=='win32':
            try: input('Pressione Enter para fechar...')
            except EOFError: pass
